# COMMITGUARD Artifact for Paper Sections 6.1--6.7

This archive is the self-contained, standard-library-only artifact for the experiments reported in Sections 6.1--6.7 and Tables 1--10 of *No Silent Abandonment: Distributed Integrity Protection for Physical Commitments in Autonomous Disaster Response*.

The simulator is a software-only discrete-event model. Its certificate checks are an abstract state-machine mechanism; the package does not implement a deployed asynchronous consensus protocol or physical robot platform.

## Quick start

Requirements: CPython 3.10 or later. No third-party Python packages are required.

From the extracted `COMMITGUARD_Source_Code` directory:

```bash
python scripts/reproduce_tables.py
python scripts/verify_paper_results.py
python scripts/run_smoke_test.py
python -m unittest discover -s tests -v
```

On Windows PowerShell, use `py` instead of `python` if that is how Python is installed:

```powershell
py scripts\reproduce_tables.py
py scripts\verify_paper_results.py
py scripts\run_smoke_test.py
py -m unittest discover -s tests -v
```

The first mode is fast: it re-aggregates the bundled formal raw CSVs and compares all reported table cells at their displayed precision. The second mode actually executes the simulator.

## Reproduction modes

### A. Recalculate the paper tables from formal raw data

```bash
python scripts/reproduce_tables.py
python scripts/verify_paper_results.py
```

Outputs:

- `results/recomputed_tables.json`
- `results/recomputed_tables.md`
- `results/verification.json`
- `docs/VERIFICATION_REPORT.md`

The formal files are immutable inputs. Central commit-aware rows for the affected experiments come from the separately recorded Central run; other policies come from the corresponding formal run. `data/SOURCE_INDEX.json` records hashes and provenance.

### B. Rerun the simulator

Quick end-to-end check:

```bash
python scripts/run_all_experiments.py --quick --no-progress
```

Full paper-sized rerun (substantially slower):

```bash
python scripts/run_all_experiments.py --no-progress
```

Individual experiments:

```bash
python src/commitguard_sim.py --experiment default --traces 500 --seed 1 --out-dir rerun/default
python src/commitguard_sim.py --experiment partition --sweep-traces 200 --seed 1 --out-dir rerun/partition
python src/commitguard_sim.py --experiment inflation --sweep-traces 200 --seed 1 --out-dir rerun/inflation
python src/commitguard_sim.py --experiment crash_witness --extra-traces 200 --seed 1 --out-dir rerun/crash_witness
python src/commitguard_sim.py --experiment handoff --extra-traces 200 --seed 1 --out-dir rerun/handoff
python src/commitguard_sim.py --experiment security_attacks --extra-traces 200 --seed 1 --out-dir rerun/security_attacks
python src/commitguard_sim.py --experiment ablation --extra-traces 200 --seed 1 --out-dir rerun/ablation
python src/commitguard_sim.py --experiment scale --extra-traces 200 --seed 1 --out-dir rerun/scalability
python src/commitguard_sim.py --experiment microbench --bench-repeats 200 --seed 1 --out-dir rerun/microbenchmark
```

Runtime measurements can vary with hardware, operating system, Python version, and system load. Exact timing reproduction is not expected. Non-timing statistics are deterministic for the recorded simulator/Python representation, seed, and parameters.

## Directory layout

```text
COMMITGUARD_Source_Code/
  src/                      simulator source
  configs/                  formal parameters and paper targets
  experiments/              experiment-to-command mapping
  scripts/                  table reproduction, verification, and runners
  data/formal/              immutable raw formal data used by Tables 2--10
  results/                  regenerated table outputs
  tests/                    deterministic regression tests
  docs/                     provenance, metrics, paper/code mapping, verification
```

The implementation under `src/` is organized by responsibility: `models.py`
defines state and event types, `simulation.py` generates traces and advances
epochs, `commitment.py` implements certificates and lifecycle transitions,
`policies.py` implements admission and strategy behavior, `security.py`
performs integrity checks, and `experiments.py` provides statistics and
experiment drivers. `commitguard_sim.py` remains the command-line entry point
and links the shared names needed by the mutually dependent lifecycle paths.
The linker performs no simulation or statistical calculation.

## Experimental design

- Default workload: 500 traces, five policies, seed 1.
- Sweeps and directed experiments: 200 traces per configuration.
- Policies at the same parameter point receive the same generated trace. Each raw row records `trace_id` and, where available, `trace_sha256`.
- Paired comparisons operate on within-trace differences and use two-sided 95% Student-t intervals.
- `Physical Completed` records completion of the modeled physical action; `Rescued` additionally requires the policy's settlement/Retire condition. For COMMITGUARD, their default difference equals `Retire Pending at End` on all 500 formal traces.
- `Silent Unbacking` is a physical-history oracle metric. It is distinct from implementation-internal invariant observations and from `Physical Underbacking` caused by exogenous capacity loss or demand growth.

See `docs/METRIC_DEFINITIONS.md` and `docs/PAPER_TO_CODE_MAPPING.md` for exact mappings.

## Known limitations

1. The simulator validates a discrete-event abstraction, not a deployed network protocol or real physical plant.
2. Table 9 runtime is Python simulation runtime. It excludes network transmission, distributed agreement, witness storage latency, robot motion, and actuation.
3. Table 10 is reproducible from the preserved aggregate benchmark rows. The original 200 individual timing samples per size were not retained, so timing-distribution re-analysis is not independently verifiable.
4. Central commit-aware rows are a separate recorded source. The policy-selective aggregation and its provenance are documented in the source index.
5. Random runtime scheduling and platform differences can change timing cells even when semantic outputs remain unchanged.

## Data integrity

`data/SOURCE_INDEX.json` records SHA-256 hashes and input provenance. See `docs/DATA_PROVENANCE.md` and `docs/PUBLIC_RELEASE_AUDIT.md` for verification scope.

## License

No open-source license was supplied for this artifact. `LICENSE.txt` records that limitation; obtain authorization before public redistribution.
