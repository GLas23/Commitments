from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Iterable, Optional

from .models import *

def check_contract_claim(commitment: Commitment, result: PolicyResult) -> None:
    record_model_underestimate(commitment, result)


def release_forgotten_view(commitment: Commitment, robots: list[Robot], result: PolicyResult, policy: str) -> None:
    if commitment.forgotten_released:
        return
    if (policy == "commit_guard" and (
        commitment.physical_live
        or commitment.certificate_update_uncertain
        or commitment.pending_operation
    )) or (policy == "central_commit_aware" and (
        commitment.physical_live
        or commitment.certificate_update_uncertain
        or commitment.pending_operation
        or not commitment.retire_committed_recorded
    )):
        # Losing access to the latest effective certificate never authorizes an
        # uncommitted Retire.  This includes the window where trusted physical
        # discharge has occurred but its successor certificate is uncertain:
        # keep the old effective right and any consumed/pending accounting
        # locked for recovery rather than manufacturing a bookkeeping retire.
        # Central has no witnesses or local ownership mechanism: after its sole
        # durable view is lost, it cannot safely infer discharge or reclaim the
        # lock.  This is an explicit availability limit, not a new capability.
        transition_at_risk(
            commitment, robots, result, policy, "certificate_copies_unavailable"
        )
        return
    released = sum(commitment.reserved.values())
    record_reservation_release_accounting(commitment, result)
    for robot_id in list(commitment.reserved):
        if 0 <= robot_id < len(robots):
            robots[robot_id].reserved.pop(commitment.ident, None)
    commitment.reserved.clear()
    commitment.effective_reserved.clear()
    commitment.pending_reserved.clear()
    commitment.pending_consumed_backing.clear()
    commitment.pending_operation = ""
    commitment.pending_version = None
    release_remote_claims(commitment, robots)
    commitment.protected_present = False
    commitment.status = STATUS_FORGOTTEN
    commitment.forgotten_released = True
    commitment.release_events.append(
        {
            "reason": "certificate_view_forgotten",
            "authorized": False,
            "executed": True,
            "amount": released,
            "effective_version": commitment.effective_version,
            "physical_live": commitment.physical_live,
        }
    )
    result.forgotten_and_resources_reused += 1 if released > 1e-9 else 0
    result.commitment_loss += 1
    if commitment.physical_live:
        result.physical_commitments_still_live += 1
        result.orphaned_liability += sum(commitment.true_req.values())


def check_forgetting(policy: str, commitment: Commitment, robots: list[Robot], result: PolicyResult) -> None:
    if not (caps(policy).has_commitment_ledger and caps(policy).has_certificate_auth) or commitment.forgetting_recorded or not commitment.protected_present:
        return
    result.certificate_survival_checks += 1
    if not has_latest_certificate(commitment, robots):
        commitment.forgetting_recorded = True
        result.forgotten += 1
        result.forgotten_commitments += 1
        result.certificates_lost += 1
        release_forgotten_view(commitment, robots, result, policy)
    else:
        result.certificate_survivors += 1


def check_remote_ownership_conflicts(policy: str, robots: list[Robot], live: list[Commitment], result: PolicyResult, where: str) -> None:
    live_by_id = {commitment.ident: commitment for commitment in live if commitment.protected_present}
    for robot_id, robot in enumerate(robots):
        if not robot.remote_reserved:
            continue
        local_reserved = sum(robot.reserved.values())
        remote_reserved = sum(robot.remote_reserved.values())
        has_local_overlap = local_reserved > 1e-9 and remote_reserved > 1e-9
        has_remote_overlap = len(robot.remote_reserved) > 1
        has_capacity_conflict = robot.active and local_reserved + remote_reserved > robot.energy - robot.self_reserve + 1e-9
        if not (has_local_overlap or has_remote_overlap or has_capacity_conflict):
            continue
        for commitment_id in list(robot.remote_reserved):
            commitment = live_by_id.get(commitment_id)
            if commitment is None:
                result.release_violations += 1
                result.invariant_violations += 1
                continue
            if commitment.remote_overspend_recorded:
                continue
            if has_local_overlap or has_remote_overlap:
                record_invariant_violation(policy, result, "double_spend_violations", f"remote claim {commitment_id} overlaps resource ownership on robot {robot_id} at {where}")
                result.remote_double_spend_events += 1
            if has_capacity_conflict:
                record_invariant_violation(policy, result, "capacity_violations", f"remote claim {commitment_id} exceeds local capacity on robot {robot_id} at {where}")
            result.stale_ownership += 1
            result.ownership_conflicts += 1
            result.remote_overspend_success += 1
            result.attack_success += 1
            result.adversarial_success += 1
            result.adversarial_physical_violation += 1
            commitment.remote_overspend_recorded = True


def check_invariants(policy: str, robots: list[Robot], live: list[Commitment], result: PolicyResult, where: str) -> None:
    for i, robot in enumerate(robots):
        if robot.energy < -1e-9:
            record_invariant_violation(policy, result, "capacity_violations", f"robot {i} negative energy at {where}")
        if robot.self_level not in SELF_LEVELS:
            record_invariant_violation(policy, result, "illegal_degradation_violations", f"robot {i} illegal level {robot.self_level}")
        if robot.active and policy != "immediate_only" and robot.total_reserved > robot.energy - robot.self_reserve + 1e-9:
            record_invariant_violation(policy, result, "capacity_violations", f"robot {i} over-reserved at {where}")
        for cid, amount in robot.reserved.items():
            if amount < -1e-9:
                record_invariant_violation(policy, result, "double_spend_violations", f"negative reservation {cid} at {where}")
        for cid, amount in robot.remote_reserved.items():
            if amount < -1e-9:
                record_invariant_violation(policy, result, "double_spend_violations", f"negative remote reservation {cid} at {where}")
        for cid, amount in robot.pending_execution_cost.items():
            if amount < -1e-9:
                record_invariant_violation(policy, result, "double_spend_violations", f"negative pending Mint cost {cid} at {where}")

    check_remote_ownership_conflicts(policy, robots, live, result, where)

    active_ids = {
        c.ident
        for c in live
        if c.protected_present and (c.status in ACTIVE_STATUSES or c.physical_live)
    }
    for robot in robots:
        for cid in robot.reserved:
            if cid not in active_ids:
                record_invariant_violation(policy, result, "release_violations", f"reservation for inactive commitment {cid} remains at {where}")
        for cid in robot.remote_reserved:
            if cid not in active_ids:
                record_invariant_violation(policy, result, "release_violations", f"remote claim for inactive commitment {cid} remains at {where}")

    for commitment in live:
        if lifecycle_protected(policy) and commitment.physical_live and not commitment.protected_present:
            record_invariant_violation(
                policy,
                result,
                "release_violations",
                f"commitment {commitment.ident} removed from protected state while physical liability remains",
            )
        if caps(policy).has_certificate_auth and commitment.effective_version > 0:
            effective = commitment.effective_version
            snapshot = commitment.certificate_history.get(effective)
            metadata = commitment.certificate_metadata.get(effective)
            acknowledgements = commitment.certificate_acknowledgements.get(effective, set())
            if snapshot is None or metadata is None:
                record_invariant_violation(
                    policy,
                    result,
                    "version_violations",
                    f"commitment {commitment.ident} effective certificate {effective} lacks committed state",
                )
            else:
                expected_hash = commitment.version_state_hashes.get(effective)
                if expected_hash != snapshot_hash(snapshot):
                    record_invariant_violation(
                        policy,
                        result,
                        "certificate_hash_violations",
                        f"commitment {commitment.ident} effective certificate {effective} hash mismatch",
                    )
                predecessor = int(metadata.get("predecessor", -1))
                if predecessor >= effective or commitment.certificate_successors.get(predecessor) != effective:
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} effective certificate {effective} has invalid predecessor chain",
                    )
                committed_versions = set(commitment.certificate_history)
                if committed_versions and effective != max(committed_versions):
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} effective certificate {effective} is not the committed chain head",
                    )
                if int(snapshot.get("version", -1)) != effective:
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} certificate {effective} carries a different state version",
                    )
                required_participants = {int(snapshot["carrier"])}
                if snapshot.get("support") is not None:
                    required_participants.add(int(snapshot["support"]))
                if not required_participants.issubset(acknowledgements):
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} certificate {effective} lacks participant confirmation",
                    )
                persisted_copies = commitment.certificate_persisted_versions.get(effective, acknowledgements)
                if len(persisted_copies) < commitment.certificate_persistence_threshold:
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} certificate {effective} lacks persistence quorum",
                    )
                certificate_reserved = _native_snapshot_map(snapshot.get("reserved", {}))
                if certificate_reserved != commitment.effective_reserved or commitment.reserved != commitment.effective_reserved:
                    result.certificate_ledger_mismatch_violations += 1
                    record_invariant_violation(
                        policy,
                        result,
                        "backing_violations",
                        f"commitment {commitment.ident} effective certificate reservation differs from effective logical ledger",
                    )
                stable_state_mismatches: list[str] = []
                if int(snapshot.get("carrier", -1)) != commitment.carrier:
                    stable_state_mismatches.append("carrier")
                snapshot_support = snapshot.get("support")
                native_support = None if snapshot_support is None else int(snapshot_support)
                if native_support != commitment.support:
                    stable_state_mismatches.append("support")
                if str(snapshot.get("guarantee", "")) != commitment.guarantee:
                    stable_state_mismatches.append("guarantee")
                for stage_field in ("phase_contract_id", "physical_stage", "phase_evidence_hash", "assist_for",
                                    "physical_object", "responsibility_scope", "responsibility_units"):
                    if snapshot.get(stage_field) != getattr(commitment, stage_field):
                        stable_state_mismatches.append(stage_field)
                if _native_snapshot_map(snapshot.get("certified_min_req", {})) != commitment.certified_min_req:
                    stable_state_mismatches.append("certified_min_req")
                if _native_snapshot_map(snapshot.get("initial_claimed_req", {})) != commitment.initial_claimed_req:
                    stable_state_mismatches.append("initial_claimed_req")
                if bool(snapshot.get("protected_present", True)) != commitment.protected_present:
                    stable_state_mismatches.append("protected_present")

                # AT-RISK/RUPTURED is an explicit operational overlay when an
                # exogenous change occurred but the successor certificate is
                # uncertain.  In that conservative state the physical truth
                # and current requirement may legitimately be newer than the
                # last effective certificate; participant identity and the
                # certified guarantee still may not change silently.
                uncertain_risk_overlay = (
                    commitment.certificate_update_uncertain
                    and commitment.status in {STATUS_AT_RISK, STATUS_RUPTURED}
                )
                if not uncertain_risk_overlay:
                    if str(snapshot.get("status", "")) != commitment.status:
                        stable_state_mismatches.append("status")
                    if _native_snapshot_map(snapshot.get("claimed_req", {})) != commitment.claimed_req:
                        stable_state_mismatches.append("claimed_req")
                    if _native_snapshot_map(snapshot.get("true_req", {})) != commitment.true_req:
                        stable_state_mismatches.append("true_req")
                    if bool(snapshot.get("physical_live", commitment.physical_live)) != commitment.physical_live:
                        stable_state_mismatches.append("physical_live")
                if stable_state_mismatches:
                    result.certificate_ledger_mismatch_violations += 1
                    record_invariant_violation(
                        policy,
                        result,
                        "backing_violations",
                        f"commitment {commitment.ident} effective certificate differs from protected state: "
                        + ",".join(stable_state_mismatches),
                    )

                inheritance = metadata.get("responsibility_inheritance", {})
                expected_inheritance = {
                    "physical_live": snapshot.get("physical_live"),
                    "carrier": snapshot.get("carrier"),
                    "support": snapshot.get("support"),
                    "guarantee": snapshot.get("guarantee"),
                    "phase_contract_id": snapshot.get("phase_contract_id", ""),
                    "physical_stage": snapshot.get("physical_stage", "placement"),
                    "phase_evidence_hash": snapshot.get("phase_evidence_hash", ""),
                    "assist_for": snapshot.get("assist_for"),
                    "physical_object": snapshot.get("physical_object"),
                    "responsibility_scope": snapshot.get("responsibility_scope"),
                    "responsibility_units": snapshot.get("responsibility_units"),
                }
                if inheritance != expected_inheritance:
                    record_invariant_violation(
                        policy,
                        result,
                        "certificate_hash_violations",
                        f"commitment {commitment.ident} certificate responsibility inheritance mismatch",
                    )
                crashed_acknowledgers = {
                    holder
                    for holder in acknowledgements
                    if holder < 0 or holder >= len(robots) or not robots[holder].active
                }
                active_acknowledgers = acknowledgements - crashed_acknowledgers
                if (
                    len(acknowledgements) >= commitment.certificate_fault_tolerance + 1
                    and len(crashed_acknowledgers) <= commitment.certificate_fault_tolerance
                    and not active_acknowledgers
                ):
                    result.certificate_survival_guarantee_violations += 1
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} lost all f+1 certificate copies within fault threshold",
                    )
        for release_event in commitment.release_events:
            if (
                lifecycle_protected(policy)
                and bool(release_event.get("executed"))
                and not bool(release_event.get("authorized"))
                and not bool(release_event.get("violation_recorded"))
            ):
                release_event["violation_recorded"] = True
                result.residual_liability_reuse_violations += 1
                record_invariant_violation(
                    policy,
                    result,
                    "release_violations",
                    f"commitment {commitment.ident} executed release without state authorization",
                )
            if (
                lifecycle_protected(policy)
                and bool(release_event.get("executed"))
                and bool(release_event.get("authorized"))
                and int(release_event.get("effective_version", 0)) > commitment.effective_version
            ):
                record_invariant_violation(
                    policy,
                    result,
                    "release_violations",
                    f"commitment {commitment.ident} release cites an uncommitted certificate",
                )
        if not commitment.protected_present:
            continue
        if commitment.effective_version > commitment.version:
            record_invariant_violation(
                policy,
                result,
                "version_violations",
                f"commitment {commitment.ident} effective version exceeds candidate version",
            )
        for lifecycle_event in commitment.lifecycle_events:
            if lifecycle_event.get("transition") != "degrade":
                continue
            edge_values = (
                str(lifecycle_event.get("from_guarantee")),
                str(lifecycle_event.get("to_guarantee")),
            )
            certificate_version = int(lifecycle_event.get("certificate_version", 0))
            metadata = commitment.certificate_metadata.get(certificate_version, {})
            if (
                edge_values not in commitment.authorized_degradation_edges
                or metadata.get("transition_type") != "policy_degradation"
            ):
                record_invariant_violation(
                    policy,
                    result,
                    "illegal_degradation_violations",
                    f"commitment {commitment.ident} degradation lacks contract authorization",
                )
        if commitment.status == STATUS_RUPTURED and commitment.physical_live:
            for robot_id, amount_at_rupture in commitment.rupture_backing_snapshot.items():
                if 0 <= robot_id < len(robots) and robots[robot_id].active:
                    retained = commitment.reserved.get(robot_id, 0.0)
                    mirrored = robots[robot_id].reserved.get(commitment.ident, 0.0)
                    consumed_pending = commitment.pending_consumed_backing.get(robot_id, 0.0)
                    if retained + 1e-9 < amount_at_rupture or mirrored + consumed_pending + 1e-9 < amount_at_rupture:
                        record_invariant_violation(
                            policy,
                            result,
                            "release_violations",
                            f"commitment {commitment.ident} reused valid backing after rupture",
                        )
        if commitment.status == STATUS_AT_RISK and (
            commitment.physical_live or commitment.certificate_update_uncertain
        ):
            for robot_id, amount_at_risk in commitment.at_risk_backing_snapshot.items():
                if 0 <= robot_id < len(robots) and robots[robot_id].active:
                    retained = commitment.reserved.get(robot_id, 0.0)
                    mirrored = robots[robot_id].reserved.get(commitment.ident, 0.0)
                    consumed_pending = commitment.pending_consumed_backing.get(robot_id, 0.0)
                    if retained + 1e-9 < amount_at_risk or mirrored + consumed_pending + 1e-9 < amount_at_risk:
                        record_invariant_violation(
                            policy,
                            result,
                            "release_violations",
                            f"commitment {commitment.ident} reused valid backing while at risk",
                        )
        if commitment.status not in ACTIVE_STATUSES:
            if commitment.status not in {STATUS_FORGOTTEN, STATUS_RUPTURED, STATUS_DISCHARGED}:
                if caps(policy).has_at_risk_state:
                    record_invariant_violation(policy, result, "release_violations", f"inactive commitment {commitment.ident} remains in live list")
                else:
                    result.release_violations += 1
                    result.invariant_violations += 1
            if commitment.status == STATUS_RUPTURED and not commitment.physical_live:
                record_invariant_violation(
                    policy,
                    result,
                    "release_violations",
                    f"commitment {commitment.ident} rupture silently cleared physical liability",
                )
            continue
        if caps(policy).has_monotonic_version:
            remember_version(policy, commitment, result)
        for version, snapshot in commitment.certificate_history.items():
            expected = commitment.version_state_hashes.get(version)
            if expected is not None and expected != snapshot_hash(snapshot):
                record_invariant_violation(policy, result, "certificate_hash_violations", f"commitment {commitment.ident} version {version} hash mismatch")
        check_contract_claim(commitment, result)
        check_forgetting(policy, commitment, robots, result)
        if not commitment.protected_present:
            continue
        if caps(policy).has_commitment_ledger and commitment.status in {STATUS_LIVE, STATUS_DEGRADED}:
            if not is_backed_by_reserved(commitment, robots, use_true=False):
                record_invariant_violation(policy, result, "backing_violations", f"commitment {commitment.ident} lacks modeled backing at {where}")
        if policy != "immediate_only":
            reservation_robots = set(commitment.reserved) | set(commitment.pending_reserved) | set(commitment.pending_consumed_backing)
            reservation_robots.update(
                robot_id for robot_id, robot in enumerate(robots) if commitment.ident in robot.reserved
            )
            for robot_id in reservation_robots:
                if commitment.pending_reserved.get(robot_id, 0.0) < -1e-9 or commitment.pending_consumed_backing.get(robot_id, 0.0) < -1e-9:
                    record_invariant_violation(policy, result, "double_spend_violations", f"negative pending reservation for commitment {commitment.ident}")
                    continue
                expected_lock = expected_physical_lock(commitment, robot_id)
                mirrored = robots[robot_id].reserved.get(commitment.ident, 0.0) if 0 <= robot_id < len(robots) else 0.0
                if abs(mirrored - expected_lock) > 1e-9:
                    record_invariant_violation(
                        policy,
                        result,
                        "double_spend_violations",
                        f"effective plus pending reservation mismatch for commitment {commitment.ident}",
                    )
            if commitment.pending_reserved and not commitment.pending_operation:
                record_invariant_violation(
                    policy,
                    result,
                    "version_violations",
                    f"commitment {commitment.ident} has pending locks without a transaction state",
                )
            has_pending_state = bool(
                commitment.pending_reserved
                or commitment.pending_consumed_backing
                or commitment.pending_operation
            )
            if has_pending_state and commitment.pending_version is None:
                record_invariant_violation(
                    policy,
                    result,
                    "version_violations",
                    f"commitment {commitment.ident} has pending transaction state without a version",
                )
            if commitment.pending_operation.endswith(":post_commit_release"):
                if commitment.pending_version != commitment.effective_version:
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} post-commit release lock is not tied to the effective version",
                    )
            elif has_pending_state and commitment.pending_version is not None:
                if commitment.pending_version <= commitment.effective_version:
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} uncommitted pending state does not identify a successor version",
                    )
            for robot_id, amount in commitment.remote_claims.items():
                if 0 <= robot_id < len(robots) and robots[robot_id].remote_reserved.get(commitment.ident) != amount:
                    record_invariant_violation(policy, result, "double_spend_violations", f"remote claim mismatch for commitment {commitment.ident}")


