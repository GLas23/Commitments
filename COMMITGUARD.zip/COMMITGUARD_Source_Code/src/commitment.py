from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Iterable, Optional

from .models import *

def choose_witnesses(
    prop: Proposal, participants: Iterable[int], robots: list[Robot], params: Params,
    partition: Optional[PartitionState] = None,
) -> set[int]:
    if params.witness_count <= 0:
        return set()
    chosen: list[int] = []
    participant_set = set(participants)
    for robot_id in prop.witness_order:
        if robot_id in participant_set:
            continue
        if (0 <= robot_id < len(robots) and robots[robot_id].active
                and (params.witness_selection_mode == "legacy_active"
                     or same_partition_group(partition, (*participant_set, robot_id)))):
            chosen.append(robot_id)
        if len(chosen) >= params.witness_count:
            break
    return set(chosen)


def certificate_holders(commitment: Commitment) -> set[int]:
    return set(commitment.participants) | set(commitment.witnesses)


def _snapshot_map(value: dict[int, float]) -> dict[str, float]:
    return {str(k): float(v) for k, v in sorted(value.items())}


def _native_snapshot_map(value: object) -> dict[int, float]:
    return {int(k): float(v) for k, v in dict(value).items()}  # type: ignore[arg-type]


def commitment_state_snapshot(
    commitment: Commitment,
    target_state: Optional[dict[str, object]] = None,
) -> dict[str, object]:
    snapshot: dict[str, object] = {
        "ident": commitment.ident,
        "version": commitment.version,
        "carrier": commitment.carrier,
        "support": commitment.support,
        "status": commitment.status,
        "guarantee": commitment.guarantee,
        "claimed_req": _snapshot_map(commitment.claimed_req),
        "true_req": _snapshot_map(commitment.true_req),
        "certified_min_req": _snapshot_map(commitment.certified_min_req),
        "initial_claimed_req": _snapshot_map(commitment.initial_claimed_req),
        "reserved": _snapshot_map(commitment.reserved),
        "physical_live": commitment.physical_live,
        "protected_present": commitment.protected_present,
        "phase_contract_id": commitment.phase_contract_id,
        "physical_stage": commitment.physical_stage,
        "phase_evidence_hash": commitment.phase_evidence_hash,
        "assist_for": commitment.assist_for,
        "physical_object": commitment.physical_object,
        "responsibility_scope": commitment.responsibility_scope,
        "responsibility_units": commitment.responsibility_units,
    }
    for key, value in (target_state or {}).items():
        if key in {"claimed_req", "true_req", "certified_min_req", "initial_claimed_req", "reserved"}:
            snapshot[key] = _snapshot_map({int(k): float(v) for k, v in dict(value).items()})  # type: ignore[arg-type]
        else:
            snapshot[key] = value
    snapshot["version"] = commitment.version
    return snapshot


def apply_effective_snapshot(commitment: Commitment, snapshot: dict[str, object]) -> None:
    """Install only a persisted candidate as the effective logical state."""
    commitment.carrier = int(snapshot["carrier"])
    support = snapshot.get("support")
    commitment.support = None if support is None else int(support)
    commitment.status = str(snapshot["status"])
    commitment.guarantee = str(snapshot["guarantee"])
    commitment.claimed_req = _native_snapshot_map(snapshot["claimed_req"])
    commitment.true_req = _native_snapshot_map(snapshot["true_req"])
    commitment.certified_min_req = _native_snapshot_map(snapshot["certified_min_req"])
    commitment.initial_claimed_req = _native_snapshot_map(snapshot["initial_claimed_req"])
    effective = _native_snapshot_map(snapshot["reserved"])
    commitment.effective_reserved = dict(effective)
    commitment.reserved = dict(effective)
    commitment.physical_live = bool(snapshot.get("physical_live", commitment.physical_live))
    commitment.protected_present = bool(snapshot.get("protected_present", commitment.protected_present))
    commitment.phase_contract_id = str(snapshot.get("phase_contract_id", commitment.phase_contract_id))
    commitment.physical_stage = str(snapshot.get("physical_stage", commitment.physical_stage))
    commitment.phase_evidence_hash = str(snapshot.get("phase_evidence_hash", commitment.phase_evidence_hash))
    commitment.assist_for = snapshot.get("assist_for", commitment.assist_for)
    commitment.physical_object = str(snapshot.get("physical_object", commitment.physical_object))
    commitment.responsibility_scope = str(snapshot.get("responsibility_scope", commitment.responsibility_scope))
    commitment.responsibility_units = float(snapshot.get("responsibility_units", commitment.responsibility_units))


def snapshot_hash(snapshot: dict[str, object]) -> str:
    body = json.dumps(snapshot, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


def configure_certificate_persistence(policy: str, commitment: Commitment, params: Params) -> None:
    if not caps(policy).has_certificate_auth:
        commitment.certificate_fault_tolerance = 0
        commitment.certificate_persistence_threshold = 1
        return
    if caps(policy).has_witness_replication:
        commitment.certificate_fault_tolerance = (
            min(params.witness_count, len(commitment.witnesses))
            if params.diagnostic_legacy_threshold else params.witness_count
        )
    else:
        commitment.certificate_fault_tolerance = 0
    commitment.certificate_persistence_threshold = commitment.certificate_fault_tolerance + 1


def save_version_snapshot(
    commitment: Commitment,
    event: str = "snapshot",
    predecessor: Optional[int] = None,
    resource_changes: Optional[dict[int, float]] = None,
    authorization_reason: str = "",
    target_state: Optional[dict[str, object]] = None,
) -> dict[str, object]:
    predecessor_version = commitment.effective_version if predecessor is None else predecessor
    snapshot = commitment_state_snapshot(commitment, target_state)
    candidate = {
        "version": commitment.version,
        "predecessor": predecessor_version,
        "transition_type": event,
        "state": snapshot,
        "resource_changes": {
            str(robot_id): amount for robot_id, amount in sorted((resource_changes or {}).items())
        },
        "authorization_reason": authorization_reason,
        "responsibility_inheritance": {
            "physical_live": snapshot["physical_live"],
            "carrier": snapshot["carrier"],
            "support": snapshot["support"],
            "guarantee": snapshot["guarantee"],
            "phase_contract_id": snapshot["phase_contract_id"],
            "physical_stage": snapshot["physical_stage"],
            "phase_evidence_hash": snapshot["phase_evidence_hash"],
            "assist_for": snapshot["assist_for"],
            "physical_object": snapshot["physical_object"],
            "responsibility_scope": snapshot["responsibility_scope"],
            "responsibility_units": snapshot["responsibility_units"],
        },
    }
    commitment.certificate_candidates[commitment.version] = candidate
    commitment.certificate_candidate_hashes[commitment.version] = snapshot_hash(candidate)
    return candidate


def promote_certificate_candidate(commitment: Commitment, version: int, acknowledgements: set[int]) -> None:
    candidate = commitment.certificate_candidates[version]
    predecessor = int(candidate["predecessor"])
    snapshot = dict(candidate["state"])
    commitment.certificate_history[version] = snapshot
    commitment.version_state_hashes[version] = snapshot_hash(snapshot)
    commitment.certificate_metadata[version] = {
        key: value for key, value in candidate.items() if key != "state"
    }
    commitment.certificate_successors[predecessor] = version
    commitment.effective_version = version
    commitment.certificate_update_uncertain = False
    commitment.last_certificate_result = "committed"
    apply_effective_snapshot(commitment, snapshot)
    for holder in acknowledgements:
        commitment.certificate_versions[holder] = version


def publish_certificate(
    policy: str, commitment: Commitment, robots: list[Robot], result: PolicyResult,
    partition: Optional[PartitionState] = None,
) -> bool:
    candidate = commitment.certificate_candidates.get(commitment.version)
    if candidate is None:
        candidate = save_version_snapshot(commitment)
    expected_candidate_hash = commitment.certificate_candidate_hashes.get(commitment.version)
    if expected_candidate_hash != snapshot_hash(candidate):
        commitment.certificate_update_uncertain = True
        commitment.last_certificate_result = "rejected"
        result.certificate_hash_violations += 1
        result.uncommitted_certificate_updates += 1
        return False
    if commitment.version == commitment.effective_version:
        return (
            commitment.version_state_hashes.get(commitment.effective_version)
            == snapshot_hash(dict(candidate["state"]))
        )
    predecessor = int(candidate["predecessor"])
    if policy == "central_commit_aware" and predecessor > 0 and not has_latest_certificate(commitment, robots):
        # A global controller cannot authorize a successor from an in-memory
        # certificate whose sole persisted view is no longer available.
        commitment.certificate_update_uncertain = True
        commitment.last_certificate_result = "uncertain"
        result.uncommitted_certificate_updates += 1
        result.certificate_confirmation_blocked += 1
        result.uncertain_commit_blocks += 1
        return False
    existing_successor = commitment.certificate_successors.get(predecessor)
    if existing_successor is not None and existing_successor != commitment.version:
        commitment.certificate_update_uncertain = True
        commitment.last_certificate_result = "rejected"
        result.conflicting_certificate_candidates += 1
        result.uncommitted_certificate_updates += 1
        return False

    if not caps(policy).has_certificate_auth:
        promote_certificate_candidate(commitment, commitment.version, set())
        result.logical_transition_committed += 1
        return True

    candidate_state = dict(candidate["state"])
    candidate_participants = {int(candidate_state["carrier"])}
    if candidate_state.get("support") is not None:
        candidate_participants.add(int(candidate_state["support"]))
    old_state = commitment.certificate_history.get(predecessor, {})
    old_participants: set[int] = set()
    if old_state:
        old_participants.add(int(old_state["carrier"]))
        if old_state.get("support") is not None:
            old_participants.add(int(old_state["support"]))
    transition = str(candidate.get("transition_type", ""))
    if (
        transition == "discharge"
        and commitment.simulation_epoch < commitment.certificate_not_before_epoch
    ):
        commitment.certificate_acknowledgements[commitment.version] = set()
        commitment.certificate_persisted_versions[commitment.version] = set()
        commitment.certificate_update_uncertain = True
        commitment.last_certificate_result = "uncertain"
        result.certificate_candidates_created += 1
        result.uncommitted_certificate_updates += 1
        result.certificate_confirmation_blocked += 1
        result.uncertain_commit_blocks += 1
        result.insufficient_persistence_rejections += 1
        return False
    # Releasing or moving old rights requires the old resource owners' ACKs.
    old_required = old_participants if transition in {"policy_degradation", "discharge"} else set()
    if transition == "handoff":
        old_required = old_participants if commitment.handoff_requires_old_guard else {
            holder for holder in old_participants if 0 <= holder < len(robots) and robots[holder].active
        }
    required = candidate_participants | old_required
    holders = required | set(commitment.witnesses)
    active_partition = partition if partition is not None else commitment.network_partition
    origin = commitment.initiator
    if not (0 <= origin < len(robots) and robots[origin].active):
        origin = next((h for h in sorted(old_participants | set(commitment.witnesses))
                       if 0 <= h < len(robots) and robots[h].active
                       and commitment.certificate_versions.get(h) == predecessor), -1)
    reachable = {
        holder for holder in holders
        if 0 <= holder < len(robots) and robots[holder].active
        and origin >= 0 and same_partition_group(active_partition, (origin, holder))
        and holder not in commitment.certificate_message_drops
    }
    # A signed Retire ACK for this exact immutable candidate remains valid when
    # its owner subsequently crashes. Persistence still requires live reachable
    # holders, so a stale ACK cannot manufacture a quorum.
    prior_acks = (
        commitment.certificate_acknowledgements.get(commitment.version, set())
        if transition == "discharge" and commitment.retire_recovery_enabled else set()
    )
    acknowledgements = reachable | prior_acks
    persisted = reachable if required.issubset(acknowledgements) else set()
    commitment.certificate_acknowledgements[commitment.version] = set(acknowledgements)
    commitment.certificate_persisted_versions[commitment.version] = set(persisted)
    result.certificate_message_ops += len(holders)
    result.witness_copies_created += len(persisted)
    result.certificate_candidates_created += 1
    participants_confirmed = required.issubset(acknowledgements)
    persistence_confirmed = len(persisted) >= commitment.certificate_persistence_threshold
    if not participants_confirmed or not persistence_confirmed:
        commitment.certificate_update_uncertain = True
        commitment.last_certificate_result = "uncertain"
        result.uncommitted_certificate_updates += 1
        result.certificate_confirmation_blocked += 1
        result.uncertain_commit_blocks += 1
        if not persistence_confirmed:
            result.insufficient_persistence_rejections += 1
            if active_partition is not None and any(
                0 <= holder < len(robots) and robots[holder].active
                and origin >= 0 and not same_partition_group(active_partition, (origin, holder))
                for holder in holders
            ):
                result.witness_unreachable_rejections += 1
        return False

    promote_certificate_candidate(commitment, commitment.version, persisted)
    result.certificate_candidates_committed += 1
    result.logical_transition_committed += 1
    return True


def has_latest_certificate(commitment: Commitment, robots: list[Robot]) -> bool:
    effective = commitment.effective_version
    if effective <= 0 or effective not in commitment.certificate_history:
        return False
    snapshot = commitment.certificate_history[effective]
    if commitment.version_state_hashes.get(effective) != snapshot_hash(snapshot):
        return False
    if effective not in commitment.certificate_metadata:
        return False
    persisted = commitment.certificate_persisted_versions.get(effective, set())
    return any(
        commitment.certificate_versions.get(holder) == effective
        and 0 <= holder < len(robots) and robots[holder].active
        for holder in persisted
    )


def record_version(
    policy: str,
    commitment: Commitment,
    result: PolicyResult,
    robots: list[Robot],
    event: str,
    resource_changes: Optional[dict[int, float]] = None,
    authorization_reason: str = "",
    target_state: Optional[dict[str, object]] = None,
    partition: Optional[PartitionState] = None,
) -> bool:
    if not caps(policy).has_commitment_ledger:
        return True
    pending_operation_before = commitment.pending_operation
    pending_version_before = commitment.pending_version
    old_candidate = commitment.version
    predecessor = commitment.effective_version
    commitment.version = max(commitment.version, commitment.effective_version) + 1
    if commitment.version <= old_candidate:
        result.version_violations += 1
        result.invariant_violations += 1
    save_version_snapshot(
        commitment,
        event=event,
        predecessor=predecessor,
        resource_changes=resource_changes,
        authorization_reason=authorization_reason,
        target_state=target_state,
    )
    committed = publish_certificate(policy, commitment, robots, result, partition)
    if committed and pending_version_before is not None:
        matching_prepare = {
            "mint": "mint:prepare",
            "top_up": "top_up:prepare",
            "handoff": "handoff:prepare",
        }.get(event)
        superseded_prepare = (
            pending_operation_before.endswith(":prepare")
            and pending_operation_before != matching_prepare
            and pending_version_before != commitment.effective_version
            and not commitment.pending_consumed_backing
        )
        if superseded_prepare:
            # A different successor of the old effective certificate has now
            # committed.  The losing prepare never crossed the physical commit
            # point and can no longer become effective, so its provisional lock
            # is safe to roll back.  Uncertain consumed backing is deliberately
            # excluded because it may already encode physical consequences.
            rollback_pending_reservation(commitment, robots, result)
    return committed


def record_invariant_violation(policy: str, result: PolicyResult, field_name: str, message: str) -> None:
    setattr(result, field_name, getattr(result, field_name) + 1)
    result.invariant_violations += 1
    if strict_invariant_enforced(policy):
        raise AssertionError(f"COMMIT GUARD invariant violation: {field_name}: {message}")


def remember_version(policy: str, commitment: Commitment, result: PolicyResult) -> None:
    observed_version = commitment.effective_version if caps(policy).has_certificate_auth else commitment.version
    previous = result.max_version_seen.get(commitment.ident, 0)
    if observed_version < previous:
        record_invariant_violation(policy, result, "version_violations", f"commitment {commitment.ident} regressed from {previous} to {observed_version}")
    else:
        result.max_version_seen[commitment.ident] = observed_version


def mark_missed(result: PolicyResult, field_name: str) -> None:
    setattr(result, field_name, getattr(result, field_name) + 1)
    result.missed += 1


def mark_blocked(result: PolicyResult) -> None:
    result.blocked += 1


def expected_physical_lock(commitment: Commitment, robot_id: int) -> float:
    return max(
        0.0,
        commitment.reserved.get(robot_id, 0.0)
        + commitment.pending_reserved.get(robot_id, 0.0)
        - commitment.pending_consumed_backing.get(robot_id, 0.0),
    )


def sync_robot_lock(commitment: Commitment, robots: list[Robot], robot_id: int) -> None:
    if not (0 <= robot_id < len(robots)):
        return
    amount = expected_physical_lock(commitment, robot_id)
    if amount > 1e-9:
        robots[robot_id].reserved[commitment.ident] = amount
    else:
        robots[robot_id].reserved.pop(commitment.ident, None)


def sync_all_robot_locks(commitment: Commitment, robots: list[Robot]) -> None:
    robot_ids = set(commitment.reserved) | set(commitment.pending_reserved) | set(commitment.pending_consumed_backing)
    robot_ids.update(i for i, robot in enumerate(robots) if commitment.ident in robot.reserved)
    for robot_id in robot_ids:
        sync_robot_lock(commitment, robots, robot_id)


def reserve_amounts(commitment: Commitment, robots: list[Robot]) -> None:
    sync_all_robot_locks(commitment, robots)


def stage_pending_reservation(
    commitment: Commitment,
    robots: list[Robot],
    target_reserved: dict[int, float],
    operation: str,
) -> None:
    """Lock additions without changing the effective logical allocation."""
    for robot_id in set(commitment.reserved) | set(target_reserved):
        extra = max(0.0, target_reserved.get(robot_id, 0.0) - commitment.reserved.get(robot_id, 0.0))
        if extra > 1e-9:
            commitment.pending_reserved[robot_id] = extra
        elif commitment.pending_operation == operation:
            commitment.pending_reserved.pop(robot_id, None)
    commitment.pending_operation = operation
    commitment.pending_version = commitment.version + 1
    sync_all_robot_locks(commitment, robots)


def rollback_pending_reservation(commitment: Commitment, robots: list[Robot], result: PolicyResult) -> None:
    if commitment.pending_reserved or commitment.pending_consumed_backing:
        result.pending_reservation_rollbacks += 1
    commitment.pending_reserved.clear()
    commitment.pending_consumed_backing.clear()
    commitment.pending_operation = ""
    commitment.pending_version = None
    sync_all_robot_locks(commitment, robots)


def reconcile_committed_reservation(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    physical_before_commit: dict[int, float],
    operation: str,
) -> None:
    """Convert additions to effective rights and retain removals as conservative locks."""
    commitment.pending_reserved.clear()
    commitment.pending_consumed_backing.clear()
    for robot_id in set(physical_before_commit) | set(commitment.reserved):
        surplus = max(0.0, physical_before_commit.get(robot_id, 0.0) - commitment.reserved.get(robot_id, 0.0))
        if surplus > 1e-9:
            commitment.pending_reserved[robot_id] = surplus
    commitment.pending_operation = f"{operation}:post_commit_release" if commitment.pending_reserved else ""
    commitment.pending_version = commitment.effective_version if commitment.pending_reserved else None
    result.pending_reservation_promotions += 1
    sync_all_robot_locks(commitment, robots)


def release_pending_locks(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    reason: str,
) -> dict[int, float]:
    expected_transition = {
        "authorized_degradation": "policy_degradation",
        "handoff_replaced": "handoff",
    }.get(reason)
    metadata = commitment.certificate_metadata.get(commitment.effective_version, {})
    expected_operation = (
        f"{expected_transition}:post_commit_release" if expected_transition is not None else ""
    )
    if reason == "handoff_replaced" and commitment.handoff_requires_old_guard:
        old_owners = {
            int(robot_id) for robot_id, delta in dict(metadata.get("resource_changes", {})).items()
            if float(delta) < -1e-9
        }
        if not old_owners.issubset(
            commitment.certificate_acknowledgements.get(commitment.effective_version, set())
        ):
            result.release_after_commit_failures += 1
            return {}
    if (
        expected_transition is None
        or metadata.get("transition_type") != expected_transition
        or commitment.pending_version != commitment.effective_version
        or commitment.pending_operation != expected_operation
    ):
        if metadata.get("transition_type") == expected_transition:
            result.release_after_commit_failures += 1
        return {}
    released = dict(commitment.pending_reserved)
    for amount in released.values():
        result.reserved_backing_released_unused += max(0.0, amount)
    commitment.pending_reserved.clear()
    commitment.pending_operation = ""
    commitment.pending_version = None
    sync_all_robot_locks(commitment, robots)
    active_release = sum(
        amount for robot_id, amount in released.items()
        if 0 <= robot_id < len(robots) and robots[robot_id].active
    )
    unavailable = sum(released.values()) - active_release
    if active_release > 1e-9:
        result.old_resource_release_executed += 1
    result.retained_unavailable_resources += max(0.0, unavailable)
    return released


def physical_reservation_map(commitment: Commitment) -> dict[int, float]:
    robot_ids = set(commitment.reserved) | set(commitment.pending_reserved) | set(commitment.pending_consumed_backing)
    return {robot_id: expected_physical_lock(commitment, robot_id) for robot_id in robot_ids if expected_physical_lock(commitment, robot_id) > 1e-9}


def record_reservation_release_accounting(
    commitment: Commitment,
    result: PolicyResult,
    used_by_commitment: Optional[dict[int, float]] = None,
    count_discharge_waste: bool = False,
) -> None:
    if not commitment.reserved:
        return
    consumed = 0.0
    released_unused = 0.0
    used = used_by_commitment or {}
    for robot_id, reserved_amount in commitment.reserved.items():
        used_amount = min(max(0.0, used.get(robot_id, 0.0)), max(0.0, reserved_amount))
        consumed += used_amount
        released_unused += max(0.0, reserved_amount - used_amount)
    result.reserved_backing_consumed += consumed
    result.reserved_backing_released_unused += released_unused
    if count_discharge_waste:
        result.wasted_reserve_at_discharge += released_unused


def consume_reserved_backing_pending_certificate(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    used_by_commitment: Optional[dict[int, float]],
) -> None:
    """Retire physically consumed backing without treating it as reusable capacity."""
    for robot_id, used_amount in (used_by_commitment or {}).items():
        current = max(0.0, commitment.reserved.get(robot_id, 0.0))
        already_consumed = max(0.0, commitment.pending_consumed_backing.get(robot_id, 0.0))
        consumed = min(max(0.0, current - already_consumed), max(0.0, used_amount))
        if consumed <= 1e-9:
            continue
        result.reserved_backing_consumed += consumed
        commitment.pending_consumed_backing[robot_id] = already_consumed + consumed
        commitment.pending_operation = "discharge:certificate_uncertain"
        commitment.pending_version = commitment.version
        sync_robot_lock(commitment, robots, robot_id)


def release_one_reservation(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    robot_id: int,
) -> float:
    amount = max(0.0, commitment.reserved.get(robot_id, 0.0))
    if amount > 1e-9:
        result.reserved_backing_released_unused += amount
    if 0 <= robot_id < len(robots):
        robots[robot_id].reserved.pop(commitment.ident, None)
    commitment.reserved.pop(robot_id, None)
    commitment.effective_reserved.pop(robot_id, None)
    commitment.pending_reserved.pop(robot_id, None)
    commitment.pending_consumed_backing.pop(robot_id, None)
    return amount


def release_remote_claims(commitment: Commitment, robots: list[Robot]) -> None:
    for robot_id in list(commitment.remote_claims):
        if 0 <= robot_id < len(robots):
            robots[robot_id].remote_reserved.pop(commitment.ident, None)
    commitment.remote_claims.clear()


def release_reservations(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    policy: str,
    reason: str,
    used_by_commitment: Optional[dict[int, float]] = None,
) -> bool:
    physical_reservations = physical_reservation_map(commitment)
    release_amount = sum(max(0.0, amount) for amount in physical_reservations.values())
    metadata = commitment.certificate_metadata.get(commitment.effective_version, {})
    transition_type = metadata.get("transition_type", "")
    authorized = False
    if reason == "precommit_abort":
        authorized = not commitment.physical_live and commitment.effective_version == 0
    elif reason == "discharge":
        authorized = (
            not commitment.physical_live
            and commitment.discharge_evidence_validated
            and (not caps(policy).has_certificate_auth or transition_type == "discharge")
        )
    elif reason == "terminal_policy_disposition":
        authorized = (
            not commitment.physical_live
            and commitment.terminal_disposition_authorized
            and (not caps(policy).has_certificate_auth or transition_type == "terminal_policy_disposition")
        )
    elif reason == "handoff_replaced":
        authorized = transition_type == "handoff" and commitment.effective_version > 0
    elif not lifecycle_protected(policy):
        authorized = reason in LEGAL_RELEASE_REASONS or reason in {
            "unsafe_cancel",
            "unsafe_failure",
            "deadline_failure",
            "trace_end_cleanup",
        }

    commitment.release_events.append(
        {
            "reason": reason,
            "authorized": authorized,
            "amount": release_amount,
            "effective_version": commitment.effective_version,
            "physical_live": commitment.physical_live,
            "evidence_validated": commitment.discharge_evidence_validated,
            "terminal_disposition_authorized": commitment.terminal_disposition_authorized,
            "executed": authorized or not lifecycle_protected(policy),
        }
    )
    if lifecycle_protected(policy) and not authorized:
        if commitment.status == STATUS_RUPTURED or commitment.physical_live:
            result.illegal_rupture_release_violations += 1
        return False
    consumed = 0.0
    released_unused = 0.0
    used = used_by_commitment or {}
    for robot_id, amount in physical_reservations.items():
        used_amount = min(max(0.0, used.get(robot_id, 0.0)), amount)
        consumed += used_amount
        released_unused += max(0.0, amount - used_amount)
    result.reserved_backing_consumed += consumed
    result.reserved_backing_released_unused += released_unused
    if reason == "discharge":
        result.wasted_reserve_at_discharge += released_unused
    active_release = sum(
        amount for robot_id, amount in physical_reservations.items()
        if 0 <= robot_id < len(robots) and robots[robot_id].active
    )
    unavailable = release_amount - active_release
    if active_release > 1e-9:
        result.old_resource_release_executed += 1
    result.retained_unavailable_resources += max(0.0, unavailable)
    for robot_id in set(commitment.reserved) | set(commitment.pending_reserved) | set(commitment.pending_consumed_backing):
        if 0 <= robot_id < len(robots):
            robots[robot_id].reserved.pop(commitment.ident, None)
    commitment.reserved.clear()
    commitment.effective_reserved.clear()
    commitment.pending_reserved.clear()
    commitment.pending_consumed_backing.clear()
    commitment.pending_operation = ""
    commitment.pending_version = None
    release_remote_claims(commitment, robots)
    return True


def self_snapshot(robots: list[Robot], robot_ids: Iterable[int]) -> dict[int, str]:
    return {r: robots[r].self_level for r in set(robot_ids) if 0 <= r < len(robots)}


def restore_self_snapshot(robots: list[Robot], snapshot: dict[int, str]) -> None:
    for robot_id, level in snapshot.items():
        robots[robot_id].self_level = level


def degrade_robot_one_step(robot_id: int, robots: list[Robot], result: PolicyResult) -> Optional[DegradationTransition]:
    robot = robots[robot_id]
    if not robot.active:
        return None
    next_level = ALLOWED_SELF_DEGRADATION.get(robot.self_level)
    if next_level is None:
        return None
    transition = DegradationTransition(robot=robot_id, before=robot.self_level, after=next_level)
    robot.self_level = next_level
    result.self_recovery_degradation_events += 1
    if transition.before == SELF_RETURN and transition.after == SELF_SAFE_HALT:
        result.return_to_safe_halt += 1
    elif transition.before == SELF_SAFE_HALT and transition.after == SELF_STRANDED:
        result.safe_halt_to_stranded += 1
    return transition


def degrade_self_to_cover(
    robots: list[Robot],
    req: dict[int, float],
    carrier: Optional[int],
    immediate_cost: float,
    criticality: int,
    allow: bool,
    result: PolicyResult,
) -> list[DegradationTransition]:
    if not allow or criticality < 1:
        return []
    planned: list[DegradationTransition] = []
    for robot_id, amount in req.items():
        if robot_id < 0 or robot_id >= len(robots) or not robots[robot_id].active:
            return []
        extra = immediate_cost if carrier is not None and robot_id == carrier else 0.0
        robot = robots[robot_id]
        level = robot.self_level
        projected_free = robot.energy - robot.self_base * SELF_FRACTION[level] - robot.total_reserved
        while projected_free + 1e-9 < amount + extra:
            next_level = ALLOWED_SELF_DEGRADATION.get(level)
            if next_level is None:
                return []
            planned.append(DegradationTransition(robot=robot_id, before=level, after=next_level))
            level = next_level
            projected_free = robot.energy - robot.self_base * SELF_FRACTION[level] - robot.total_reserved

    transitions: list[DegradationTransition] = []
    for planned_transition in planned:
        if robots[planned_transition.robot].self_level != planned_transition.before:
            return []
        transition = degrade_robot_one_step(planned_transition.robot, robots, result)
        if transition is None or transition.after != planned_transition.after:
            return []
        transitions.append(transition)
    return transitions


def static_reservation_from_initial(claimed_req: dict[int, float], params: Params) -> dict[int, float]:
    return {robot_id: amount * params.static_worst_case_multiplier for robot_id, amount in claimed_req.items()}


def spend_energy(robots: list[Robot], robot_id: int, amount: float, result: PolicyResult) -> None:
    robots[robot_id].energy -= amount
    result.energy_consumed += amount


def record_terminal(commitment: Commitment, result: PolicyResult, epoch: Optional[int] = None) -> None:
    result.terminal_commitments += 1
    terminal_epoch = commitment.due_epoch if epoch is None else epoch
    result.total_commitment_lifetime += max(0, terminal_epoch - commitment.created_epoch)


def create_commitment(
    policy: str,
    prop: Proposal,
    robots: list[Robot],
    result: PolicyResult,
    params: Params,
    partition: Optional[PartitionState] = None,
    phase_contract_id: str = "",
    assist_for: Optional[int] = None,
) -> Optional[Commitment]:
    initial_bound = claimed_requirement(prop)
    initial_true = true_requirement(prop)
    certified_min_req = certified_minimum_requirement(prop, params)
    enforced_req = enforced_requirement(policy, prop, params)
    reservation_req = static_reservation_from_initial(initial_bound, params) if caps(policy).uses_static_worst_case else dict(enforced_req)
    allow_degrade = caps(policy).has_policy_degradation and params.medium_high_degrade_self_recovery
    snapshot = self_snapshot(robots, reservation_req)
    before_self_degradation_events = result.self_recovery_degradation_events
    before_return_to_safe_halt = result.return_to_safe_halt
    before_safe_halt_to_stranded = result.safe_halt_to_stranded
    total_immediate = prop.immediate_cost + prop.precommit_preparation_cost
    transitions = degrade_self_to_cover(robots, reservation_req, prop.carrier, total_immediate, prop.criticality, allow_degrade, result)

    if not can_cover(robots, reservation_req, carrier=prop.carrier, immediate_cost=total_immediate):
        restore_self_snapshot(robots, snapshot)
        result.self_recovery_degradation_events = before_self_degradation_events
        result.return_to_safe_halt = before_return_to_safe_halt
        result.safe_halt_to_stranded = before_safe_halt_to_stranded
        return None

    transactional_mint = caps(policy).has_certificate_auth
    deferred_action = transactional_mint and params.mint_deferred_execution
    if prop.precommit_preparation_cost > 0:
        spend_energy(robots, prop.carrier, prop.precommit_preparation_cost, result)
        result.mint_precommit_execution_cost += prop.precommit_preparation_cost
    if not deferred_action:
        spend_energy(robots, prop.carrier, prop.immediate_cost, result)
    else:
        # This is a temporary physical lock, distinct from the candidate's
        # future-liability backing and from the effective certificate ledger.
        robots[prop.carrier].pending_execution_cost[prop.ident] = prop.immediate_cost
    commitment = Commitment(
        ident=prop.ident,
        proposal=prop,
        initiator=prop.carrier,
        carrier=prop.carrier,
        support=prop.support,
        criticality=prop.criticality,
        created_epoch=prop.epoch,
        due_epoch=prop.due_epoch,
        finish_epoch=prop.finish_epoch,
        claimed_req=dict(initial_bound),
        true_req=dict(initial_true),
        certified_min_req=dict(certified_min_req),
        initial_claimed_req=dict(initial_bound),
        reserved={} if transactional_mint else dict(reservation_req),
        effective_reserved={} if transactional_mint else dict(reservation_req),
        pending_reserved=dict(reservation_req) if transactional_mint else {},
        pending_operation="mint:prepare" if transactional_mint else "",
        status=STATUS_LIVE,
        guarantee="full",
        contract_guarantee_requirements={"full": dict(initial_bound)},
        network_partition=partition,
        phase_contract_id=phase_contract_id,
        assist_for=assist_for,
        retire_recovery_enabled=params.retire_recovery_enabled,
        simulation_epoch=prop.epoch,
        certificate_ack_delay_epochs=params.certificate_ack_delay_epochs,
        retire_recovery_wait_epochs=params.retire_recovery_wait_epochs,
    )
    reserve_amounts(commitment, robots)
    if caps(policy).has_witness_replication:
        commitment.witnesses = choose_witnesses(prop, commitment.participants, robots, params, partition)
    configure_certificate_persistence(policy, commitment, params)
    if caps(policy).has_commitment_ledger:
        save_version_snapshot(
            commitment,
            event="mint",
            predecessor=0,
            resource_changes=dict(reservation_req),
            authorization_reason="admission_check_passed",
            target_state={"reserved": dict(reservation_req)},
        )
    if not publish_certificate(policy, commitment, robots, result):
        robots[prop.carrier].pending_execution_cost.pop(prop.ident, None)
        commitment.physical_live = False
        release_reservations(commitment, robots, result, policy, "precommit_abort")
        if prop.precommit_preparation_cost > 0:
            result.mint_aborted_after_cost += 1
        if deferred_action:
            restore_self_snapshot(robots, snapshot)
            result.self_recovery_degradation_events = before_self_degradation_events
            result.return_to_safe_halt = before_return_to_safe_halt
            result.safe_halt_to_stranded = before_safe_halt_to_stranded
        return None
    if transactional_mint:
        physical_before_commit = dict(reservation_req)
        reconcile_committed_reservation(
            commitment, robots, result, physical_before_commit, "mint"
        )
    if deferred_action:
        robots[prop.carrier].pending_execution_cost.pop(prop.ident, None)
        if not prop.physical_execution_success:
            result.mint_execution_failures_after_certificate += 1
            commitment.physical_live = False
            transition_at_risk(commitment, robots, result, policy, "mint_execution_failed_after_certificate")
            return commitment
        spend_energy(robots, prop.carrier, prop.immediate_cost, result)
    record_minimum_backing_mint(policy, prop, commitment, result, params)
    if params.contract_degradation_enabled and caps(policy).has_policy_degradation:
        target_requirement = {
            commitment.carrier: params.contract_degraded_carrier_requirement,
        }
        if commitment.support is not None:
            target_requirement[commitment.support] = params.contract_degraded_support_requirement
        if all(
            0.0 <= target_requirement[robot_id] <= commitment.claimed_req.get(robot_id, -1.0) + 1e-9
            for robot_id in target_requirement
        ):
            configure_contract_degradation(
                commitment,
                "full",
                "reduced_settlement",
                target_requirement,
            )
    return commitment


def transition_at_risk(commitment: Commitment, robots: list[Robot], result: PolicyResult, policy: str, reason: str) -> None:
    if commitment.status == STATUS_AT_RISK:
        return
    if not caps(policy).has_at_risk_state:
        commitment.status = STATUS_RUPTURED
        commitment.at_risk_reason = f"no_at_risk_state:{reason}"
        result.ruptures += 1
        result.commitment_loss += 1
        result.silent_unbacking += 1
        record_rupture_residual(commitment, result, robots)
        release_reservations(commitment, robots, result, policy, "terminal_policy_disposition")
        commitment.physical_live = True
        record_terminal(commitment, result)
        return
    commitment.status = STATUS_AT_RISK
    commitment.at_risk_reason = reason
    commitment.at_risk_backing_snapshot = dict(commitment.reserved)
    result.at_risk += 1
    commitment.lifecycle_events.append(
        {"transition": "at_risk", "reason": reason, "from_guarantee": commitment.guarantee}
    )
    record_version(policy, commitment, result, robots, "at_risk", authorization_reason=reason)


def record_rupture_residual(commitment: Commitment, result: PolicyResult, robots: Optional[list[Robot]] = None) -> None:
    if not commitment.physical_live or commitment.rupture_residual_recorded:
        return
    residual = sum(max(0.0, amount) for amount in commitment.true_req.values())
    lost_capacity = 0.0
    locked_backing = 0.0
    if robots is not None:
        for robot_id, amount in commitment.reserved.items():
            if 0 <= robot_id < len(robots) and robots[robot_id].active:
                locked_backing += max(0.0, amount)
            else:
                already_recorded = commitment.lost_physical_backing.get(robot_id, 0.0)
                lost_capacity += max(0.0, amount - already_recorded)
                commitment.lost_physical_backing[robot_id] = max(already_recorded, max(0.0, amount))
    result.residual_after_rupture += 1
    result.ruptured_physical_liability += residual
    result.lost_physical_capacity += lost_capacity
    result.ruptured_locked_backing += locked_backing
    commitment.rupture_residual_recorded = True


def transition_rupture(commitment: Commitment, robots: list[Robot], result: PolicyResult, policy: str, reason: str) -> None:
    if commitment.status == STATUS_RUPTURED:
        return
    commitment.status = STATUS_RUPTURED
    commitment.at_risk_reason = reason
    result.ruptures += 1
    commitment.physical_live = True
    commitment.rupture_backing_snapshot = dict(commitment.reserved)
    commitment.lifecycle_events.append(
        {"transition": "rupture", "reason": reason, "residual_retained": True}
    )
    record_version(policy, commitment, result, robots, "rupture", authorization_reason=reason)
    record_rupture_residual(commitment, result, robots)
    record_terminal(commitment, result)


def transition_discharge(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    policy: str,
    used_by_commitment: Optional[dict[int, float]] = None,
    epoch: Optional[int] = None,
) -> bool:
    previous_status = commitment.status
    if epoch is not None:
        commitment.simulation_epoch = epoch
        commitment.certificate_not_before_epoch = max(
            commitment.certificate_not_before_epoch,
            epoch + commitment.certificate_ack_delay_epochs,
        )
    commitment.discharge_evidence_validated = True
    old_reserved = dict(commitment.reserved)
    physical_before_commit = {
        robot_id: robots[robot_id].reserved.get(commitment.ident, 0.0)
        for robot_id in range(len(robots))
        if commitment.ident in robots[robot_id].reserved
    }
    resource_changes = {
        robot_id: -amount for robot_id, amount in commitment.reserved.items()
    }
    committed = record_version(
        policy,
        commitment,
        result,
        robots,
        "discharge",
        resource_changes=resource_changes,
        authorization_reason="validated_physical_discharge_evidence",
        target_state={
            "status": STATUS_DISCHARGED,
            "physical_live": False,
            "reserved": {},
        },
    )
    if not committed:
        commitment.status = STATUS_AT_RISK if caps(policy).has_at_risk_state else previous_status
        commitment.physical_live = False
        commitment.at_risk_reason = "discharge_certificate_unconfirmed"
        if commitment.retire_pending_since is None:
            commitment.retire_pending_since = epoch
            result.retire_pending += 1
        consume_reserved_backing_pending_certificate(
            commitment, robots, result, used_by_commitment
        )
        commitment.at_risk_backing_snapshot = dict(commitment.reserved)
        result.at_risk += 1
        return False
    reconcile_committed_reservation(
        commitment, robots, result, physical_before_commit, "discharge"
    )
    result.discharges += 1
    if not commitment.retire_committed_recorded:
        commitment.retire_committed_recorded = True
        if caps(policy).has_certificate_auth:
            result.retire_certificate_committed += 1
    commitment.lifecycle_events.append(
        {"transition": "discharge", "reason": "validated_physical_discharge_evidence"}
    )
    if not release_reservations(commitment, robots, result, policy, "discharge", used_by_commitment=used_by_commitment):
        return False
    record_terminal(commitment, result)
    return True


def recover_pending_retire(
    policy: str, commitment: Commitment, partition: Optional[PartitionState],
    robots: list[Robot], result: PolicyResult, epoch: int,
) -> bool:
    """Retry an already evidenced Retire without replaying the physical action."""
    if not (commitment.retire_recovery_enabled and commitment.physical_execution_completed
            and commitment.discharge_evidence_validated
            and commitment.at_risk_reason == "discharge_certificate_unconfirmed"
            and not commitment.retire_committed_recorded):
        return False
    if (
        commitment.retire_pending_since is not None
        and epoch < commitment.retire_pending_since + commitment.retire_recovery_wait_epochs
    ):
        return False
    commitment.simulation_epoch = epoch
    physical_before_commit = physical_reservation_map(commitment)
    predecessor = commitment.effective_version
    candidate_versions = sorted(
        version for version, candidate in commitment.certificate_candidates.items()
        if candidate.get("transition_type") == "discharge"
        and int(candidate.get("predecessor", -1)) == predecessor
        and commitment.certificate_candidate_hashes.get(version) == snapshot_hash(candidate)
    )
    if candidate_versions:
        commitment.version = candidate_versions[-1]
        committed = publish_certificate(policy, commitment, robots, result, partition)
    elif predecessor not in commitment.certificate_successors:
        committed = record_version(
            policy, commitment, result, robots, "discharge",
            resource_changes={robot_id: -amount for robot_id, amount in commitment.reserved.items()},
            authorization_reason="retry_validated_physical_discharge_evidence",
            target_state={"status": STATUS_DISCHARGED, "physical_live": False, "reserved": {}},
            partition=partition,
        )
    else:
        return False
    if not committed:
        return False
    # The already-spent portion was accounted when the first Retire failed.
    # Only the remaining physical lock is now released as unused backing.
    reconcile_committed_reservation(commitment, robots, result, physical_before_commit, "discharge")
    if not release_reservations(commitment, robots, result, policy, "discharge"):
        return False
    commitment.retire_committed_recorded = True
    result.retire_certificate_committed += 1
    result.retire_recovered += 1
    result.discharges += 1
    result.at_risk_resolved += 1
    if not commitment.rescued_recorded:
        commitment.rescued_recorded = True
        result.rescued += 1
        if commitment.proposal.adversarial:
            result.adversarial_success += 1
    commitment.lifecycle_events.append({
        "transition": "retire_recovered", "epoch": epoch,
        "physical_completion_epoch": commitment.physical_completion_epoch,
        "certificate_version": commitment.effective_version,
    })
    record_terminal(commitment, result, epoch)
    return True


def apply_inflation(
    policy: str,
    commitment: Commitment,
    live: list[Commitment],
    robots: list[Robot],
    partition: Optional[PartitionState],
    result: PolicyResult,
    multiplier: float,
    params: Params,
) -> None:
    for robot_id in list(commitment.claimed_req):
        commitment.claimed_req[robot_id] *= multiplier
    for robot_id in list(commitment.true_req):
        commitment.true_req[robot_id] *= multiplier

    if policy == "immediate_only":
        return

    if policy == "static_worst_case":
        if not is_backed_by_reserved(commitment, robots, use_true=False):
            transition_at_risk(commitment, robots, result, policy, "static_envelope_exceeded")
        return

    attempt_top_up(policy, commitment, live, robots, partition, result, params, reason="inflation")


def is_backed_by_reserved(commitment: Commitment, robots: list[Robot], use_true: bool) -> bool:
    req = commitment.true_req if use_true else commitment.claimed_req
    for robot_id, amount in req.items():
        if robot_id < 0 or robot_id >= len(robots) or not robots[robot_id].active:
            return False
        if commitment.reserved.get(robot_id, 0.0) + 1e-9 < amount:
            return False
    return True


def reserve_delta_to_bound(
    policy: str,
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    params: Params,
) -> bool:
    transactional = caps(policy).has_certificate_auth
    current_physical = {
        robot_id: expected_physical_lock(commitment, robot_id)
        for robot_id in set(commitment.reserved) | set(commitment.pending_reserved) | set(commitment.claimed_req)
    }
    deltas = {
        robot_id: max(0.0, amount - current_physical.get(robot_id, 0.0))
        for robot_id, amount in commitment.claimed_req.items()
    }
    snapshot = self_snapshot(robots, deltas)
    before_self_degradations = result.self_recovery_degradation_events
    before_return_to_safe_halt = result.return_to_safe_halt
    before_safe_halt_to_stranded = result.safe_halt_to_stranded
    allow_degrade = caps(policy).has_policy_degradation and params.medium_high_degrade_self_recovery
    transitions = degrade_self_to_cover(robots, deltas, None, 0.0, commitment.criticality, allow_degrade, result)
    if not all(robots[r].active and robots[r].free + 1e-9 >= delta for r, delta in deltas.items()):
        restore_self_snapshot(robots, snapshot)
        result.self_recovery_degradation_events = before_self_degradations
        result.return_to_safe_halt = before_return_to_safe_halt
        result.safe_halt_to_stranded = before_safe_halt_to_stranded
        return False
    target_reserved = dict(commitment.reserved)
    for robot_id, amount in commitment.claimed_req.items():
        target_reserved[robot_id] = max(target_reserved.get(robot_id, 0.0), amount)
    if transactional:
        stage_pending_reservation(commitment, robots, target_reserved, "top_up:prepare")
    else:
        commitment.reserved = target_reserved
        commitment.effective_reserved = dict(target_reserved)
        reserve_amounts(commitment, robots)
    return True


def configure_contract_degradation(
    commitment: Commitment,
    source_guarantee: str,
    target_guarantee: str,
    target_requirement: dict[int, float],
) -> None:
    """Install an author-provided contract edge; the simulator never invents its cost."""
    commitment.contract_guarantee_requirements[target_guarantee] = dict(target_requirement)
    commitment.authorized_degradation_edges.add((source_guarantee, target_guarantee))


def attempt_policy_degradation(
    policy: str,
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    target_guarantee: str = "reduced_settlement",
    reason: str = "top_up_insufficient",
) -> bool:
    result.contract_degradation_attempts += 1
    if not caps(policy).has_policy_degradation:
        return False
    if caps(policy).has_certificate_auth and (
        commitment.pending_reserved
        or commitment.pending_consumed_backing
        or commitment.pending_operation
    ):
        result.degradation_policy_state_rejections += 1
        return False
    if commitment.status not in ACTIVE_STATUSES or commitment.criticality >= 2:
        result.degradation_policy_state_rejections += 1
        return False
    transition_edge = (commitment.guarantee, target_guarantee)
    if transition_edge not in commitment.authorized_degradation_edges:
        result.unauthorized_degradation_rejections += 1
        return False
    target_requirement = commitment.contract_guarantee_requirements.get(target_guarantee)
    if target_requirement is None:
        result.unauthorized_degradation_rejections += 1
        return False
    if set(target_requirement) != set(commitment.claimed_req):
        result.illegal_degradation_violations += 1
        return False
    if any(amount < -1e-9 for amount in target_requirement.values()):
        result.illegal_degradation_violations += 1
        return False
    if any(
        target_requirement[robot_id] > commitment.claimed_req.get(robot_id, 0.0) + 1e-9
        for robot_id in target_requirement
    ):
        result.illegal_degradation_violations += 1
        return False
    if any(
        commitment.reserved.get(robot_id, 0.0) + 1e-9 < amount
        for robot_id, amount in target_requirement.items()
    ):
        result.degradation_support_failures += 1
        return False

    previous_guarantee = commitment.guarantee
    before_reserved = dict(commitment.reserved)
    physical_before_commit = {
        robot_id: robots[robot_id].reserved.get(commitment.ident, 0.0)
        for robot_id in range(len(robots))
        if commitment.ident in robots[robot_id].reserved
    }
    resource_changes = {
        robot_id: target_requirement[robot_id] - commitment.reserved.get(robot_id, 0.0)
        for robot_id in target_requirement
    }
    target_state = {
        "claimed_req": dict(target_requirement),
        "true_req": dict(target_requirement),
        "reserved": dict(target_requirement),
        "status": STATUS_DEGRADED,
        "guarantee": target_guarantee,
    }
    if not record_version(
        policy,
        commitment,
        result,
        robots,
        "policy_degradation",
        resource_changes=resource_changes,
        authorization_reason=reason,
        target_state=target_state,
    ):
        result.contract_degradation_certificate_failures += 1
        return False

    commitment.at_risk_reason = ""
    reconcile_committed_reservation(
        commitment, robots, result, physical_before_commit, "policy_degradation"
    )
    released = release_pending_locks(
        commitment, robots, result, "authorized_degradation"
    )
    commitment.release_events.append(
        {
            "reason": "authorized_degradation",
            "authorized": True,
            "amount": sum(released.values()),
            "effective_version": commitment.effective_version,
            "physical_live": commitment.physical_live,
            "transition_edge": [previous_guarantee, target_guarantee],
            "executed": True,
        }
    )
    commitment.lifecycle_events.append(
        {
            "transition": "degrade",
            "from_guarantee": previous_guarantee,
            "to_guarantee": target_guarantee,
            "reason": reason,
            "resource_released": {str(k): v for k, v in sorted(released.items())},
            "certificate_version": commitment.effective_version,
        }
    )
    result.degradation_events += 1
    return True


def attempt_top_up(
    policy: str,
    commitment: Commitment,
    live: list[Commitment],
    robots: list[Robot],
    partition: Optional[PartitionState],
    result: PolicyResult,
    params: Params,
    reason: str,
) -> bool:
    if caps(policy).has_certificate_auth and (
        commitment.pending_consumed_backing
        or (
            commitment.pending_operation
            and commitment.pending_operation != "top_up:prepare"
        )
    ):
        result.top_up_failed += 1
        if commitment.status != STATUS_AT_RISK:
            transition_at_risk(
                commitment, robots, result, policy, f"{reason}_pending_transaction"
            )
        return False
    if caps(policy).requires_global_view and not all_team_connected(partition):
        result.top_up_failed += 1
        transition_at_risk(commitment, robots, result, policy, f"{reason}_needs_global_view")
        return False
    if caps(policy).has_local_resource_ownership and not same_partition_group(partition, commitment.participants):
        result.top_up_failed += 1
        transition_at_risk(commitment, robots, result, policy, f"{reason}_participants_partitioned")
        return False
    if not active_participants(commitment.participants, robots):
        result.top_up_failed += 1
        transition_at_risk(commitment, robots, result, policy, f"{reason}_participant_unavailable")
        return False

    before_reserved = dict(commitment.reserved)
    previous_status = commitment.status
    if reserve_delta_to_bound(policy, commitment, robots, result, params):
        target_reserved = dict(commitment.reserved)
        for robot_id, amount in commitment.claimed_req.items():
            target_reserved[robot_id] = max(target_reserved.get(robot_id, 0.0), amount)
        target_status = commitment.status
        if target_status == STATUS_AT_RISK:
            target_status = STATUS_DEGRADED if commitment.guarantee != "full" else STATUS_LIVE
        resource_changes = {
            robot_id: target_reserved.get(robot_id, 0.0) - before_reserved.get(robot_id, 0.0)
            for robot_id in set(target_reserved) | set(before_reserved)
        }
        physical_before_commit = {
            robot_id: robots[robot_id].reserved.get(commitment.ident, 0.0)
            for robot_id in range(len(robots))
            if commitment.ident in robots[robot_id].reserved
        }
        if not record_version(
            policy,
            commitment,
            result,
            robots,
            "top_up",
            resource_changes=resource_changes,
            authorization_reason=reason,
            target_state={"reserved": target_reserved, "status": target_status},
        ):
            commitment.at_risk_reason = f"{reason}_certificate_unconfirmed"
            if commitment.last_certificate_result == "rejected":
                rollback_pending_reservation(commitment, robots, result)
            else:
                result.pending_reservation_uncertain += 1
                if caps(policy).has_at_risk_state and commitment.status != STATUS_AT_RISK:
                    commitment.status = STATUS_AT_RISK
                    commitment.at_risk_backing_snapshot = dict(commitment.reserved)
                    result.at_risk += 1
            result.top_up_failed += 1
            return False
        reconcile_committed_reservation(
            commitment, robots, result, physical_before_commit, "top_up"
        )
        commitment.at_risk_reason = ""
        result.top_up_success += 1
        if previous_status == STATUS_AT_RISK:
            result.at_risk_resolved += 1
        return True

    if policy == "priority_cancel":
        while not is_backed_by_reserved(commitment, robots, use_true=False):
            if not cancel_one_lower_priority(live, robots, commitment.criticality, result, policy):
                break
        if reserve_delta_to_bound(policy, commitment, robots, result, params):
            result.top_up_success += 1
            return True
        result.silent_unbacking += 1
        result.top_up_failed += 1
        return False

    was_at_risk_before_degradation = commitment.status == STATUS_AT_RISK
    if attempt_policy_degradation(policy, commitment, robots, result, reason=reason):
        result.top_up_success += 1
        if was_at_risk_before_degradation:
            result.at_risk_resolved += 1
        return True

    result.top_up_failed += 1
    transition_at_risk(commitment, robots, result, policy, f"{reason}_insufficient_local_rights")
    return False


def handoff_role(commitment: Commitment, role_pick: float) -> str:
    if commitment.support is not None and role_pick < 0.5:
        return "support"
    return "carrier"


def replacement_target(event: HandoffEvent, commitment: Commitment, robots: list[Robot]) -> Optional[int]:
    current = set(commitment.participants)
    for robot_id in event.target_order:
        if robot_id not in current and 0 <= robot_id < len(robots) and robots[robot_id].active:
            return robot_id
    return None


def move_participant_maps(commitment: Commitment, old_robot: int, new_robot: int, new_reserved_amount: float) -> bool:
    if old_robot not in commitment.claimed_req or old_robot not in commitment.true_req:
        return False
    bound = commitment.claimed_req.pop(old_robot)
    true = commitment.true_req.pop(old_robot)
    certified_minimum = commitment.certified_min_req.pop(old_robot, 0.0)
    initial = commitment.initial_claimed_req.pop(old_robot, bound)
    commitment.reserved.pop(old_robot, None)
    commitment.claimed_req[new_robot] = bound
    commitment.true_req[new_robot] = true
    commitment.certified_min_req[new_robot] = certified_minimum
    commitment.initial_claimed_req[new_robot] = initial
    commitment.reserved[new_robot] = new_reserved_amount
    commitment.effective_reserved = dict(commitment.reserved)
    for requirement in commitment.contract_guarantee_requirements.values():
        if old_robot in requirement:
            requirement[new_robot] = requirement.pop(old_robot)
    if old_robot == commitment.carrier:
        commitment.carrier = new_robot
    elif old_robot == commitment.support:
        commitment.support = new_robot
    return True


def reserve_replacement_target(
    policy: str,
    commitment: Commitment,
    old_robot: int,
    new_robot: int,
    robots: list[Robot],
    result: PolicyResult,
    params: Params,
) -> Optional[tuple[float, bool]]:
    amount = max(commitment.reserved.get(old_robot, 0.0), commitment.claimed_req.get(old_robot, 0.0))
    already_locked = robots[new_robot].reserved.get(commitment.ident, 0.0)
    req = {new_robot: max(0.0, amount - already_locked)}
    snapshot = self_snapshot(robots, [new_robot])
    before_self_degradations = result.self_recovery_degradation_events
    before_return_to_safe_halt = result.return_to_safe_halt
    before_safe_halt_to_stranded = result.safe_halt_to_stranded
    allow_degrade = caps(policy).has_policy_degradation and params.medium_high_degrade_self_recovery
    transitions = degrade_self_to_cover(robots, req, None, 0.0, commitment.criticality, allow_degrade, result)
    if not can_cover(robots, req):
        restore_self_snapshot(robots, snapshot)
        result.self_recovery_degradation_events = before_self_degradations
        result.return_to_safe_halt = before_return_to_safe_halt
        result.safe_halt_to_stranded = before_safe_halt_to_stranded
        return None
    if caps(policy).has_certificate_auth:
        commitment.pending_reserved[new_robot] = amount
        commitment.pending_operation = "handoff:prepare"
        commitment.pending_version = commitment.version + 1
        sync_robot_lock(commitment, robots, new_robot)
    else:
        robots[new_robot].reserved[commitment.ident] = amount
    return amount, bool(transitions)


def handoff_target_state(
    commitment: Commitment,
    old_robot: int,
    new_robot: int,
    replacement_amount: float,
    status: str,
) -> dict[str, object]:
    def moved(values: dict[int, float], default: float = 0.0) -> dict[int, float]:
        target = dict(values)
        amount = target.pop(old_robot, default)
        target[new_robot] = amount
        return target

    carrier = new_robot if commitment.carrier == old_robot else commitment.carrier
    support = new_robot if commitment.support == old_robot else commitment.support
    reserved = dict(commitment.reserved)
    reserved.pop(old_robot, None)
    reserved[new_robot] = replacement_amount
    return {
        "carrier": carrier,
        "support": support,
        "status": status,
        "claimed_req": moved(commitment.claimed_req),
        "true_req": moved(commitment.true_req),
        "certified_min_req": moved(commitment.certified_min_req),
        "initial_claimed_req": moved(commitment.initial_claimed_req),
        "reserved": reserved,
    }


def attempt_handoff(
    policy: str,
    commitment: Commitment,
    event: HandoffEvent,
    partition: Optional[PartitionState],
    robots: list[Robot],
    result: PolicyResult,
    params: Params,
    live: list[Commitment],
    phase_contract: Optional[TwoStageContract] = None,
    phase_evidence: Optional[HandoffEvidence] = None,
) -> bool:
    commitment.network_partition = partition
    result.handoff_attempts += 1
    if phase_contract is not None:
        if (
            phase_evidence is None
            or not phase_evidence.trusted or not phase_evidence.valid
            or not phase_evidence.physically_observed
            or phase_evidence.residual_id != commitment.ident
            or phase_evidence.contract_id != phase_contract.contract_id
            or phase_evidence.kind not in {"safe_wait", "physical_takeover"}
            or (phase_evidence.kind == "safe_wait" and not phase_contract.safe_wait_authorized)
            or (phase_evidence.kind == "physical_takeover" and not phase_contract.physical_takeover_authorized)
            or commitment.phase_contract_id != phase_contract.contract_id
            or abs(commitment.claimed_req.get(commitment.carrier, 0.0) - phase_contract.original_requirement) > 1e-9
        ):
            result.handoff_blocked += 1
            return False
        commitment.handoff_requires_old_guard = True
    if caps(policy).has_certificate_auth and (
        commitment.pending_consumed_backing
        or (
            commitment.pending_operation
            and commitment.pending_operation != "handoff:prepare"
        )
    ):
        # Serialize protected lifecycle updates.  In particular, a Retire with
        # physical consequences but an uncertain certificate cannot be
        # overwritten by a new Handoff prepare or cleared by that prepare's
        # rollback path.
        result.handoff_blocked += 1
        return False
    target = replacement_target(event, commitment, robots)
    if target is None:
        result.handoff_failed += 1
        return False
    if event.replacement_blocked:
        result.handoff_blocked += 1
        return False
    role = handoff_role(commitment, event.role_pick)
    old_robot = commitment.support if role == "support" else commitment.carrier
    if phase_contract is not None and old_robot != commitment.carrier:
        result.handoff_blocked += 1
        return False
    if old_robot is None:
        result.handoff_failed += 1
        return False
    if old_robot not in commitment.claimed_req or old_robot not in commitment.true_req:
        result.handoff_failed += 1
        record_invariant_violation(policy, result, "backing_violations", f"handoff source {old_robot} missing requirement map for commitment {commitment.ident}")
        transition_at_risk(commitment, robots, result, policy, "handoff_missing_source_requirement")
        return False
    if event.old_crash_before:
        result.handoff_old_crash_before += 1
        result.handoff_failed += 1
        handle_crash(policy, old_robot, robots, live, result)
        return False

    if caps(policy).requires_global_view and not all_team_connected(partition):
        result.handoff_blocked += 1
        return False
    if caps(policy).has_local_resource_ownership and not same_partition_group(partition, list(commitment.participants) + [target]):
        result.handoff_blocked += 1
        return False

    if policy == "immediate_only":
        if not move_participant_maps(commitment, old_robot, target, 0.0):
            result.handoff_failed += 1
            record_invariant_violation(policy, result, "backing_violations", f"handoff source {old_robot} missing during immediate handoff")
            return False
        result.handoff_success += 1
        return True

    if policy == "priority_cancel" or not caps(policy).has_replacement_before_release:
        if old_robot in commitment.reserved:
            release_one_reservation(commitment, robots, result, old_robot)
        amount = commitment.claimed_req.get(old_robot, 0.0)
        if event.crash_during:
            result.handoff_crash_during += 1
            result.replacement_before_release_violations += 1
            result.unbacked_window_count += 1
            result.silent_unbacking += 1
            transition_at_risk(commitment, robots, result, policy, "handoff_target_crashed_after_old_release")
            handle_crash(policy, target, robots, live, result)
            return False
        if not can_cover(robots, {target: amount}):
            result.replacement_before_release_violations += 1
            result.unbacked_window_count += 1
            result.silent_unbacking += 1
            transition_at_risk(commitment, robots, result, policy, "handoff_released_before_replacement")
            return False
        robots[target].reserved[commitment.ident] = amount
        if not move_participant_maps(commitment, old_robot, target, amount):
            robots[target].reserved.pop(commitment.ident, None)
            result.handoff_failed += 1
            record_invariant_violation(policy, result, "backing_violations", f"handoff source {old_robot} missing after unsafe replacement reserve")
            transition_at_risk(commitment, robots, result, policy, "handoff_missing_source_after_release")
            return False
        result.handoff_success += 1
        return True

    was_at_risk = commitment.status == STATUS_AT_RISK
    previous_at_risk_reason = commitment.at_risk_reason
    replacement = reserve_replacement_target(policy, commitment, old_robot, target, robots, result, params)
    if replacement is None:
        result.handoff_failed += 1
        return False
    replacement_amount, degraded_self = replacement
    if phase_contract is not None and replacement_amount + 1e-9 < phase_contract.successor_requirement:
        if caps(policy).has_certificate_auth:
            rollback_pending_reservation(commitment, robots, result)
        else:
            robots[target].reserved.pop(commitment.ident, None)
        result.handoff_blocked += 1
        return False

    if event.crash_during:
        if caps(policy).has_certificate_auth:
            rollback_pending_reservation(commitment, robots, result)
        else:
            robots[target].reserved.pop(commitment.ident, None)
        result.handoff_crash_during += 1
        result.handoff_failed += 1
        handle_crash(policy, target, robots, live, result)
        return False

    old_reserved_released_unused = max(0.0, commitment.reserved.get(old_robot, 0.0))
    # A replacement repairs only the selected participant.  An AT-RISK
    # commitment may still be under-backed at another participant, so do not
    # clear the risk overlay merely because this one handoff can commit.
    target_status = commitment.status
    target_state = handoff_target_state(
        commitment, old_robot, target, replacement_amount, target_status
    )
    if phase_contract is not None and phase_evidence is not None:
        target_state["physical_stage"] = "transport" if phase_evidence.kind == "safe_wait" else "takeover"
        target_state["phase_contract_id"] = phase_contract.contract_id
        target_state["phase_evidence_hash"] = snapshot_hash(asdict(phase_evidence))
    if was_at_risk:
        target_claimed = _native_snapshot_map(target_state["claimed_req"])
        target_reserved = _native_snapshot_map(target_state["reserved"])
        target_participants = {int(target_state["carrier"])}
        if target_state.get("support") is not None:
            target_participants.add(int(target_state["support"]))
        replacement_fully_restores_backing = all(
            0 <= robot_id < len(robots)
            and robots[robot_id].active
            and target_reserved.get(robot_id, 0.0) + 1e-9 >= amount
            for robot_id, amount in target_claimed.items()
        ) and target_participants.issubset(set(target_claimed))
        if replacement_fully_restores_backing:
            target_state["status"] = STATUS_LIVE
    physical_before_commit = {
        robot_id: robots[robot_id].reserved.get(commitment.ident, 0.0)
        for robot_id in range(len(robots))
        if commitment.ident in robots[robot_id].reserved
    }
    resource_changes = {
        old_robot: -old_reserved_released_unused,
        target: replacement_amount,
    }
    certificate_committed = record_version(
        policy,
        commitment,
        result,
        robots,
        "handoff",
        resource_changes=resource_changes,
        authorization_reason=(
            "trusted_stage_evidence_and_successor_backing"
            if phase_contract is not None else "replacement_backing_confirmed_before_release"
        ),
        target_state=target_state,
        partition=partition,
    )
    if not certificate_committed:
        commitment.at_risk_reason = "handoff_certificate_unconfirmed"
        if commitment.last_certificate_result == "rejected":
            rollback_pending_reservation(commitment, robots, result)
        else:
            result.pending_reservation_uncertain += 1
        result.handoff_failed += 1
        return False
    for requirement in commitment.contract_guarantee_requirements.values():
        if old_robot in requirement:
            requirement[target] = requirement.pop(old_robot)
    reconcile_committed_reservation(
        commitment, robots, result, physical_before_commit, "handoff"
    )
    backed_after_handoff = is_backed_by_reserved(commitment, robots, use_true=False)
    if backed_after_handoff:
        commitment.at_risk_reason = ""
    elif was_at_risk:
        commitment.at_risk_reason = previous_at_risk_reason or "handoff_partial_recovery"
    if event.partition_after_certificate:
        result.handoff_partition_after_certificate += 1
        # The link fails after the effective version has been persisted.  The
        # old owner can act on its local ACK; a missing ACK still retains locks.
        old_group = frozenset({old_robot})
        other_group = frozenset(set(range(len(robots))) - {old_robot})
        commitment.network_partition = PartitionState((old_group, other_group), event.epoch + 1)
    if event.old_crash_after_certificate:
        robots[old_robot].active = False
        robots[old_robot].energy = 0.0
    released = release_pending_locks(commitment, robots, result, "handoff_replaced")
    local_release_executed = 0 <= old_robot < len(robots) and robots[old_robot].active
    if commitment.status == STATUS_AT_RISK:
        # The committed handoff lawfully moves the retained liability from the
        # old participant to its replacement.  Refresh the risk snapshot to
        # the certified post-handoff allocation so the detector protects the
        # replacement backing rather than treating the authorized old release
        # as silent reuse.
        commitment.at_risk_backing_snapshot = dict(commitment.reserved)
    commitment.release_events.append(
        {
            "reason": "handoff_replaced",
            "authorized": True,
            "amount": sum(released.values()),
            "effective_version": commitment.effective_version,
            "physical_live": commitment.physical_live,
            "replacement_robot": target,
            "released_robot": old_robot,
            "executed": local_release_executed,
            "logical_ledger_cleanup": True,
            "retained_unavailable": not local_release_executed,
        }
    )
    commitment.lifecycle_events.append(
        {
            "transition": "handoff",
            "from_participant": old_robot,
            "to_participant": target,
            "certificate_version": commitment.effective_version,
        }
    )
    if was_at_risk and backed_after_handoff:
        result.at_risk_resolved += 1
    result.handoff_success += 1
    check_invariants(policy, robots, live, result, "handoff")
    return True


def attempt_assist(
    old: Commitment, new_robot: int, new_ident: int, contract: TwoStageContract,
    partition: Optional[PartitionState], robots: list[Robot], result: PolicyResult,
    params: Params,
) -> Optional[Commitment]:
    """Mint B's independent obligation; A's certificate and rights are untouched."""
    if new_robot in old.participants or new_ident == old.ident or contract.contract_id != old.phase_contract_id:
        return None
    if new_robot < 0 or new_robot >= len(robots) or not robots[new_robot].active:
        return None
    proposal = replace(
        old.proposal, ident=new_ident, carrier=new_robot, support=None,
        immediate_cost=0.0, carrier_bound=contract.successor_requirement,
        support_bound=0.0, true_carrier_bound=contract.successor_requirement,
        true_support_bound=0.0,
    )
    return create_commitment(
        "commit_guard", proposal, robots, result, params, partition,
        phase_contract_id=contract.contract_id, assist_for=old.ident,
    )


def confirm_assist_takeover(
    old: Commitment, assist: Commitment, evidence: HandoffEvidence,
    contract: TwoStageContract, partition: Optional[PartitionState],
    robots: list[Robot], result: PolicyResult,
) -> bool:
    """Preauthorized witness recovery may certify B's coverage without freeing A.

    This is an abstract witness confirmation, not a general two-certificate
    atomic commit protocol.  If the contract lacks this edge, both records stay.
    """
    if not (
        contract.witness_recovery_authorized
        and evidence.trusted and evidence.valid and evidence.physically_observed
        and evidence.kind == "physical_takeover"
        and evidence.contract_id == contract.contract_id
        and evidence.residual_id == old.ident
        and assist.assist_for == old.ident
        and assist.phase_contract_id == contract.contract_id
        and assist.status in ACTIVE_STATUSES
        and has_latest_certificate(old, robots)
        and has_latest_certificate(assist, robots)
        and assist.reserved.get(assist.carrier, 0.0) + 1e-9 >= contract.successor_requirement
    ):
        return False
    assist.network_partition = partition
    committed = record_version(
        "commit_guard", assist, result, robots, "assist_takeover",
        authorization_reason=f"preauthorized_witness_recovery_from_{old.ident}",
        target_state={
            "physical_stage": "takeover",
            "phase_evidence_hash": snapshot_hash(asdict(evidence)),
            "assist_for": old.ident,
        },
        partition=partition,
    )
    if committed:
        old.lifecycle_events.append({
            "transition": "successor_coverage_observed",
            "successor": assist.ident,
            "successor_effective_version": assist.effective_version,
            "old_backing_retained": True,
        })
    return committed


def try_recover_at_risk(
    policy: str,
    commitment: Commitment,
    partition: Optional[PartitionState],
    robots: list[Robot],
    result: PolicyResult,
    params: Params,
    live: list[Commitment],
    epoch: Optional[int] = None,
) -> None:
    if commitment.status != STATUS_AT_RISK:
        return
    if policy == "central_commit_aware" and not has_latest_certificate(commitment, robots):
        # No successor can be certified without the effective predecessor.
        # Retain the old resource lock until an existing copy becomes reachable
        # or a separately authorized physical disposition is available.
        return
    if commitment.at_risk_reason == "discharge_certificate_unconfirmed":
        recovery_epoch = commitment.physical_completion_epoch if epoch is None else epoch
        if recover_pending_retire(policy, commitment, partition, robots, result, recovery_epoch or 0):
            if commitment in live:
                live.remove(commitment)
        return
    if commitment.at_risk_reason in {
        "invalid_or_missing_discharge_evidence",
    }:
        return
    inactive = [p for p in commitment.participants if not robots[p].active]
    if inactive:
        order = [r for r in range(len(robots)) if r not in commitment.participants]
        role_pick = 0.0 if commitment.support in inactive else 1.0
        event = HandoffEvent(epoch=0, pick=0.0, role_pick=role_pick, target_order=tuple(order))
        attempt_handoff(policy, commitment, event, partition, robots, result, params, live)
        return
    attempt_top_up(policy, commitment, live, robots, partition, result, params, reason="at_risk_recovery")


