"""COMMITGUARD discrete-event experiment modules."""
