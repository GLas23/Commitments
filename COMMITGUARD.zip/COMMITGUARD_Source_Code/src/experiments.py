from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Iterable, Optional

from .models import *

def mean(values: list[float]) -> float:
    return statistics.fmean(values) if values else 0.0


def stdev(values: list[float]) -> float:
    return statistics.stdev(values) if len(values) > 1 else 0.0


def student_t_critical_95(sample_count: int) -> float:
    """Two-sided 95% Student-t critical value without external dependencies."""
    if sample_count <= 1:
        return 0.0
    table = (
        12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306, 2.262, 2.228,
        2.201, 2.179, 2.160, 2.145, 2.131, 2.120, 2.110, 2.101, 2.093, 2.086,
        2.080, 2.074, 2.069, 2.064, 2.060, 2.056, 2.052, 2.048, 2.045, 2.042,
    )
    degrees = sample_count - 1
    if degrees <= len(table):
        return table[degrees - 1]
    z = 1.959963984540054
    d = float(degrees)
    return (
        z + (z ** 3 + z) / (4 * d)
        + (5 * z ** 5 + 16 * z ** 3 + 3 * z) / (96 * d ** 2)
        + (3 * z ** 7 + 19 * z ** 5 + 17 * z ** 3 - 15 * z) / (384 * d ** 3)
    )


def student_t_ci95(values: list[float]) -> Optional[float]:
    return (
        student_t_critical_95(len(values)) * stdev(values) / math.sqrt(len(values))
        if len(values) > 1 else None
    )


def result_to_row(result: PolicyResult) -> dict[str, float | str]:
    row = asdict(result)
    row.pop("max_version_seen", None)
    return row


def numeric_cell(value: object) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        number = float(value)
        return number if math.isfinite(number) else None
    if isinstance(value, str):
        text = value.strip()
        if not text or text.upper() in {"N/A", "NA", "NONE", "NULL"}:
            return None
        try:
            number = float(text)
        except ValueError:
            return None
        return number if math.isfinite(number) else None
    return None


def aggregate(policy: str, rows: list[PolicyResult]) -> dict[str, float | str]:
    out: dict[str, float | str] = {"policy": policy, "label": POLICY_LABELS[policy]}
    sample = result_to_row(rows[0]) if rows else result_to_row(PolicyResult(policy))
    for key in sample:
        if key == "policy":
            continue
        xs = [value for r in rows if (value := numeric_cell(result_to_row(r).get(key))) is not None]
        if not xs:
            out[f"{key}_mean"] = ""
            out[f"{key}_sd"] = ""
            out[f"{key}_ci95"] = ""
            continue
        out[f"{key}_mean"] = mean(xs)
        out[f"{key}_sd"] = stdev(xs) if len(xs) > 1 else None
        out[f"{key}_ci95"] = student_t_ci95(xs)
        if len(xs) != len(rows):
            out[f"{key}_defined_n"] = len(xs)
    return out


def run_policies(
    params: Params,
    traces: int,
    seed: int,
    policies: list[str],
    progress_label: Optional[str] = None,
    show_progress: bool = True,
) -> tuple[list[dict[str, float | str]], list[dict[str, float | str]]]:
    raw: list[dict[str, float | str]] = []
    by_policy: dict[str, list[PolicyResult]] = {p: [] for p in policies}
    progress = ProgressBar(progress_label or "simulating", traces * len(policies), enabled=show_progress and PROGRESS_ENABLED)
    try:
        for trace_index in range(traces):
            trace = generate_trace(params, seed + trace_index)
            trace_digest = hashlib.sha256(repr(trace).encode("utf-8")).hexdigest()
            for policy in policies:
                result = simulate_policy(policy, trace, params)
                if hashlib.sha256(repr(trace).encode("utf-8")).hexdigest() != trace_digest:
                    raise AssertionError("policy mutated the shared exogenous workload trace")
                by_policy[policy].append(result)
                row = result_to_row(result)
                row["trace"] = trace_index
                row["trace_sha256"] = trace_digest
                row["trace_seed"] = seed + trace_index
                row["policy_label"] = POLICY_LABELS[policy]
                raw.append(row)
                progress.update()
    finally:
        progress.close()
    summary = [aggregate(policy, by_policy[policy]) for policy in policies]
    return summary, raw


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def extra_trace_count(args: argparse.Namespace) -> int:
    return int(getattr(args, "extra_traces", getattr(args, "sweep_traces", 200)))


def paired_analysis(raw: list[dict[str, float | str]], comparisons: list[tuple[str, str]], metrics: list[str]) -> list[dict[str, object]]:
    by_trace_policy: dict[int, dict[str, dict[str, float | str]]] = {}
    for row in raw:
        pair = by_trace_policy.setdefault(int(row["trace"]), {})
        policy = str(row["policy"])
        if policy in pair:
            raise ValueError("duplicate trace/policy in paired analysis; group sweep configurations first")
        pair[policy] = row
    rows: list[dict[str, object]] = []
    for baseline, challenger in comparisons:
        for metric in metrics:
            diffs: list[float] = []
            for policies in by_trace_policy.values():
                if baseline in policies and challenger in policies:
                    challenger_value = numeric_cell(policies[challenger].get(metric))
                    baseline_value = numeric_cell(policies[baseline].get(metric))
                    if challenger_value is None or baseline_value is None:
                        continue
                    diffs.append(challenger_value - baseline_value)
            if not diffs:
                continue
            difference_mean = mean(diffs)
            margin = student_t_ci95(diffs)
            rows.append(
                {
                    "baseline": baseline,
                    "challenger": challenger,
                    "metric": metric,
                    "mean_diff": difference_mean,
                    "sd_diff": stdev(diffs) if len(diffs) > 1 else None,
                    "ci95_low": difference_mean - margin if margin is not None else None,
                    "ci95_high": difference_mean + margin if margin is not None else None,
                    "ci95_method": "paired Student-t",
                    "paired_traces": len(diffs),
                }
            )
    return rows


def write_capability_table(out_dir: Path) -> None:
    rows = []
    for policy in POLICIES:
        row = {"policy": policy, "label": POLICY_LABELS[policy]}
        row.update(asdict(caps(policy)))
        rows.append(row)
    write_csv(out_dir / "policy_capabilities.csv", rows)
    write_json(out_dir / "policy_capabilities.json", rows)


def strict_invariant_enforced(policy: str) -> bool:
    if policy not in STRICT_POLICIES:
        return False
    capability = caps(policy)
    return (
        capability.has_commitment_ledger
        and capability.has_exact_reservation
        and capability.has_authenticated_certificate
        and capability.has_at_risk_state
        and capability.has_monotonic_version
        and capability.has_certificate_auth
        and capability.has_witness_replication
        and capability.has_local_resource_ownership
        and capability.has_policy_degradation
        and capability.has_replacement_before_release
        and capability.has_certified_minimum_backing
        and capability.rejects_visible_planner_errors
    )


def make_params(args: argparse.Namespace, **overrides: float | int | bool | str) -> Params:
    values = asdict(Params())
    values.update(
        robots=args.robots,
        proposal_prob=args.proposal_prob,
        proposal_mode=args.proposal_mode,
        proposal_load_per_robot=args.proposal_load_per_robot,
        partition_start_prob=args.partition_prob,
        partition_duration_min=args.partition_duration_min,
        partition_duration_max=args.partition_duration_max,
        inflation_prob=args.inflation_prob,
        crash_prob=args.crash_prob,
        self_recovery_guarantee=args.self_recovery,
        witness_count=args.witness_count,
        certificate_ack_delay_epochs=args.certificate_ack_delay_epochs,
        retire_recovery_wait_epochs=args.retire_recovery_wait_epochs,
        handoff_prob=args.handoff_prob,
        handoff_replacement_scarcity=args.handoff_replacement_scarcity,
        handoff_crash_prob=args.handoff_crash_prob,
        handoff_old_crash_prob=args.handoff_old_crash_prob,
        handoff_partition_after_certificate_prob=args.handoff_partition_after_certificate_prob,
        version_replay_prob=args.version_replay_prob,
        lifecycle_attack_prob=args.lifecycle_attack_prob,
        lifecycle_attack_kind=args.lifecycle_attack_kind,
        adversarial_proposal_prob=args.adversarial_proposal_prob,
        adversarial_cost_multiplier=args.adversarial_cost_multiplier,
        attack_mode=args.attack_mode,
        bound_error=args.bound_error,
        underreport_fraction=args.underreport_fraction,
        min_carrier_low=args.min_carrier_low,
        min_carrier_medium=args.min_carrier_medium,
        min_carrier_high=args.min_carrier_high,
        min_support_low=args.min_support_low,
        min_support_medium=args.min_support_medium,
        min_support_high=args.min_support_high,
        deadline_tightness=args.deadline_tightness,
        evidence_delay_max=args.evidence_delay_max,
        evidence_missing_prob=args.evidence_missing_prob,
        evidence_invalid_prob=args.evidence_invalid_prob,
        contract_degraded_carrier_requirement=getattr(
            args, "contract_degraded_carrier_requirement", Params.contract_degraded_carrier_requirement
        ),
        contract_degraded_support_requirement=getattr(
            args, "contract_degraded_support_requirement", Params.contract_degraded_support_requirement
        ),
    )
    values.update(overrides)
    return Params(**values)


def experiment_dir(out_dir: Path, name: str) -> Path:
    target = out_dir / name
    target.mkdir(parents=True, exist_ok=True)
    write_capability_table(target)
    return target


def metadata_payload(experiment: str, args: argparse.Namespace, params: Params, trace_count: int, sweep_values: dict[str, object] | list[dict[str, object]]) -> dict[str, object]:
    return {
        "simulator_version": "commitguard-discrete-event-paper-artifact",
        "experiment": experiment,
        "random_seed": args.seed,
        "trace_count": trace_count,
        "params": asdict(params),
        "policy_capabilities": {policy: asdict(caps(policy)) for policy in POLICIES},
        "sweep_values": sweep_values,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "python_version": sys.version,
        "assumptions": {
            "confidence_intervals": "two-sided Student-t mean intervals; paired differences use matched trace IDs; n<2 gives an undefined interval",
            "trace_fingerprints": "run_policies hashes the same Trace before and after every policy; mutation is an error. trace_sha256 is a reproducibility fingerprint within the recorded Python representation version",
            "physical_oracle": "P4 checks object, obligation scope, responsibility units, protected effective version and stage inheritance; energy/capacity is measured separately. The original full obligation persists through an unconfirmed Transform",
            "oracle_scope": "physical history is observed from simulated execution and physical requirement fields. This software-only model is not an independently implemented physical plant",
            "durable_oracle": "only live persisted holders of the current valid certificate count; obsolete quorum envelopes do not extend the successor's crash bound",
            "commit_release_boundary": "logical commit and actual local release are separate counters; inactive owners' resources remain unavailable even if central logical bookkeeping is cleaned",
            "experiment_type": "software-only discrete-event simulation; no ROS/Gazebo/FPGA/real-robot component",
            "completion_time": "default duration is sampled so duration <= deadline; deadline remains the latest permitted completion time",
            "criticality_distribution": "low/medium/high probabilities are 0.50/0.30/0.20",
            "attack_generation": "ground-truth attack labels are generated by the attack RNG and are not visible to policy admission decisions",
            "witness_selection": "witnesses are selected from deterministic witness_order among active non-participant robots",
            "common_random_numbers": "sweeps reuse deterministic stream seeds and change only the swept parameter or threshold",
            "crn_generation_method": "inflation, partition, handoff, replay, and lifecycle_attack use per-epoch deterministic candidate RNG streams; changing a probability threshold does not consume a different number of random values in later epochs",
            "lifecycle_attack_generation": "formal A2/A3 attacks are generated as post-admission LifecycleAttackEvent instances against existing LIVE/DEGRADED commitments; proposal-level malicious fields remain only for compatibility validation",
            "bound_detection_semantics": "model_underestimate_events counts true_req > claimed_req once per commitment as simulator ground truth; bound_detection_count and mean_detection_latency are recorded when settlement exposes the underdeclared requirement",
            "malicious_underreport_semantics": "malicious_underreport lowers only public carrier_bound/support_bound by underreport_fraction; true_carrier_bound/true_support_bound remain based on the original normally sampled bounds and the normal bound_error factor",
            "certified_minimum_backing": "certified_minimum_requirement uses only public participant roles and criticality thresholds; it does not read true_carrier_bound or true_support_bound. COMMIT GUARD reserves max(claimed requirement, certified minimum).",
            "contract_bound_violations_alias": "contract_bound_violations is retained as a compatibility alias for model_underestimate_events",
            "deadline_tightness": "deadline_tightness controls the upper sampling bound for duration relative to deadline; it is not an exact duration/deadline equality constraint",
            "reservation_efficiency": "reserve_efficiency is defined only when a policy has reserved backing; it equals reserved_backing_consumed / (reserved_backing_consumed + reserved_backing_released_unused)",
            "reserved_energy_alias": "total_reserved_energy is retained for old CSV compatibility and means reservation_energy_area, i.e. sum_t Reserved(t), not cumulative energy consumption",
            "rupture_residual": "DISCHARGED clears physical_live after discharge evidence and settlement; RUPTURED leaves physical_live true by default and records residual_after_rupture plus ruptured_physical_liability",
            "rupture_resource_disposition": "AT-RISK and RUPTURED retain valid backing while physical_live remains true. Crash-lost backing is excluded from available capacity; release requires committed discharge, replacement, or explicit terminal disposition evidence.",
            "observation_censoring": "commitments still active at the end of a finite trace are counted as unfinished/observation_censored and are not automatically converted to physical rupture or discharge",
            "contract_degradation": "the default workload defines only the full task guarantee. Alternative task guarantees must be installed through configure_contract_degradation with an explicit authorized edge and resource requirement; the simulator does not infer a degraded physical demand from available reservation",
            "transactional_reservation": "certificate-protected Mint, Inflate, Degrade, Transform, and Retire use prepare/confirm/commit accounting. effective_reserved mirrors the effective certificate; pending_reserved is a conservative physical lock and is not an effective right.",
            "pending_lock_metrics": "pending_reservation_energy_area and mean/peak/end pending metrics quantify conservative locks that are not effective rights; pending_consumed_backing_at_end records physically consumed backing awaiting certificate resolution.",
            "certificate_abstraction": "certificate candidates become effective only after participant acknowledgements and the configured f+1 persistence threshold. This is a lightweight state-machine safety abstraction, not an implementation or formal verification of a network consensus protocol",
            "attack_primary_metrics": "security_attacks_summary.csv reports scenario-specific primary metrics: replay uses effective stale-version attempts, lifecycle attacks use their own accepted/rejected counters, remote-right overspend uses only occupied remote reservations, and underdeclared-liability reports contract-soundness failure rather than generic attack success",
            "invariant_vs_attack_counts": "invariant violation observations may persist across epochs for debugging; attack-event counters such as remote_overspend_success, ownership_conflicts, and remote_double_spend_events are unique per affected commitment",
            "ablation_matching": "ablation runs use Full and Ablated COMMIT GUARD on the same generated trace for each scenario and report paired deltas as Ablated minus Full",
            "minimum_backing_microbench": "minimum_backing_microbench isolates Python admission-check overhead for claimed-only versus certified-minimum max/compare; it is not an end-to-end distributed systems timing measurement",
        },
    }


def write_metadata(out_dir: Path, experiment: str, args: argparse.Namespace, params: Params, trace_count: int, sweep_values: dict[str, object] | list[dict[str, object]]) -> None:
    write_json(out_dir / "experiment_metadata.json", metadata_payload(experiment, args, params, trace_count, sweep_values))


def annotate_rows(rows: list[dict[str, float | str]], experiment: str, seed: int, trace_count: int, params: Params, parameter_values: dict[str, object]) -> list[dict[str, object]]:
    annotated: list[dict[str, object]] = []
    for row in rows:
        out: dict[str, object] = {"experiment": experiment, "seed": seed, "trace_count": trace_count}
        out.update(parameter_values)
        out.update(row)
        if "trace" in out:
            out["trace_id"] = out["trace"]
        if "policy" in out and "policy_label" not in out:
            out["policy_label"] = POLICY_LABELS.get(str(out["policy"]), str(out["policy"]))
        annotated.append(out)
    return annotated


def row_metric(row: dict[str, object], metric: str, summary: bool) -> float:
    key = f"{metric}_mean" if summary else metric
    value = numeric_cell(row.get(key))
    return 0.0 if value is None else value


def add_primary_attack_metrics(row: dict[str, object], attack_name: str, summary: bool) -> None:
    def m(metric: str) -> float:
        return row_metric(row, metric, summary)

    attempts = 0.0
    successes = 0.0
    rejected = 0.0
    blocked = 0.0
    success_rate: float | str = ""
    prevention_rate: float | str = ""

    if attack_name == "A1_replay":
        attempts = m("replay_effective_attempts")
        successes = m("version_replay_accepted")
        rejected = m("replay_rejected")
        success_rate = successes / attempts if attempts else ""
        prevention_rate = rejected / attempts if attempts else ""
    elif attack_name == "A2_silent_cancellation":
        attempts = m("silent_cancellation_attempts")
        successes = m("silent_cancellation_success")
        rejected = m("silent_cancellation_rejected")
        success_rate = successes / attempts if attempts else ""
        prevention_rate = rejected / attempts if attempts else ""
    elif attack_name == "A3_unauthorized_degradation":
        attempts = m("illegal_degradation_attempts")
        successes = m("illegal_degradation_success")
        rejected = m("illegal_degradation_rejected")
        success_rate = successes / attempts if attempts else ""
        prevention_rate = rejected / attempts if attempts else ""
    elif attack_name == "A4_remote_right_overspend":
        attempts = m("remote_overspend_attempts")
        successes = m("remote_overspend_success")
        rejected = m("remote_overspend_rejected")
        blocked = m("remote_overspend_blocked")
        success_rate = successes / attempts if attempts else ""
        prevention_rate = (rejected + blocked) / attempts if attempts else ""
    elif attack_name == "A5_underdeclared_liability":
        attempts = m("underdeclared_attempts")
        admitted = m("underdeclared_admitted")
        successes = m("underdeclared_physical_underbacking")
        rejected = max(0.0, attempts - admitted)
        success_rate = successes / admitted if admitted else ""
        prevention_rate = ""
    else:
        attempts = m("attack_attempts")
        successes = m("attack_success")
        rejected = (
            m("adversarial_rejected")
            + m("replay_rejected")
            + m("silent_cancellation_rejected")
            + m("illegal_degradation_rejected")
            + m("remote_overspend_rejected")
        )
        blocked = m("remote_overspend_blocked")
        success_rate = successes / attempts if attempts else ""
        prevention_rate = (rejected + blocked) / attempts if attempts else ""

    row["primary_attack_attempts"] = attempts
    row["primary_attack_successes"] = successes
    row["primary_attack_rejected"] = rejected
    row["primary_attack_blocked"] = blocked
    row["primary_attack_success_rate"] = success_rate
    row["primary_attack_prevention_rate"] = prevention_rate


def progress_label(experiment: str, traces: int, policies: list[str], parameter_values: dict[str, object]) -> str:
    suffix_parts = []
    for key, value in parameter_values.items():
        if key in {"seed", "trace_count"}:
            continue
        suffix_parts.append(f"{key}={value}")
        if len(suffix_parts) >= 2:
            break
    suffix = f" ({', '.join(suffix_parts)})" if suffix_parts else ""
    return f"{experiment}{suffix}: {traces} traces x {len(policies)} policies"


def run_point(experiment: str, params: Params, traces: int, seed: int, policies: list[str], parameter_values: dict[str, object]) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    summary, raw = run_policies(
        params,
        traces,
        seed,
        policies,
        progress_label=progress_label(experiment, traces, policies, parameter_values),
    )
    return annotate_rows(summary, experiment, seed, traces, params, parameter_values), annotate_rows(raw, experiment, seed, traces, params, parameter_values)


def write_summary_json(path: Path, experiment: str, params: Params, summary: list[dict[str, object]], raw: list[dict[str, object]] | None = None) -> None:
    payload: dict[str, object] = {"experiment": experiment, "params": asdict(params), "summary": summary}
    if raw is not None:
        payload["raw"] = raw
    write_json(path, payload)


def write_paired_outputs(out_dir: Path, raw: list[dict[str, object]], metrics: list[str]) -> list[dict[str, object]]:
    paired = paired_analysis(raw, [("static_worst_case", "commit_guard"), ("priority_cancel", "commit_guard"), ("central_commit_aware", "commit_guard"), ("immediate_only", "commit_guard")], metrics)  # type: ignore[arg-type]
    write_csv(out_dir / "paired_analysis.csv", paired)
    write_json(out_dir / "paired_analysis.json", paired)
    return paired


def default_workload(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "default")
    params = make_params(args)
    summary, raw = run_point("default", params, args.traces, args.seed, POLICIES, {})
    write_csv(exp / "default_summary.csv", summary)
    write_csv(exp / "default_raw.csv", raw)
    paired = write_paired_outputs(exp, raw, [
        "rescued", "physical_completed", "missed", "admitted", "rejected", "blocked",
        "at_risk", "silent_unbacking", "double_spend_violations",
        "semantic_liability_coverage_violations", "physical_underbacking_events",
        "forgotten_liability", "durable_record_survival_violations",
        "pending_lock_duration", "retire_recovered", "retire_pending_at_end",
        "energy_consumed", "invariant_violations", "reserve_efficiency",
    ])
    write_csv(exp / "default_paired_analysis.csv", paired)
    write_json(exp / "default_paired_analysis.json", paired)
    write_summary_json(exp / "default_summary.json", "default", params, summary)
    write_metadata(exp, "default", args, params, args.traces, {})


def partition_sweep(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "partition")
    values = [0.00, 0.025, 0.05, 0.075, 0.10, 0.125, 0.15, 0.18]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    last_params = make_params(args)
    for prob in values:
        params = make_params(args, partition_start_prob=prob)
        last_params = params
        summary, raw = run_point("partition", params, args.sweep_traces, args.seed + 20_000, ["central_commit_aware", "commit_guard"], {"partition_start_probability": prob, "partition_start_prob": prob})
        rows.extend(summary)
        raw_rows.extend(raw)
    write_csv(exp / "partition_sweep.csv", rows)
    write_csv(exp / "partition_raw.csv", raw_rows)
    write_summary_json(exp / "partition_sweep.json", "partition", last_params, rows)
    write_metadata(exp, "partition", args, last_params, args.sweep_traces, {"partition_start_probability": values})


def inflation_sweep(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "inflation")
    values = [0.00, 0.025, 0.05, 0.075, 0.10, 0.125, 0.15, 0.175, 0.20]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    last_params = make_params(args)
    for prob in values:
        params = make_params(args, inflation_prob=prob)
        last_params = params
        summary, raw = run_point("inflation", params, args.sweep_traces, args.seed + 30_000, ["priority_cancel", "static_worst_case", "commit_guard"], {"inflation_probability": prob, "inflation_prob": prob})
        rows.extend(summary)
        raw_rows.extend(raw)
    write_csv(exp / "inflation_sweep.csv", rows)
    write_csv(exp / "inflation_raw.csv", raw_rows)
    write_summary_json(exp / "inflation_sweep.json", "inflation", last_params, rows)
    write_metadata(exp, "inflation", args, last_params, args.sweep_traces, {"inflation_probability": values})


def controlled_witness_failure(args: argparse.Namespace, out_dir: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for witness_count in [0, 1, 2, 3, 4]:
        params = make_params(args, crash_prob=0.0, witness_count=witness_count, partition_start_prob=0.0)
        for requested_crashes in [0, 1, 2, 3, 4]:
            robots = make_robots(params)
            result = PolicyResult(policy="commit_guard")
            result.total_initial_energy = params.robots * params.initial_energy
            prop = Proposal(ident=1, epoch=0, carrier=0, support=1, criticality=2, immediate_cost=4.0, carrier_bound=10.0, support_bound=4.0, true_carrier_bound=10.0, true_support_bound=4.0, deadline=10, duration=4, settlement_ratio=1.0, witness_order=tuple(range(2, params.robots)))
            commitment = create_commitment("commit_guard", prop, robots, result, params)
            live = [commitment] if commitment is not None else []
            holders = sorted(certificate_holders(commitment)) if commitment is not None else []
            crashed = holders[: min(requested_crashes, len(holders))]
            for holder in crashed:
                handle_crash("commit_guard", holder, robots, live, result)
            for c in list(live):
                check_forgetting("commit_guard", c, robots, result)
            actual_crashes = len(crashed)
            copy_count = len(holders)
            actual_extra_witnesses = len(commitment.witnesses) if commitment is not None else 0
            expected_survives = actual_crashes < copy_count
            rows.append({"experiment": "controlled_witness_failure", "seed": args.seed, "policy": "commit_guard", "policy_label": POLICY_LABELS["commit_guard"], "witness_count": witness_count, "actual_extra_witnesses": actual_extra_witnesses, "copy_count": copy_count, "requested_holder_crashes": requested_crashes, "actual_holder_crashes": actual_crashes, "expected_survives_by_f_plus_1": expected_survives, "forgotten_commitments": result.forgotten_commitments, "certificates_lost": result.certificates_lost, "orphaned_physical_liability": result.orphaned_liability, "silent_unbacking": result.silent_unbacking, "invariant_violations": result.invariant_violations})
    write_csv(out_dir / "controlled_witness_failure.csv", rows)
    write_json(out_dir / "controlled_witness_failure.json", rows)
    return rows


def crash_witness_sweep(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "crash_witness")
    crash_values = [0.0, 0.001, 0.002, 0.005, 0.01, 0.02]
    witness_values = [0, 1, 2, 3, 4]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    last_params = make_params(args)
    for crash_prob in crash_values:
        for witnesses in witness_values:
            params = make_params(args, crash_prob=crash_prob, witness_count=witnesses)
            last_params = params
            summary, raw = run_point("crash_witness", params, extra_trace_count(args), args.seed + 50_000, ["commit_guard"], {"crash_probability": crash_prob, "crash_prob": crash_prob, "witness_count": witnesses})
            rows.extend(summary)
            raw_rows.extend(raw)
    controlled = controlled_witness_failure(args, exp)
    write_csv(exp / "crash_witness_sweep.csv", rows)
    write_csv(exp / "crash_witness_raw.csv", raw_rows)
    write_json(exp / "crash_witness_sweep.json", {"summary": rows, "controlled_witness_failure": controlled})
    write_metadata(exp, "crash_witness", args, last_params, extra_trace_count(args), {"crash_probability": crash_values, "witness_count": witness_values})


def handoff_stress(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "handoff")
    values = [0.0, 0.02, 0.05, 0.10, 0.20, 0.30]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    last_params = make_params(args)
    for handoff_prob in values:
        params = make_params(args, handoff_prob=handoff_prob)
        last_params = params
        summary, raw = run_point("handoff_sweep", params, extra_trace_count(args), args.seed + 60_000, ["priority_cancel", "central_commit_aware", "commit_guard"], {"handoff_probability": handoff_prob, "handoff_prob": handoff_prob, "fault": "none"})
        rows.extend(summary)
        raw_rows.extend(raw)
    fault_configs = [("F1_old_participant_crashes_before_replacement", {"handoff_prob": 0.20, "handoff_old_crash_prob": 1.0}), ("F2_replacement_crashes_after_reserve_before_certificate", {"handoff_prob": 0.20, "handoff_crash_prob": 1.0}), ("F3_partition_after_new_certificate_before_old_release", {"handoff_prob": 0.20, "handoff_partition_after_certificate_prob": 1.0}), ("F4_replacement_insufficient_capacity", {"handoff_prob": 0.20, "handoff_replacement_scarcity": 1.0})]
    fault_rows: list[dict[str, object]] = []
    fault_raw: list[dict[str, object]] = []
    for fault_name, overrides in fault_configs:
        params = make_params(args, **overrides)
        last_params = params
        summary, raw = run_point("handoff_fault_injection", params, extra_trace_count(args), args.seed + 61_000, ["priority_cancel", "central_commit_aware", "commit_guard"], {"fault": fault_name, **overrides})
        fault_rows.extend(summary)
        fault_raw.extend(raw)
    write_csv(exp / "handoff_sweep.csv", rows)
    write_csv(exp / "handoff_fault_injection.csv", fault_rows)
    write_csv(exp / "handoff_raw.csv", raw_rows + fault_raw)
    write_json(exp / "handoff_results.json", {"handoff_sweep": rows, "handoff_fault_injection": fault_rows})
    write_json(exp / "handoff_sweep.json", rows)
    write_json(exp / "handoff_fault_injection.json", fault_rows)
    write_metadata(exp, "handoff", args, last_params, extra_trace_count(args), {"handoff_probability": values, "faults": [name for name, _ in fault_configs]})


def security_attacks_experiment(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "security_attacks")
    configs: list[tuple[str, dict[str, object]]] = [
        ("A1_replay", {"version_replay_prob": 0.20, "adversarial_proposal_prob": 0.0, "attack_mode": "mixed", "lifecycle_attack_prob": 0.0}),
        ("A2_silent_cancellation", {"adversarial_proposal_prob": 0.0, "attack_mode": "mixed", "lifecycle_attack_prob": 0.20, "lifecycle_attack_kind": "silent_cancellation"}),
        ("A3_unauthorized_degradation", {"adversarial_proposal_prob": 0.0, "attack_mode": "mixed", "lifecycle_attack_prob": 0.20, "lifecycle_attack_kind": "unauthorized_degradation"}),
        ("A4_remote_right_overspend", {"adversarial_proposal_prob": 0.20, "attack_mode": "remote_right_overspend", "partition_start_prob": 0.18, "lifecycle_attack_prob": 0.0}),
        ("A5_underdeclared_liability", {"adversarial_proposal_prob": 0.20, "attack_mode": "underdeclared_bound", "adversarial_cost_multiplier": 2.0, "lifecycle_attack_prob": 0.0}),
        ("mixed", {"version_replay_prob": 0.10, "adversarial_proposal_prob": 0.20, "attack_mode": "mixed", "lifecycle_attack_prob": 0.05, "lifecycle_attack_kind": "mixed"}),
    ]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    last_params = make_params(args)
    for attack_name, overrides in configs:
        params = make_params(args, **overrides)
        last_params = params
        summary, raw = run_point("security_attacks", params, extra_trace_count(args), args.seed + 85_000, POLICIES, {"attack": attack_name, **overrides})
        for row in summary:
            add_primary_attack_metrics(row, attack_name, summary=True)
        for row in raw:
            add_primary_attack_metrics(row, attack_name, summary=False)
        rows.extend(summary)
        raw_rows.extend(raw)
    write_csv(exp / "security_attacks_summary.csv", rows)
    write_csv(exp / "security_attacks_raw.csv", raw_rows)
    write_json(exp / "security_attacks.json", {"summary": rows, "raw_file": "security_attacks_raw.csv"})
    write_metadata(exp, "security_attacks", args, last_params, extra_trace_count(args), {"attacks": [name for name, _ in configs]})


def run_commit_guard_with_capability_override(
    params: Params,
    traces: int,
    seed: int,
    override: dict[str, object],
    progress_name: str = "ablation",
) -> list[PolicyResult]:
    original = POLICY_CAPABILITIES["commit_guard"]
    POLICY_CAPABILITIES["commit_guard"] = replace(original, **override)
    results: list[PolicyResult] = []
    progress = ProgressBar(f"{progress_name}: {traces} traces x 1 policy", traces, enabled=PROGRESS_ENABLED)
    try:
        for trace_index in range(traces):
            trace = generate_trace(params, seed + trace_index)
            results.append(simulate_policy("commit_guard", trace, params))
            progress.update()
    finally:
        progress.close()
        POLICY_CAPABILITIES["commit_guard"] = original
    return results


def run_ablation_pair(
    params: Params,
    traces: int,
    seed: int,
    override: dict[str, object],
    progress_name: str = "ablation",
) -> tuple[list[PolicyResult], list[PolicyResult]]:
    original = POLICY_CAPABILITIES["commit_guard"]
    ablated = replace(original, **override)
    full_results: list[PolicyResult] = []
    ablated_results: list[PolicyResult] = []
    progress = ProgressBar(f"{progress_name}: {traces} traces x 2 variants", traces * 2, enabled=PROGRESS_ENABLED)
    try:
        for trace_index in range(traces):
            trace = generate_trace(params, seed + trace_index)
            POLICY_CAPABILITIES["commit_guard"] = original
            full_results.append(simulate_policy("commit_guard", trace, params))
            progress.update()
            POLICY_CAPABILITIES["commit_guard"] = ablated
            ablated_results.append(simulate_policy("commit_guard", trace, params))
            progress.update()
    finally:
        progress.close()
        POLICY_CAPABILITIES["commit_guard"] = original
    return full_results, ablated_results


def ablation_policy_suffix(name: str) -> str:
    return name.lower().replace("-", "minus_").replace(" ", "_")


def add_ablation_summary_aliases(summary: dict[str, object]) -> None:
    summary["replay_success_mean"] = summary.get("version_replay_accepted_mean", 0.0)
    summary["replacement_violation_mean"] = summary.get("replacement_before_release_violations_mean", 0.0)
    summary["illegal_release_mean"] = summary.get("release_violations_mean", 0.0)


def ablation_paired_rows(
    scenario: str,
    ablation: str,
    full_results: list[PolicyResult],
    ablated_results: list[PolicyResult],
    metrics: list[str],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for metric in metrics:
        full_values: list[float] = []
        ablated_values: list[float] = []
        diffs: list[float] = []
        for full_result, ablated_result in zip(full_results, ablated_results):
            full_value = numeric_cell(result_to_row(full_result).get(metric))
            ablated_value = numeric_cell(result_to_row(ablated_result).get(metric))
            if full_value is None or ablated_value is None:
                continue
            full_values.append(full_value)
            ablated_values.append(ablated_value)
            diffs.append(ablated_value - full_value)
        if not diffs:
            continue
        delta_mean = mean(diffs)
        margin = student_t_ci95(diffs)
        rows.append(
            {
                "scenario": scenario,
                "ablation": ablation,
                "metric": metric,
                "full_mean": mean(full_values),
                "ablated_mean": mean(ablated_values),
                "mean_delta": delta_mean,
                "sd_delta": stdev(diffs),
                "ci95_low": delta_mean - margin if margin is not None else None,
                "ci95_high": delta_mean + margin if margin is not None else None,
                "ci95_method": "paired Student-t",
                "paired_traces": len(diffs),
            }
        )
    return rows


def ablation_experiment(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "ablation")
    configs = [
        ("-Witness", "crash stress", {"has_witness_replication": False}, {"crash_prob": 0.02, "witness_count": 2}, ["forgotten_commitments", "certificates_lost", "orphaned_physical_liability"]),
        ("-Version", "replay attack", {"has_monotonic_version": False}, {"version_replay_prob": 0.20}, ["version_replay_accepted", "rollback_silent_unbacking", "stale_ownership"]),
        ("-LocalRights", "partition + remote-right attack", {"has_local_resource_ownership": False}, {"partition_start_prob": 0.18, "adversarial_proposal_prob": 0.20, "attack_mode": "remote_right_overspend"}, ["remote_overspend_success", "ownership_conflicts", "remote_double_spend_events"]),
        ("-Transform", "handoff stress", {"has_replacement_before_release": False}, {"handoff_prob": 0.20, "handoff_crash_prob": 0.02}, ["replacement_before_release_violations", "unbacked_window_count", "silent_unbacking"]),
        ("-Degradation", "high resource pressure", {"has_policy_degradation": False}, {"proposal_prob": 0.75, "self_recovery_guarantee": 20.0}, ["rescued", "rejected", "blocked", "self_recovery_degradation_events", "reserve_efficiency"]),
        ("-AT-RISK", "inflation stress", {"has_at_risk_state": False}, {"inflation_prob": 0.20}, ["silent_unbacking", "release_violations", "ruptures", "at_risk", "residual_after_rupture"]),
    ]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    paired_rows: list[dict[str, object]] = []
    traces = extra_trace_count(args)
    seed = args.seed + 95_000
    for name, scenario, override, param_overrides, metrics in configs:
        params = make_params(args, **param_overrides)
        full_results, ablated_results = run_ablation_pair(params, traces, seed, override, progress_name=f"ablation {name}")

        full_summary = aggregate("commit_guard", full_results)
        full_summary["policy"] = f"commit_guard_full_matched_{ablation_policy_suffix(name)}"
        full_summary["label"] = "COMMITGUARD Full matched"
        full_summary["variant"] = "Full-matched"
        full_summary["ablation"] = name
        full_summary["scenario"] = scenario
        add_ablation_summary_aliases(full_summary)
        rows.append(annotate_rows([full_summary], "ablation", seed, traces, params, {"ablation": name, "scenario": scenario, "variant": "Full-matched"})[0])

        ablated_summary = aggregate("commit_guard", ablated_results)
        ablated_summary["policy"] = f"commit_guard_{ablation_policy_suffix(name)}"
        ablated_summary["label"] = f"COMMITGUARD {name}"
        ablated_summary["variant"] = "Ablated"
        ablated_summary["ablation"] = name
        ablated_summary["scenario"] = scenario
        add_ablation_summary_aliases(ablated_summary)
        rows.append(annotate_rows([ablated_summary], "ablation", seed, traces, params, {"ablation": name, "scenario": scenario, "variant": "Ablated"})[0])

        paired_rows.extend(ablation_paired_rows(scenario, name, full_results, ablated_results, metrics))

        for trace_id, (full_result, ablated_result) in enumerate(zip(full_results, ablated_results)):
            full_raw = result_to_row(full_result)
            full_raw["trace"] = trace_id
            full_raw["policy"] = f"commit_guard_full_matched_{ablation_policy_suffix(name)}"
            full_raw["policy_label"] = "COMMITGUARD Full matched"
            full_raw["variant"] = "Full"
            full_raw["ablation"] = name
            full_raw["scenario"] = scenario
            raw_rows.extend(annotate_rows([full_raw], "ablation", seed, traces, params, {"ablation": name, "scenario": scenario, "variant": "Full"}))

            ablated_raw = result_to_row(ablated_result)
            ablated_raw["trace"] = trace_id
            ablated_raw["policy"] = f"commit_guard_{ablation_policy_suffix(name)}"
            ablated_raw["policy_label"] = f"COMMITGUARD {name}"
            ablated_raw["variant"] = "Ablated"
            ablated_raw["ablation"] = name
            ablated_raw["scenario"] = scenario
            raw_rows.extend(annotate_rows([ablated_raw], "ablation", seed, traces, params, {"ablation": name, "scenario": scenario, "variant": "Ablated"}))
    write_csv(exp / "ablation.csv", rows)
    write_csv(exp / "ablation_raw.csv", raw_rows)
    write_csv(exp / "ablation_paired.csv", paired_rows)
    write_json(exp / "ablation.json", {"summary": rows, "raw_file": "ablation_raw.csv", "paired_file": "ablation_paired.csv"})
    write_metadata(exp, "ablation", args, make_params(args), traces, {"ablations": [c[0] for c in configs], "matched_full_baseline": True})


def scale_experiment(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "scalability")
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    robot_values = [5, 10, 20, 40, 80, 100]
    rho_values = [0.025, 0.05, 0.10]
    last_params = make_params(args)
    for robots in robot_values:
        for rho in rho_values:
            params = make_params(args, robots=robots, proposal_mode="poisson_per_robot", proposal_load_per_robot=rho)
            last_params = params
            summary, raw = run_point("scalability", params, extra_trace_count(args), args.seed + 100_000, ["central_commit_aware", "commit_guard"], {"robots": robots, "rho": rho, "proposal_load_per_robot": rho})
            rows.extend(summary)
            raw_rows.extend(raw)
            write_csv(exp / "scalability.csv", rows)
            write_csv(exp / "scale.csv", rows)
            write_csv(exp / "scalability_raw.csv", raw_rows)
            print(f"scalability complete: robots={robots}, rho={rho}, traces={extra_trace_count(args)}", flush=True)
    write_csv(exp / "scalability.csv", rows)
    write_csv(exp / "scale.csv", rows)
    write_csv(exp / "scalability_raw.csv", raw_rows)
    write_json(exp / "scalability.json", {"summary": rows, "raw_file": "scalability_raw.csv"})
    write_json(exp / "scale.json", {"summary": rows, "raw_file": "scalability_raw.csv"})
    write_metadata(exp, "scalability", args, last_params, extra_trace_count(args), {"robots": robot_values, "rho": rho_values})


def percentile_us(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    xs = sorted(values)
    idx = min(len(xs) - 1, max(0, math.ceil(q * len(xs)) - 1))
    return xs[idx] * 1_000_000.0


def median_microseconds(values: list[float]) -> float:
    return percentile_us(values, 0.50)


def accounting_microbench(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "microbenchmark")
    rng = random.Random(args.seed + 40_000)
    sizes = [10, 100, 1_000, 10_000, 100_000]
    rows: list[dict[str, object]] = []
    progress = ProgressBar("microbenchmark", len(sizes) * args.bench_repeats, enabled=PROGRESS_ENABLED)
    for size in sizes:
        commitments = [(rng.randrange(10), rng.randrange(10), rng.randrange(10), rng.uniform(3, 18)) for _ in range(size)]
        participants = (1, 4, 7)
        local_rights = {p: 100.0 for p in participants}
        local_req = {p: rng.uniform(3, 18) for p in participants}
        full_times: list[float] = []
        local_times: list[float] = []
        repeats = args.bench_repeats
        for _ in range(repeats):
            start = time.perf_counter()
            total = 0.0
            for a, b, c, demand in commitments:
                if a in participants or b in participants or c in participants:
                    total += demand
            _ = total <= 300.0
            full_times.append(time.perf_counter() - start)
            start = time.perf_counter()
            _ = all(local_rights[p] >= local_req[p] for p in participants)
            local_times.append(time.perf_counter() - start)
            progress.update()
        global_median = median_microseconds(full_times)
        local_median = median_microseconds(local_times)
        rows.append({"experiment": "microbenchmark", "seed": args.seed, "repeats": repeats, "outstanding_commitments": size, "global_scan_median_us": global_median, "global_scan_mean_us": mean(full_times) * 1_000_000.0, "global_scan_p95_us": percentile_us(full_times, 0.95), "global_scan_p99_us": percentile_us(full_times, 0.99), "participant_local_median_us": local_median, "participant_local_mean_us": mean(local_times) * 1_000_000.0, "participant_local_p95_us": percentile_us(local_times, 0.95), "participant_local_p99_us": percentile_us(local_times, 0.99), "full_scan_median_us": global_median, "local_check_median_us": local_median, "speedup_median": global_median / max(local_median, 1e-9), "speedup": global_median / max(local_median, 1e-9)})
    progress.close()
    write_csv(exp / "accounting_microbench.csv", rows)
    write_json(exp / "accounting_microbench.json", rows)
    write_metadata(exp, "microbenchmark", args, make_params(args), args.bench_repeats, {"outstanding_commitments": sizes})


INVARIANT_SUMMARY_COLUMNS = [
    "experiment",
    "trace_id",
    "policy",
    "invariant_violations",
    "capacity_violations",
    "double_spend_violations",
    "backing_violations",
    "version_violations",
    "release_violations",
    "certificate_hash_violations",
    "replacement_before_release_violations",
    "replay_accepted",
]


def invariant_raw_files(out_dir: Path) -> list[Path]:
    excluded_names = {
        "paired_analysis.csv",
        "default_paired_analysis.csv",
        "policy_capabilities.csv",
        "invariant_summary.csv",
        "invariant_summary_aggregate.csv",
        "ablation.csv",
        "accounting_microbench.csv",
        "microbenchmark.csv",
        "final_default_raw.csv",  # delivery alias, not another independent trace file
    }
    paths: list[Path] = []
    for csv_path in sorted(out_dir.rglob("*_raw.csv")):
        if "statistics" in csv_path.relative_to(out_dir).parts:
            continue
        if csv_path.name in excluded_names:
            continue
        if csv_path.name.endswith("_summary.csv"):
            continue
        paths.append(csv_path)
    return paths


def invariant_number(row: dict[str, str], key: str) -> float:
    value = numeric_cell(row.get(key))
    return 0.0 if value is None else value


def write_invariant_summary(out_dir: Path) -> None:
    stats = out_dir / "statistics"
    stats.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, object]] = []
    aggregate: dict[tuple[str, str], dict[str, object]] = {}
    metric_columns = INVARIANT_SUMMARY_COLUMNS[3:]
    for csv_path in invariant_raw_files(out_dir):
        try:
            with csv_path.open("r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                if "invariant_violations" not in (reader.fieldnames or []):
                    continue
                for row in reader:
                    if "policy" not in row:
                        continue
                    experiment = row.get("experiment", csv_path.parent.name)
                    policy = row.get("policy", "")
                    out_row = {
                        "experiment": experiment,
                        "trace_id": row.get("trace_id", row.get("trace", "")),
                        "policy": policy,
                        "invariant_violations": row.get("invariant_violations", ""),
                        "capacity_violations": row.get("capacity_violations", ""),
                        "double_spend_violations": row.get("double_spend_violations", ""),
                        "backing_violations": row.get("backing_violations", ""),
                        "version_violations": row.get("version_violations", ""),
                        "release_violations": row.get("release_violations", ""),
                        "certificate_hash_violations": row.get("certificate_hash_violations", ""),
                        "replacement_before_release_violations": row.get("replacement_before_release_violations", ""),
                        "replay_accepted": row.get("replay_accepted", ""),
                    }
                    rows.append(out_row)
                    key = (experiment, policy)
                    if key not in aggregate:
                        aggregate[key] = {"experiment": experiment, "policy": policy, "raw_rows": 0}
                        for metric in metric_columns:
                            aggregate[key][f"{metric}_total"] = 0.0
                            aggregate[key][f"{metric}_max"] = 0.0
                    aggregate[key]["raw_rows"] = int(aggregate[key]["raw_rows"]) + 1
                    for metric in metric_columns:
                        value = invariant_number(row, metric)
                        aggregate[key][f"{metric}_total"] = float(aggregate[key][f"{metric}_total"]) + value
                        aggregate[key][f"{metric}_max"] = max(float(aggregate[key][f"{metric}_max"]), value)
        except UnicodeDecodeError:
            continue
    write_csv(stats / "invariant_summary.csv", rows)
    write_json(stats / "invariant_summary.json", rows)
    aggregate_rows = []
    for key in sorted(aggregate):
        aggregate_row = aggregate[key]
        raw_count = max(1, int(aggregate_row["raw_rows"]))
        for metric in metric_columns:
            aggregate_row[f"{metric}_mean"] = float(aggregate_row[f"{metric}_total"]) / raw_count
        aggregate_rows.append(aggregate_row)
    write_csv(stats / "invariant_summary_aggregate.csv", aggregate_rows)
    write_json(stats / "invariant_summary_aggregate.json", aggregate_rows)
    default_dir = out_dir / "default"
    paired = default_dir / "paired_analysis.csv"
    if paired.exists():
        (stats / "paired_analysis.csv").write_text(paired.read_text(encoding="utf-8"), encoding="utf-8")
        paired_json = default_dir / "paired_analysis.json"
        if paired_json.exists():
            (stats / "paired_analysis.json").write_text(paired_json.read_text(encoding="utf-8"), encoding="utf-8")


def print_default_summary(out_dir: Path) -> None:
    path = out_dir / "default_summary.csv"
    if not path.exists():
        path = out_dir / "default" / "default_summary.csv"
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    print("\nDefault workload mean per trace")
    print("policy,rescued,missed,rejected,failed,deadline,unfinished,silent,blocked,at_risk,violations")
    for row in rows:
        print(
            f"{row['label']},"
            f"{float(row['rescued_mean']):.2f},"
            f"{float(row['missed_mean']):.2f},"
            f"{float(row['rejected_mean']):.2f},"
            f"{float(row['failed_mean']):.2f},"
            f"{float(row['deadline_missed_mean']):.2f},"
            f"{float(row['unfinished_mean']):.2f},"
            f"{float(row['silent_unbacking_mean']):.2f},"
            f"{float(row['blocked_mean']):.2f},"
            f"{float(row['at_risk_mean']):.2f},"
            f"{float(row['invariant_violations_mean']):.2f}"
        )


