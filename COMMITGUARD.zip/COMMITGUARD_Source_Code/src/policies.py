from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Iterable, Optional

from .models import *

def valid_visible_proposal(prop: Proposal, params: Params) -> bool:
    if not (0 <= prop.carrier < params.robots):
        return False
    if prop.support is not None and not (0 <= prop.support < params.robots):
        return False
    if prop.support is not None and prop.support == prop.carrier:
        return False
    public_amounts = (prop.immediate_cost, prop.carrier_bound, prop.support_bound, prop.settlement_ratio)
    if any(not math.isfinite(value) or value < 0 for value in public_amounts):
        return False
    if prop.deadline <= 0 or prop.duration <= 0:
        return False
    return True


def validate_simulator_ground_truth(prop: Proposal) -> bool:
    hidden_amounts = (prop.true_carrier_bound, prop.true_support_bound)
    return all(math.isfinite(value) and value >= 0 for value in hidden_amounts)


def valid_proposal(prop: Proposal, params: Params) -> bool:
    return valid_visible_proposal(prop, params) and validate_simulator_ground_truth(prop)


def claimed_requirement(prop: Proposal) -> dict[int, float]:
    req = {prop.carrier: prop.carrier_bound}
    if prop.support is not None:
        req[prop.support] = prop.support_bound
    return req


def true_requirement(prop: Proposal) -> dict[int, float]:
    req = {prop.carrier: prop.true_carrier_bound}
    if prop.support is not None:
        req[prop.support] = prop.true_support_bound
    return req


def minimum_thresholds(params: Params, prefix: str) -> dict[int, float]:
    return {
        0: getattr(params, f"{prefix}_low"),
        1: getattr(params, f"{prefix}_medium"),
        2: getattr(params, f"{prefix}_high"),
    }


def certified_minimum_requirement(prop: Proposal, params: Params) -> dict[int, float]:
    """Policy-visible minimum backing; never reads hidden true demand fields."""
    carrier_min = minimum_thresholds(params, "min_carrier").get(prop.criticality, params.min_carrier_low)
    support_min = minimum_thresholds(params, "min_support").get(prop.criticality, params.min_support_low)
    req = {prop.carrier: carrier_min}
    if prop.support is not None:
        req[prop.support] = support_min
    return req


def merge_requirement_max(base: dict[int, float], floor: dict[int, float]) -> dict[int, float]:
    merged = dict(base)
    for robot_id, amount in floor.items():
        merged[robot_id] = max(merged.get(robot_id, 0.0), amount)
    return merged


def enforced_requirement(policy: str, prop: Proposal, params: Params) -> dict[int, float]:
    req = claimed_requirement(prop)
    if caps(policy).has_certified_minimum_backing:
        req = merge_requirement_max(req, certified_minimum_requirement(prop, params))
    return req


def minimum_backing_gap(prop: Proposal, params: Params) -> float:
    claimed = claimed_requirement(prop)
    certified = certified_minimum_requirement(prop, params)
    return sum(max(0.0, amount - claimed.get(robot_id, 0.0)) for robot_id, amount in certified.items())


def lacks_certified_minimum_backing(commitment: Commitment) -> bool:
    for robot_id, minimum in commitment.certified_min_req.items():
        if commitment.reserved.get(robot_id, 0.0) + 1e-9 < minimum:
            return True
    return False


def record_minimum_backing_mint(policy: str, prop: Proposal, commitment: Commitment, result: PolicyResult, params: Params) -> None:
    if prop.adversarial_kind != "malicious_underreport":
        return
    gap = minimum_backing_gap(prop, params)
    underbacked = lacks_certified_minimum_backing(commitment)
    if underbacked and not commitment.minimum_backing_violation_recorded:
        result.minimum_backing_attack_success += 1
        result.infeasible_mint_events += 1
        commitment.minimum_backing_violation_recorded = True
        if caps(policy).has_certified_minimum_backing:
            raise AssertionError("COMMIT GUARD minted a malicious-underreport proposal below its certified minimum backing")
    if caps(policy).has_certified_minimum_backing and gap > 1e-9 and not underbacked:
        result.minimum_backing_enforced += 1
        result.minimum_backing_extra_reserved += gap


def can_cover(robots: list[Robot], req: dict[int, float], carrier: Optional[int] = None, immediate_cost: float = 0.0) -> bool:
    for robot_id, amount in req.items():
        extra = immediate_cost if carrier is not None and robot_id == carrier else 0.0
        if robot_id < 0 or robot_id >= len(robots) or not robots[robot_id].active:
            return False
        if robots[robot_id].free + 1e-9 < amount + extra:
            return False
    return True


def lower_priority_live(live: list[Commitment], criticality: int) -> list[Commitment]:
    return sorted(
        [c for c in live if c.status in ACTIVE_STATUSES and c.criticality < criticality],
        key=lambda c: (c.criticality, -c.due_epoch, c.ident),
    )


def cancel_one_lower_priority(
    live: list[Commitment],
    robots: list[Robot],
    criticality: int,
    result: PolicyResult,
    policy: str,
) -> bool:
    candidates = lower_priority_live(live, criticality)
    if not candidates:
        return False
    old = candidates[0]
    old.status = STATUS_RUPTURED
    release_reservations(old, robots, result, policy, "unsafe_cancel")
    live.remove(old)
    result.silent_unbacking += 1
    mark_missed(result, "failed")
    return True


def declared_need_exceeds_single_robot_capacity(prop: Proposal, params: Params) -> bool:
    declared = prop.immediate_cost + max(prop.carrier_bound, prop.support_bound)
    return declared > params.initial_energy - params.self_recovery_guarantee + 1e-9


def partition_group_for_robot(partition: Optional[PartitionState], robot_id: int) -> Optional[frozenset[int]]:
    if partition is None:
        return None
    for group in partition.groups:
        if robot_id in group:
            return group
    return None


def remote_overspend_victim(
    prop: Proposal,
    partition: Optional[PartitionState],
    robots: list[Robot],
    live: list[Commitment],
) -> Optional[int]:
    if not (prop.adversarial and prop.adversarial_kind == "remote_right_overspend" and prop.uses_remote_rights):
        return None
    if partition is None or not (0 <= prop.carrier < len(robots)) or not robots[prop.carrier].active:
        return None
    requester_group = partition_group_for_robot(partition, prop.carrier)
    if requester_group is None:
        return None
    participant_set = set(prop.participants)
    live_reserved_ids_by_robot: dict[int, set[int]] = {}
    for commitment in live:
        if not commitment.protected_present or commitment.status not in {STATUS_LIVE, STATUS_DEGRADED}:
            continue
        for robot_id, amount in commitment.reserved.items():
            if amount > 1e-9:
                live_reserved_ids_by_robot.setdefault(robot_id, set()).add(commitment.ident)

    remote_candidates = sorted(
        robot_id
        for group in partition.groups
        if group != requester_group
        for robot_id in group
        if 0 <= robot_id < len(robots)
        and robots[robot_id].active
        and robot_id not in participant_set
        and robots[robot_id].reserved
        and any(commitment_id in live_reserved_ids_by_robot.get(robot_id, set()) for commitment_id in robots[robot_id].reserved)
    )
    return remote_candidates[0] if remote_candidates else None


def remote_overspend_amount(prop: Proposal, victim: int, robots: list[Robot]) -> float:
    existing_reserved = sum(robots[victim].reserved.values())
    requested_remote_amount = max(prop.carrier_bound, prop.support_bound, 1.0)
    if existing_reserved <= 1e-9:
        return 0.0
    return min(existing_reserved, max(1.0, requested_remote_amount))


def apply_remote_overspend_attack(
    policy: str,
    prop: Proposal,
    commitment: Commitment,
    victim: Optional[int],
    robots: list[Robot],
    result: PolicyResult,
) -> None:
    if victim is None:
        return
    amount = remote_overspend_amount(prop, victim, robots)
    if amount <= 1e-9 or policy == "immediate_only":
        return
    result.remote_overspend_accepted += 1
    commitment.remote_claims[victim] = commitment.remote_claims.get(victim, 0.0) + amount
    robots[victim].remote_reserved[commitment.ident] = robots[victim].remote_reserved.get(commitment.ident, 0.0) + amount


def visible_planner_error(policy: str, prop: Proposal, params: Params, partition: Optional[PartitionState]) -> bool:
    if not valid_visible_proposal(prop, params):
        return True
    if prop.requested_self_degradation:
        return True
    if prop.silent_cancel_requested:
        return True
    if prop.uses_remote_rights and partition is not None and caps(policy).has_local_resource_ownership:
        return True
    if declared_need_exceeds_single_robot_capacity(prop, params):
        return True
    return False


def admit(
    policy: str,
    prop: Proposal,
    partition: Optional[PartitionState],
    robots: list[Robot],
    live: list[Commitment],
    result: PolicyResult,
    params: Params,
) -> None:
    result.proposals += 1

    visible_error = visible_planner_error(policy, prop, params, partition)
    remote_victim = remote_overspend_victim(prop, partition, robots, live)
    if prop.adversarial:
        result.adversarial_proposals += 1
        result.attack_attempts += 1
        if visible_error:
            result.immediately_detectable_attacks += 1
        if prop.adversarial_kind == "unauthorized_degradation":
            result.illegal_degradation_attempts += 1
        elif prop.adversarial_kind == "remote_right_overspend":
            if remote_victim is not None:
                result.remote_overspend_attempts += 1
        elif prop.adversarial_kind == "silent_cancellation":
            result.silent_cancellation_attempts += 1
        elif prop.adversarial_kind == "underdeclared_bound":
            result.underdeclared_attempts += 1
        elif prop.adversarial_kind == "malicious_underreport":
            result.minimum_backing_attack_attempts += 1

    if visible_error:
        result.planner_error_proposals += 1
        if caps(policy).rejects_visible_planner_errors:
            result.planner_errors_rejected += 1
            if prop.adversarial:
                result.adversarial_rejected += 1
                result.detection_count += 1
                if prop.adversarial_kind == "unauthorized_degradation":
                    result.illegal_degradation_rejected += 1
                elif prop.adversarial_kind == "remote_right_overspend":
                    if remote_victim is not None:
                        result.remote_overspend_rejected += 1
                elif prop.adversarial_kind == "silent_cancellation":
                    result.silent_cancellation_rejected += 1
            else:
                result.false_rejection_benign += 1
            mark_missed(result, "rejected")
            return

    if not valid_visible_proposal(prop, params) and prop.support is not None and not (0 <= prop.support < params.robots):
        mark_missed(result, "rejected")
        return

    if not valid_visible_proposal(prop, params) and not (0 <= prop.carrier < params.robots):
        mark_missed(result, "rejected")
        return

    if not validate_simulator_ground_truth(prop):
        mark_missed(result, "rejected")
        return

    if prop.adversarial:
        result.adversarial_accepted += 1
        if prop.adversarial_kind == "unauthorized_degradation":
            result.illegal_degradation_accepted += 1
        elif prop.adversarial_kind == "remote_right_overspend":
            pass
        elif prop.adversarial_kind == "silent_cancellation":
            result.silent_cancellation_accepted += 1

    if prop.silent_cancel_requested:
        result.attack_success += 1
        result.adversarial_physical_violation += 1
        result.silent_unbacking += 1
        result.commitment_loss += 1
        mark_missed(result, "failed")
        return

    if not active_participants(prop.participants, robots):
        mark_missed(result, "pre_start_failed")
        return

    if caps(policy).requires_global_view and not all_team_connected(partition):
        if prop.adversarial and prop.adversarial_kind == "remote_right_overspend" and remote_victim is not None:
            result.remote_overspend_blocked += 1
        mark_blocked(result)
        return

    if caps(policy).has_local_resource_ownership and not same_partition_group(partition, prop.participants):
        if prop.adversarial and prop.adversarial_kind == "remote_right_overspend" and remote_victim is not None:
            result.remote_overspend_blocked += 1
        mark_blocked(result)
        return

    if policy == "immediate_only":
        carrier = robots[prop.carrier]
        if carrier.active and carrier.free + 1e-9 >= prop.immediate_cost:
            spend_energy(robots, prop.carrier, prop.immediate_cost, result)
            commitment = Commitment(
                ident=prop.ident,
                proposal=prop,
                initiator=prop.carrier,
                carrier=prop.carrier,
                support=prop.support,
                criticality=prop.criticality,
                created_epoch=prop.epoch,
                due_epoch=prop.due_epoch,
                finish_epoch=prop.finish_epoch,
                claimed_req=claimed_requirement(prop),
                true_req=true_requirement(prop),
                certified_min_req=certified_minimum_requirement(prop, params),
                initial_claimed_req=claimed_requirement(prop),
                reserved={},
                contract_guarantee_requirements={"full": claimed_requirement(prop)},
            )
            configure_certificate_persistence(policy, commitment, params)
            save_version_snapshot(commitment, event="mint", predecessor=0, authorization_reason="immediate_execution")
            publish_certificate(policy, commitment, robots, result)
            record_minimum_backing_mint(policy, prop, commitment, result, params)
            live.append(commitment)
            result.admitted += 1
            if prop.adversarial:
                result.adversarial_admitted += 1
                result.admitted_attacks += 1
                if prop.adversarial_kind == "underdeclared_bound":
                    result.underdeclared_admitted += 1
            apply_remote_overspend_attack(policy, prop, commitment, remote_victim, robots, result)
            result.silent_unbacking += 1
        else:
            mark_missed(result, "rejected")
        return

    commitment = create_commitment(policy, prop, robots, result, params, partition)
    if commitment is None and policy == "priority_cancel":
        while commitment is None and cancel_one_lower_priority(live, robots, prop.criticality, result, policy):
            commitment = create_commitment(policy, prop, robots, result, params)

    if commitment is None:
        if policy == "commit_guard":
            attempted = enforced_requirement(policy, prop, params)
            pending_by_robot = {
                robot_id: sum(
                    max(0.0, c.pending_reserved.get(robot_id, 0.0))
                    for c in live if c.protected_present
                ) + sum(robots[robot_id].pending_execution_cost.values())
                for robot_id in attempted
            }
            if any(amount > 1e-9 for amount in pending_by_robot.values()) and all(
                0 <= robot_id < len(robots) and robots[robot_id].active
                and robots[robot_id].free + pending_by_robot[robot_id] + 1e-9
                >= amount + (prop.immediate_cost if robot_id == prop.carrier else 0.0)
                for robot_id, amount in attempted.items()
            ):
                result.blocked_by_pending_resources += 1
        if prop.adversarial_kind == "malicious_underreport" and caps(policy).has_certified_minimum_backing and minimum_backing_gap(prop, params) > 1e-9:
            result.minimum_backing_rejected += 1
        mark_missed(result, "rejected")
        return

    live.append(commitment)
    result.admitted += 1
    if prop.adversarial:
        result.adversarial_admitted += 1
        result.admitted_attacks += 1
        if prop.adversarial_kind == "underdeclared_bound":
            result.underdeclared_admitted += 1
    apply_remote_overspend_attack(policy, prop, commitment, remote_victim, robots, result)
    check_invariants(policy, robots, live, result, "admit")


def choose_live_by_pick(live: list[Commitment], pick: float, include_at_risk: bool = False) -> Optional[Commitment]:
    statuses = ACTIVE_STATUSES if include_at_risk else {STATUS_LIVE, STATUS_DEGRADED}
    candidates = [c for c in live if c.protected_present and c.status in statuses]
    if not candidates:
        return None
    index = min(len(candidates) - 1, int(pick * len(candidates)))
    return candidates[index]


def lifecycle_protected(policy: str) -> bool:
    return policy in PROTECTED_POLICIES


def record_lifecycle_integrity_loss(
    commitment: Commitment,
    policy: str,
    live: list[Commitment],
    robots: list[Robot],
    result: PolicyResult,
    epoch: int,
    release_backing: bool,
    reason: str,
) -> None:
    released = sum(commitment.reserved.values())
    if release_backing and released > 1e-9:
        release_reservations(commitment, robots, result, policy, reason)
        result.forgotten_and_resources_reused += 1
        result.silent_unbacking += 1
        result.release_violations += 1
        result.invariant_violations += 1
    commitment.protected_present = False
    commitment.status = STATUS_FORGOTTEN
    result.commitment_loss += 1
    result.attack_success += 1
    result.adversarial_physical_violation += 1
    if commitment.physical_live:
        result.physical_commitments_still_live += 1
        result.orphaned_liability += sum(commitment.true_req.values())
    if commitment in live:
        live.remove(commitment)
    record_terminal(commitment, result, epoch)


def apply_lifecycle_attack(
    policy: str,
    event: LifecycleAttackEvent,
    live: list[Commitment],
    robots: list[Robot],
    result: PolicyResult,
) -> None:
    commitment = choose_live_by_pick(live, event.pick, include_at_risk=False)
    if commitment is None or not commitment.physical_live:
        return

    result.lifecycle_attack_attempts += 1
    if event.kind == "silent_cancellation":
        result.silent_cancellation_attempts += 1
        if lifecycle_protected(policy):
            result.silent_cancellation_rejected += 1
            result.detection_count += 1
            return
        result.silent_cancellation_accepted += 1
        result.silent_cancellation_success += 1
        record_lifecycle_integrity_loss(
            commitment,
            policy,
            live,
            robots,
            result,
            event.epoch,
            release_backing=(policy != "immediate_only"),
            reason="unsafe_lifecycle_cancel",
        )
        return

    if event.kind == "unauthorized_degradation":
        result.illegal_degradation_attempts += 1
        if lifecycle_protected(policy):
            result.illegal_degradation_rejected += 1
            result.detection_count += 1
            return
        result.illegal_degradation_accepted += 1
        result.illegal_degradation_success += 1
        result.illegal_degradation_violations += 1
        for robot_id in commitment.participants:
            if 0 <= robot_id < len(robots) and robots[robot_id].active:
                robots[robot_id].self_level = SELF_STRANDED
        commitment.guarantee = "illegal_abandonment"
        record_lifecycle_integrity_loss(
            commitment,
            policy,
            live,
            robots,
            result,
            event.epoch,
            release_backing=(policy != "immediate_only"),
            reason="unsafe_lifecycle_degradation",
        )


def restore_snapshot_without_changing_physical_truth(commitment: Commitment, robots: list[Robot], snapshot: dict[str, object]) -> None:
    for robot in robots:
        robot.reserved.pop(commitment.ident, None)
        robot.remote_reserved.pop(commitment.ident, None)

    old_true = dict(commitment.true_req)
    commitment.carrier = int(snapshot["carrier"])
    support = snapshot["support"]
    commitment.support = None if support is None else int(support)
    commitment.status = str(snapshot["status"])
    commitment.guarantee = str(snapshot["guarantee"])
    commitment.claimed_req = {int(k): float(v) for k, v in dict(snapshot["claimed_req"]).items()}
    commitment.initial_claimed_req = {int(k): float(v) for k, v in dict(snapshot["initial_claimed_req"]).items()}
    commitment.reserved = {int(k): float(v) for k, v in dict(snapshot["reserved"]).items()}
    commitment.effective_reserved = dict(commitment.reserved)
    commitment.pending_reserved.clear()
    commitment.pending_consumed_backing.clear()
    commitment.pending_operation = ""
    commitment.pending_version = None
    commitment.remote_claims.clear()
    commitment.true_req = old_true
    commitment.protected_present = bool(snapshot.get("protected_present", True))

    for robot_id, amount in commitment.reserved.items():
        if 0 <= robot_id < len(robots) and robots[robot_id].active:
            robots[robot_id].reserved[commitment.ident] = amount


def apply_replay(policy: str, commitment: Commitment, robots: list[Robot], result: PolicyResult, stale_offset: int) -> None:
    result.replay_attempts += 1
    current_version = commitment.effective_version if caps(policy).has_certificate_auth else commitment.version
    stale_version = max(1, current_version - stale_offset)
    if stale_version >= current_version:
        result.replay_current_noop += 1
        return
    result.replay_effective_attempts += 1
    if caps(policy).has_monotonic_version:
        result.replay_rejected += 1
        result.detection_count += 1
        return
    result.version_replay_accepted += 1
    result.replay_accepted += 1
    result.attack_success += 1
    result.version_violations += 1
    result.invariant_violations += 1
    result.silent_unbacking += 1
    snapshot = commitment.certificate_history.get(stale_version)
    if snapshot is not None:
        current_participants = set(commitment.participants)
        restore_snapshot_without_changing_physical_truth(commitment, robots, snapshot)
        commitment.version = stale_version
        commitment.effective_version = stale_version
        if set(commitment.participants) != current_participants:
            result.stale_ownership += 1
        if not is_backed_by_reserved(commitment, robots, use_true=True):
            result.rollback_silent_unbacking += 1
            result.resource_reuse_after_rollback += 1
            result.unbacked_window_count += 1
            result.physical_underbacking_events += 1
        for robot in robots:
            if robot.active and policy != "immediate_only" and robot.total_reserved > robot.energy - robot.self_reserve + 1e-9:
                result.rollback_double_spend += 1
                break
        result.max_version_seen[commitment.ident] = commitment.version


