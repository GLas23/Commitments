"""Command-line entry point and compatibility facade for COMMITGUARD experiments.

The implementation is organized in six modules. Their functions share a
linked symbol table because lifecycle transitions, policies, and invariant
checks call each other. The linker only resolves names; it does not duplicate
or wrap experiment algorithms.
"""
from __future__ import annotations

import sys
from pathlib import Path

_PACKAGE_ROOT = Path(__file__).resolve().parent.parent
if str(_PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(_PACKAGE_ROOT))

from src import models, simulation, commitment, policies, security, experiments

_MODULES = (models, simulation, commitment, policies, security, experiments)
_symbols = {}
for _module in _MODULES:
    for _name, _value in vars(_module).items():
        if not _name.startswith("__") and _name not in {"models", "simulation", "commitment", "policies", "security", "experiments"}:
            _symbols[_name] = _value
for _module in _MODULES:
    vars(_module).update(_symbols)
globals().update(_symbols)

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Reproduce the formal COMMITGUARD experiments reported in paper Sections 6.1--6.7."
    )
    parser.add_argument(
        "--experiment",
        choices=[
            "default", "partition", "inflation", "crash_witness", "handoff",
            "security_attacks", "ablation", "scale", "microbench", "all",
        ],
        default="default",
    )
    parser.add_argument("--traces", type=int, default=500)
    parser.add_argument("--sweep-traces", type=int, default=200)
    parser.add_argument("--extra-traces", type=int, default=200)
    parser.add_argument("--bench-repeats", type=int, default=200)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--out-dir", type=Path, default=Path("results"))
    parser.add_argument("--no-progress", action="store_true")
    parser.add_argument("--robots", type=int, default=Params.robots)
    parser.add_argument("--proposal-prob", type=float, default=Params.proposal_prob)
    parser.add_argument("--proposal-mode", choices=["bernoulli", "poisson_per_robot"], default=Params.proposal_mode)
    parser.add_argument("--proposal-load-per-robot", type=float, default=Params.proposal_load_per_robot)
    parser.add_argument("--partition-prob", type=float, default=Params.partition_start_prob)
    parser.add_argument("--partition-duration-min", type=int, default=Params.partition_duration_min)
    parser.add_argument("--partition-duration-max", type=int, default=Params.partition_duration_max)
    parser.add_argument("--inflation-prob", type=float, default=Params.inflation_prob)
    parser.add_argument("--crash-prob", type=float, default=Params.crash_prob)
    parser.add_argument("--self-recovery", type=float, default=Params.self_recovery_guarantee)
    parser.add_argument("--witness-count", type=int, default=Params.witness_count)
    parser.add_argument("--certificate-ack-delay-epochs", type=int, default=Params.certificate_ack_delay_epochs)
    parser.add_argument("--retire-recovery-wait-epochs", type=int, default=Params.retire_recovery_wait_epochs)
    parser.add_argument("--handoff-prob", type=float, default=Params.handoff_prob)
    parser.add_argument("--handoff-replacement-scarcity", type=float, default=Params.handoff_replacement_scarcity)
    parser.add_argument("--handoff-crash-prob", type=float, default=Params.handoff_crash_prob)
    parser.add_argument("--handoff-old-crash-prob", type=float, default=Params.handoff_old_crash_prob)
    parser.add_argument("--handoff-partition-after-certificate-prob", type=float, default=Params.handoff_partition_after_certificate_prob)
    parser.add_argument("--version-replay-prob", type=float, default=Params.version_replay_prob)
    parser.add_argument("--lifecycle-attack-prob", type=float, default=Params.lifecycle_attack_prob)
    parser.add_argument("--lifecycle-attack-kind", choices=["mixed", "silent_cancellation", "unauthorized_degradation"], default=Params.lifecycle_attack_kind)
    parser.add_argument("--adversarial-proposal-prob", type=float, default=Params.adversarial_proposal_prob)
    parser.add_argument("--adversarial-cost-multiplier", type=float, default=Params.adversarial_cost_multiplier)
    parser.add_argument(
        "--attack-mode",
        choices=["mixed", "duplicate_participant", "impossible_cost", "underdeclared_bound",
                 "unauthorized_degradation", "remote_right_overspend", "silent_cancellation",
                 "malicious_underreport"],
        default=Params.attack_mode,
    )
    parser.add_argument("--bound-error", type=float, default=Params.bound_error)
    parser.add_argument("--underreport-fraction", type=float, default=Params.underreport_fraction)
    parser.add_argument("--min-carrier-low", type=float, default=Params.min_carrier_low)
    parser.add_argument("--min-carrier-medium", type=float, default=Params.min_carrier_medium)
    parser.add_argument("--min-carrier-high", type=float, default=Params.min_carrier_high)
    parser.add_argument("--min-support-low", type=float, default=Params.min_support_low)
    parser.add_argument("--min-support-medium", type=float, default=Params.min_support_medium)
    parser.add_argument("--min-support-high", type=float, default=Params.min_support_high)
    parser.add_argument("--deadline-tightness", type=float, default=Params.deadline_tightness)
    parser.add_argument("--evidence-delay-max", type=int, default=Params.evidence_delay_max)
    parser.add_argument("--evidence-missing-prob", type=float, default=Params.evidence_missing_prob)
    parser.add_argument("--evidence-invalid-prob", type=float, default=Params.evidence_invalid_prob)
    parser.add_argument("--contract-degraded-carrier-requirement", type=float, default=Params.contract_degraded_carrier_requirement)
    parser.add_argument("--contract-degraded-support-requirement", type=float, default=Params.contract_degraded_support_requirement)
    args = parser.parse_args()

    global PROGRESS_ENABLED
    PROGRESS_ENABLED = not args.no_progress
    for _module in _MODULES:
        _module.PROGRESS_ENABLED = PROGRESS_ENABLED
    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    write_capability_table(out_dir)

    experiments = {
        "default": default_workload,
        "partition": partition_sweep,
        "inflation": inflation_sweep,
        "crash_witness": crash_witness_sweep,
        "handoff": handoff_stress,
        "security_attacks": security_attacks_experiment,
        "ablation": ablation_experiment,
        "scale": scale_experiment,
        "microbench": accounting_microbench,
    }
    selected = list(experiments) if args.experiment == "all" else [args.experiment]
    for name in selected:
        experiments[name](args, out_dir)

    write_invariant_summary(out_dir)
    print(f"Wrote results to: {out_dir}")
    if args.experiment in {"default", "all"}:
        print_default_summary(out_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
