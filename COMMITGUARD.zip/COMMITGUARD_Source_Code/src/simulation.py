from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Iterable, Optional

from .models import *

def weighted_criticality(rng: random.Random) -> int:
    x = rng.random()
    if x < 0.50:
        return 0
    if x < 0.80:
        return 1
    return 2


def stream_seed(seed: int, name: str) -> int:
    digest = hashlib.sha256(f"{seed}:{name}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def rng_stream(seed: int, name: str) -> random.Random:
    return random.Random(stream_seed(seed, name))


def epoch_rng(seed: int, family: str, epoch: int) -> random.Random:
    return random.Random(stream_seed(seed, f"{family}:{epoch}"))


def poisson(rng: random.Random, lam: float) -> int:
    if lam <= 0:
        return 0
    if lam < 30:
        threshold = math.exp(-lam)
        k = 0
        product = 1.0
        while product > threshold:
            k += 1
            product *= rng.random()
        return k - 1
    return max(0, int(round(rng.gauss(lam, math.sqrt(lam)))))


def proposal_count_for_epoch(params: Params, arrival_rng: random.Random) -> int:
    if params.proposal_mode == "poisson_per_robot":
        return poisson(arrival_rng, params.proposal_load_per_robot * params.robots)
    return 1 if arrival_rng.random() < params.proposal_prob else 0


def maybe_adversarial(rng: random.Random, params: Params) -> tuple[bool, str]:
    if rng.random() >= params.adversarial_proposal_prob:
        return False, ""
    if params.attack_mode != "mixed":
        return True, params.attack_mode
    return True, rng.choice(
        [
            "duplicate_participant",
            "impossible_cost",
            "underdeclared_bound",
            "unauthorized_degradation",
            "remote_right_overspend",
            "silent_cancellation",
        ]
    )


def true_factor_from_bound_error(rng: random.Random, epsilon: float) -> float:
    if epsilon >= 0:
        return 1.0 + rng.uniform(0.0, epsilon)
    return max(0.05, 1.0 - rng.uniform(0.0, abs(epsilon)))


def duration_before_deadline(timing_rng: random.Random, params: Params, deadline: int) -> int:
    lower = max(1, params.completion_duration_min)
    if params.deadline_tightness <= 1.0:
        upper = min(params.completion_duration_max, max(lower, int(math.floor(deadline * params.deadline_tightness))))
    else:
        upper = max(lower, int(math.ceil(deadline * params.deadline_tightness)))
    return timing_rng.randint(lower, max(lower, upper))


def generate_trace(params: Params, seed: int) -> Trace:
    arrival_rng = rng_stream(seed, "task_arrival")
    assignment_rng = rng_stream(seed, "assignment")
    cost_rng = rng_stream(seed, "cost")
    criticality_rng = rng_stream(seed, "criticality")
    timing_rng = rng_stream(seed, "duration_deadline")
    crash_rng = rng_stream(seed, "crash")
    adversarial_rng = rng_stream(seed, "adversarial")
    evidence_rng = rng_stream(seed, "evidence")
    proposals: dict[int, list[Proposal]] = {e: [] for e in range(params.epochs)}
    inflations: dict[int, list[InflationEvent]] = {e: [] for e in range(params.epochs)}
    crashes: dict[int, list[int]] = {e: [] for e in range(params.epochs)}
    handoffs: dict[int, list[HandoffEvent]] = {e: [] for e in range(params.epochs)}
    replays: dict[int, list[ReplayEvent]] = {e: [] for e in range(params.epochs)}
    lifecycle_attacks: dict[int, list[LifecycleAttackEvent]] = {e: [] for e in range(params.epochs)}
    partitions: dict[int, PartitionState] = {}

    ident = 0
    for epoch in range(params.epochs):
        for _ in range(proposal_count_for_epoch(params, arrival_rng)):
            carrier = assignment_rng.randrange(params.robots)
            support = None
            support_bound = 0.0
            if assignment_rng.random() < params.support_required_prob:
                choices = [r for r in range(params.robots) if r != carrier]
                support = assignment_rng.choice(choices)
                support_bound = cost_rng.uniform(params.support_bound_min, params.support_bound_max)

            adversarial, adversarial_kind = maybe_adversarial(adversarial_rng, params)
            immediate_cost = cost_rng.uniform(params.immediate_cost_min, params.immediate_cost_max)
            carrier_bound = cost_rng.uniform(params.carrier_bound_min, params.carrier_bound_max)
            deadline = timing_rng.randint(6, 14)
            duration = duration_before_deadline(timing_rng, params, deadline)
            true_factor = true_factor_from_bound_error(cost_rng, params.bound_error)
            true_support_factor = true_factor_from_bound_error(cost_rng, params.bound_error)
            original_carrier_bound = carrier_bound
            original_support_bound = support_bound
            requested_self_degradation = ""
            uses_remote_rights = False
            silent_cancel_requested = False

            if adversarial and adversarial_kind == "duplicate_participant":
                support = carrier
                support_bound = cost_rng.uniform(params.support_bound_min, params.support_bound_max)
            elif adversarial and adversarial_kind == "impossible_cost":
                immediate_cost *= params.adversarial_cost_multiplier
                carrier_bound *= params.adversarial_cost_multiplier
                support_bound *= params.adversarial_cost_multiplier
            elif adversarial and adversarial_kind == "underdeclared_bound":
                true_factor *= params.adversarial_cost_multiplier
                true_support_factor *= params.adversarial_cost_multiplier
            elif adversarial and adversarial_kind == "unauthorized_degradation":
                requested_self_degradation = SELF_STRANDED
            elif adversarial and adversarial_kind == "remote_right_overspend":
                uses_remote_rights = True
            elif adversarial and adversarial_kind == "silent_cancellation":
                silent_cancel_requested = True
            elif adversarial and adversarial_kind == "malicious_underreport":
                fraction = min(1.0, max(0.0, params.underreport_fraction))
                carrier_bound = original_carrier_bound * fraction
                support_bound = original_support_bound * fraction

            true_carrier_bound_base = original_carrier_bound if adversarial and adversarial_kind == "malicious_underreport" else carrier_bound
            true_support_bound_base = original_support_bound if adversarial and adversarial_kind == "malicious_underreport" else support_bound

            witness_order = list(range(params.robots))
            assignment_rng.shuffle(witness_order)
            evidence_missing = evidence_rng.random() < params.evidence_missing_prob
            evidence_valid = not evidence_missing and evidence_rng.random() >= params.evidence_invalid_prob
            evidence_delay = evidence_rng.randint(0, max(0, params.evidence_delay_max))
            proposals[epoch].append(
                Proposal(
                    ident=ident,
                    epoch=epoch,
                    carrier=carrier,
                    support=support,
                    criticality=weighted_criticality(criticality_rng),
                    immediate_cost=immediate_cost,
                    carrier_bound=carrier_bound,
                    support_bound=support_bound,
                    true_carrier_bound=true_carrier_bound_base * true_factor,
                    true_support_bound=true_support_bound_base * true_support_factor,
                    deadline=deadline,
                    duration=duration,
                    settlement_ratio=cost_rng.uniform(params.settlement_ratio_min, params.settlement_ratio_max),
                    witness_order=tuple(witness_order),
                    adversarial=adversarial,
                    adversarial_kind=adversarial_kind,
                    ground_truth_attack=adversarial_kind if adversarial else "",
                    requested_self_degradation=requested_self_degradation,
                    uses_remote_rights=uses_remote_rights,
                    silent_cancel_requested=silent_cancel_requested,
                    evidence_delay=evidence_delay,
                    evidence_valid=evidence_valid,
                    evidence_missing=evidence_missing,
                )
            )
            ident += 1

        inflation_epoch_rng = epoch_rng(seed, "inflation", epoch)
        inflation_gate = inflation_epoch_rng.random()
        inflation_pick = inflation_epoch_rng.random()
        inflation_multiplier = inflation_epoch_rng.uniform(params.inflation_multiplier_min, params.inflation_multiplier_max)
        if inflation_gate < params.inflation_prob:
            inflations[epoch].append(InflationEvent(epoch=epoch, pick=inflation_pick, multiplier=inflation_multiplier))

        handoff_epoch_rng = epoch_rng(seed, "handoff", epoch)
        handoff_gate = handoff_epoch_rng.random()
        handoff_pick = handoff_epoch_rng.random()
        handoff_role_pick = handoff_epoch_rng.random()
        order = list(range(params.robots))
        handoff_epoch_rng.shuffle(order)
        replacement_blocked_gate = handoff_epoch_rng.random()
        crash_during_gate = handoff_epoch_rng.random()
        old_crash_gate = handoff_epoch_rng.random()
        partition_after_certificate_gate = handoff_epoch_rng.random()
        if handoff_gate < params.handoff_prob:
            handoffs[epoch].append(
                HandoffEvent(
                    epoch=epoch,
                    pick=handoff_pick,
                    role_pick=handoff_role_pick,
                    target_order=tuple(order),
                    replacement_blocked=replacement_blocked_gate < params.handoff_replacement_scarcity,
                    crash_during=crash_during_gate < params.handoff_crash_prob,
                    old_crash_before=old_crash_gate < params.handoff_old_crash_prob,
                    partition_after_certificate=partition_after_certificate_gate < params.handoff_partition_after_certificate_prob,
                )
            )

        replay_epoch_rng = epoch_rng(seed, "replay", epoch)
        replay_gate = replay_epoch_rng.random()
        replay_pick = replay_epoch_rng.random()
        replay_stale_offset = replay_epoch_rng.randint(1, 3)
        if replay_gate < params.version_replay_prob:
            replays[epoch].append(ReplayEvent(epoch=epoch, pick=replay_pick, stale_offset=replay_stale_offset))

        lifecycle_epoch_rng = epoch_rng(seed, "lifecycle_attack", epoch)
        lifecycle_gate = lifecycle_epoch_rng.random()
        lifecycle_pick = lifecycle_epoch_rng.random()
        lifecycle_kind = params.lifecycle_attack_kind
        if lifecycle_kind == "mixed":
            lifecycle_kind = lifecycle_epoch_rng.choice(["silent_cancellation", "unauthorized_degradation"])
        if lifecycle_gate < params.lifecycle_attack_prob:
            lifecycle_attacks[epoch].append(LifecycleAttackEvent(epoch=epoch, kind=lifecycle_kind, pick=lifecycle_pick))

        for robot in range(params.robots):
            if crash_rng.random() < params.crash_prob:
                crashes[epoch].append(robot)

    active_until = -1
    active_state: Optional[PartitionState] = None
    for epoch in range(params.epochs):
        partition_epoch_rng = epoch_rng(seed, "partition", epoch)
        partition_gate = partition_epoch_rng.random()
        robot_ids = list(range(params.robots))
        partition_epoch_rng.shuffle(robot_ids)
        cut = partition_epoch_rng.randint(1, params.robots - 1)
        duration = partition_epoch_rng.randint(params.partition_duration_min, params.partition_duration_max)
        if active_state is not None and epoch < active_until:
            partitions[epoch] = active_state
            continue
        active_state = None
        if partition_gate < params.partition_start_prob:
            g1 = frozenset(robot_ids[:cut])
            g2 = frozenset(robot_ids[cut:])
            active_until = epoch + duration
            active_state = PartitionState((g1, g2), active_until)
            partitions[epoch] = active_state

    return Trace(proposals, inflations, crashes, partitions, handoffs, replays, lifecycle_attacks)


def make_robots(params: Params) -> list[Robot]:
    level = SELF_STRANDED if params.self_recovery_guarantee <= 1e-9 else SELF_RETURN
    return [Robot(params.initial_energy, params.self_recovery_guarantee, self_level=level) for _ in range(params.robots)]


def same_partition_group(partition: Optional[PartitionState], participants: Iterable[int]) -> bool:
    if partition is None:
        return True
    ps = list(dict.fromkeys(participants))
    return any(all(p in group for p in ps) for group in partition.groups)


def all_team_connected(partition: Optional[PartitionState]) -> bool:
    return partition is None


def active_participants(participants: Iterable[int], robots: list[Robot]) -> bool:
    return all(0 <= r < len(robots) and robots[r].active for r in participants)


def handle_crash(policy: str, robot_id: int, robots: list[Robot], live: list[Commitment], result: PolicyResult) -> None:
    if not robots[robot_id].active:
        return
    robots[robot_id].active = False
    robots[robot_id].energy = 0.0
    for commitment in list(live):
        if commitment.status not in ACTIVE_STATUSES:
            continue
        if robot_id in commitment.participants:
            # A completed Retire may still have an old effective certificate,
            # but its consumed backing is no longer physical capacity to lose.
            lost_backing = (0.0 if commitment.physical_execution_completed else
                            max(0.0, commitment.reserved.get(robot_id, 0.0)))
            previously_recorded = commitment.lost_physical_backing.get(robot_id, 0.0)
            if lost_backing > previously_recorded + 1e-9:
                result.lost_physical_capacity += lost_backing - previously_recorded
                commitment.lost_physical_backing[robot_id] = lost_backing
            if policy in PROTECTED_POLICIES:
                transition_at_risk(commitment, robots, result, policy, "participant_crash")
            elif policy == "immediate_only":
                result.forgotten += 1
                result.silent_unbacking += 1
            else:
                result.silent_unbacking += 1


def requirement_underestimated(commitment: Commitment) -> bool:
    return any(true_amount > commitment.claimed_req.get(robot_id, 0.0) + 1e-9 for robot_id, true_amount in commitment.true_req.items())


def record_model_underestimate(commitment: Commitment, result: PolicyResult) -> None:
    if commitment.contract_violation_recorded:
        return
    if requirement_underestimated(commitment):
        commitment.contract_violation_recorded = True
        result.model_underestimate_events += 1
        result.contract_bound_violations += 1


def record_bound_detection(commitment: Commitment, result: PolicyResult, epoch: int) -> None:
    if not requirement_underestimated(commitment):
        return
    record_model_underestimate(commitment, result)
    if commitment.underestimate_detected:
        return
    commitment.underestimate_detected = True
    commitment.underestimate_detected_epoch = epoch
    latency = max(0, epoch - commitment.created_epoch)
    result.bound_detection_count += 1
    result.late_at_risk_discovery += 1
    result.bound_detection_latency_total += latency
    result.detection_latency_total += latency
    if commitment.proposal.adversarial and commitment.proposal.adversarial_kind == "underdeclared_bound":
        result.detection_count += 1


def settle_commitment(commitment: Commitment, policy: str, robots: list[Robot], result: PolicyResult, epoch: int) -> bool:
    if commitment.physical_execution_completed:
        return False
    record_bound_detection(commitment, result, epoch)
    if commitment.status == STATUS_AT_RISK and policy in PROTECTED_POLICIES:
        if not commitment.physical_live and commitment.discharge_evidence_validated:
            # The physical action completed, but the Retire certificate is
            # uncertain.  Keep the old rights conservatively locked for
            # recovery instead of manufacturing a physical rupture.
            return False
        transition_rupture(commitment, robots, result, policy, "settlement_attempted_while_at_risk")
        mark_missed(result, "failed")
        return False

    if not active_participants(commitment.participants, robots):
        if policy in PROTECTED_POLICIES:
            transition_rupture(commitment, robots, result, policy, "participant_unavailable_at_settlement")
        else:
            release_reservations(commitment, robots, result, policy, "unsafe_failure")
        if commitment.proposal.adversarial:
            result.adversarial_physical_violation += 1
        mark_missed(result, "failed")
        return False

    actual_need = {robot_id: amount * commitment.proposal.settlement_ratio for robot_id, amount in commitment.true_req.items()}
    if policy == "immediate_only":
        ok = all(robots[r].energy + 1e-9 >= amount for r, amount in actual_need.items())
    else:
        ok = all(commitment.reserved.get(r, 0.0) + 1e-9 >= amount for r, amount in actual_need.items())

    if ok:
        for robot_id, amount in actual_need.items():
            spend_energy(robots, robot_id, amount, result)
        commitment.physical_execution_completed = True
        commitment.physical_completion_epoch = epoch
        commitment.retire_consumed_amounts = dict(actual_need)
        result.physical_completed += 1
        discharged = transition_discharge(
            commitment,
            robots,
            result,
            policy,
            used_by_commitment=actual_need if policy != "immediate_only" else None,
            epoch=epoch,
        )
        if discharged:
            if not commitment.rescued_recorded:
                commitment.rescued_recorded = True
                result.rescued += 1
                if commitment.proposal.adversarial:
                    result.adversarial_success += 1
            return True
        return False

    if policy in PROTECTED_POLICIES:
        transition_rupture(commitment, robots, result, policy, "insufficient_reserved_backing_at_settlement")
    else:
        release_reservations(commitment, robots, result, policy, "unsafe_failure")
    if commitment.proposal.adversarial:
        result.adversarial_physical_violation += 1
        if commitment.proposal.adversarial_kind == "underdeclared_bound":
            result.underdeclared_physical_underbacking += 1
    if not ok:
        result.physical_underbacking_events += 1
    mark_missed(result, "failed")
    return False


def discharge_evidence_ready(commitment: Commitment, epoch: int) -> bool:
    return epoch >= commitment.proposal.evidence_epoch


def valid_discharge_evidence(commitment: Commitment) -> bool:
    return not commitment.proposal.evidence_missing and commitment.proposal.evidence_valid


def process_completion_and_deadlines(policy: str, epoch: int, live: list[Commitment], robots: list[Robot], result: PolicyResult) -> None:
    for commitment in list(live):
        if not commitment.protected_present or commitment.status not in ACTIVE_STATUSES:
            continue
        if commitment.physical_execution_completed:
            continue
        if epoch >= commitment.finish_epoch and not discharge_evidence_ready(commitment, epoch):
            if not commitment.discharge_pending_recorded:
                commitment.discharge_pending_recorded = True
                result.discharge_evidence_pending += 1
            continue
        if epoch >= commitment.finish_epoch and epoch <= commitment.due_epoch and discharge_evidence_ready(commitment, epoch):
            if not valid_discharge_evidence(commitment):
                if not commitment.evidence_failure_recorded:
                    commitment.evidence_failure_recorded = True
                    if commitment.proposal.evidence_missing:
                        result.discharge_evidence_missing += 1
                    else:
                        result.discharge_evidence_invalid += 1
                if policy in PROTECTED_POLICIES:
                    transition_at_risk(commitment, robots, result, policy, "invalid_or_missing_discharge_evidence")
                else:
                    live.remove(commitment)
                    release_reservations(commitment, robots, result, policy, "unsafe_failure")
                    mark_missed(result, "failed")
                continue
            settled = settle_commitment(commitment, policy, robots, result, epoch)
            if settled or policy not in PROTECTED_POLICIES:
                live.remove(commitment)

    for commitment in list(live):
        if not commitment.protected_present or commitment.status not in ACTIVE_STATUSES:
            continue
        if commitment.physical_execution_completed:
            continue
        if epoch >= commitment.due_epoch and (
            commitment.finish_epoch > commitment.due_epoch
            or not discharge_evidence_ready(commitment, epoch)
            or not valid_discharge_evidence(commitment)
        ):
            if policy in PROTECTED_POLICIES:
                transition_rupture(commitment, robots, result, policy, "deadline_expired_before_completion_or_evidence")
            else:
                live.remove(commitment)
                release_reservations(commitment, robots, result, policy, "deadline_failure")
            mark_missed(result, "deadline_missed")


def update_time_integrals(live: list[Commitment], robots: list[Robot], result: PolicyResult) -> None:
    result.pending_lock_duration += sum(
        1 for commitment in live
        if commitment.physical_execution_completed and commitment.retire_pending_since is not None
        and not commitment.retire_committed_recorded
    )
    active_commitments = sum(1 for c in live if c.protected_present and c.status in ACTIVE_STATUSES)
    result.active_commitments_area += active_commitments
    result.peak_active_commitments = max(result.peak_active_commitments, active_commitments)
    reserved_now = sum(robot.total_reserved for robot in robots)
    effective_reserved_now = sum(
        sum(commitment.reserved.values())
        for commitment in live
        if commitment.protected_present
    )
    pending_reserved_now = sum(
        sum(commitment.pending_reserved.values())
        for commitment in live
        if commitment.protected_present
    )
    result.reserved_energy_area += reserved_now
    result.reservation_energy_area += reserved_now
    result.effective_reservation_energy_area += effective_reserved_now
    result.pending_reservation_energy_area += pending_reserved_now
    result.peak_reserved_energy = max(result.peak_reserved_energy, reserved_now)
    result.peak_pending_reserved_energy = max(
        result.peak_pending_reserved_energy, pending_reserved_now
    )


def finalize_trace_commitments(
    policy: str,
    live: list[Commitment],
    robots: list[Robot],
    result: PolicyResult,
) -> None:
    for commitment in list(live):
        if commitment.status not in ACTIVE_STATUSES:
            continue
        if commitment.physical_execution_completed and not commitment.retire_committed_recorded:
            commitment.lifecycle_events.append(
                {"transition": "retire_observation_censored", "reason": "certificate_pending_at_end"}
            )
            result.retire_pending_at_end += 1
            result.observation_censored += 1
            continue
        commitment.lifecycle_events.append(
            {"transition": "observation_censored", "reason": "trace_end_unfinished"}
        )
        result.observation_censored += 1
        mark_missed(result, "unfinished")


def finalize_result(result: PolicyResult, params: Params) -> None:
    result.attack_attempts = result.adversarial_proposals + result.replay_attempts + result.lifecycle_attack_attempts
    result.total_energy_consumed = result.energy_consumed
    result.reservation_energy_area = result.reservation_energy_area or result.reserved_energy_area
    result.total_reserved_energy = result.reservation_energy_area
    result.wasted_reserved_energy = result.reserved_backing_released_unused
    result.eventual_physical_violations = result.adversarial_physical_violation
    result.orphaned_physical_liability = result.orphaned_liability
    result.late_detection = result.late_at_risk_discovery
    result.mean_detection_latency = 0.0
    result.underdeclared_failure_rate = (
        result.underdeclared_physical_underbacking / result.underdeclared_admitted
        if result.underdeclared_admitted
        else 0.0
    )
    result.certificate_updates = result.certificate_message_ops
    result.witness_copy_operations = result.witness_copies_created
    result.simulated_message_operations = result.certificate_message_ops
    result.runtime_seconds = result.simulation_runtime_s
    result.runtime_per_trace = result.simulation_runtime_s
    if result.certificate_survival_checks:
        result.witness_survival_rate = result.certificate_survivors / result.certificate_survival_checks
    if params.epochs:
        result.reserved_energy_mean = result.reservation_energy_area / params.epochs
        result.mean_reserved_energy = result.reserved_energy_mean
        result.mean_effective_reserved_energy = (
            result.effective_reservation_energy_area / params.epochs
        )
        result.mean_pending_reserved_energy = (
            result.pending_reservation_energy_area / params.epochs
        )
        result.mean_active_commitments = result.active_commitments_area / params.epochs
    if result.total_initial_energy > 0:
        result.mean_energy_utilization = result.energy_consumed / result.total_initial_energy
    reserve_denominator = result.reserved_backing_consumed + result.reserved_backing_released_unused
    if reserve_denominator > 0:
        result.reserve_efficiency = result.reserved_backing_consumed / reserve_denominator
        result.reserve_efficiency_defined = True
    else:
        result.reserve_efficiency = None
        result.reserve_efficiency_defined = False
    if result.terminal_commitments:
        result.mean_commitment_lifetime = result.total_commitment_lifetime / result.terminal_commitments
    if result.bound_detection_count:
        result.detection_latency_mean = result.detection_latency_total / result.bound_detection_count
        result.mean_detection_latency = result.bound_detection_latency_total / result.bound_detection_count
    if result.proposals:
        result.blocked_rate = result.blocked / result.proposals
        result.silent_unbacking_rate = result.silent_unbacking / result.proposals
        result.detection_rate = result.detection_count / result.attack_attempts if result.attack_attempts else 0.0
        result.attack_success_rate = result.attack_success / result.attack_attempts if result.attack_attempts else 0.0
        result.physical_underbacking_rate = result.physical_underbacking_events / result.proposals
    if params.robots:
        result.rescued_per_robot = result.rescued / params.robots
        result.admitted_per_robot = result.admitted / params.robots


def format_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    minutes, sec = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours:d}h{minutes:02d}m{sec:02d}s"
    if minutes:
        return f"{minutes:d}m{sec:02d}s"
    return f"{sec:d}s"


class ProgressBar:
    def __init__(self, label: str, total: int, enabled: bool = True, min_interval: float = 0.25, width: int = 30) -> None:
        self.label = label
        self.total = max(0, int(total))
        self.enabled = enabled and self.total > 0
        self.min_interval = min_interval
        self.width = width
        self.current = 0
        self.started = time.perf_counter()
        self.last_render = 0.0
        self.rendered = False
        if self.enabled:
            self.render(force=True)

    def update(self, step: int = 1) -> None:
        if not self.enabled:
            return
        self.current = min(self.total, self.current + step)
        now = time.perf_counter()
        if self.current >= self.total or now - self.last_render >= self.min_interval:
            self.render(now=now, force=True)

    def render(self, now: Optional[float] = None, force: bool = False) -> None:
        if not self.enabled:
            return
        now = time.perf_counter() if now is None else now
        if not force and now - self.last_render < self.min_interval:
            return
        self.last_render = now
        elapsed = now - self.started
        ratio = self.current / self.total if self.total else 1.0
        filled = min(self.width, int(round(self.width * ratio)))
        bar = "#" * filled + "-" * (self.width - filled)
        rate = self.current / elapsed if elapsed > 0 else 0.0
        eta = (self.total - self.current) / rate if rate > 0 else 0.0
        message = (
            f"\r{self.label} [{bar}] "
            f"{self.current}/{self.total} {ratio * 100:6.2f}% "
            f"elapsed {format_duration(elapsed)} eta {format_duration(eta)}"
        )
        sys.stderr.write(message)
        sys.stderr.flush()
        self.rendered = True

    def close(self) -> None:
        if not self.enabled:
            return
        if self.current < self.total:
            self.render(force=True)
        if self.rendered:
            sys.stderr.write("\n")
            sys.stderr.flush()


def audit_simulated_physical_liabilities(
    oracle: PhysicalLiabilityOracle,
    known: dict[int, Commitment],
    oracle_state: dict[int, tuple[str, int]],
    robots: list[Robot],
    result: PolicyResult,
    epoch: int,
) -> None:
    """Feed committed physical facts to the evaluation-only Oracle.

    This observer is outside admission/release decisions. It tracks each
    physical residual after the policy has acted and never grants authority.
    """
    for commitment in known.values():
        residual_id = commitment.assist_for if commitment.assist_for is not None else commitment.ident
        if residual_id not in oracle.residuals and commitment.assist_for is None and not commitment.physical_execution_completed:
            required = commitment.true_req.get(commitment.carrier, 0.0)
            oracle.observe(PhysicalEvent(
                commitment.created_epoch, residual_id, "physical_commit", commitment.carrier,
                required_backing=required,
                physical_object=f"residual:{residual_id}",
                contract_id=commitment.phase_contract_id,
                responsibility_scope="full",
                resource_requirements=tuple(commitment.true_req.items()),
            ))
            oracle_state[residual_id] = (commitment.physical_stage, commitment.carrier)
        if commitment.physical_execution_completed and commitment.discharge_evidence_validated:
            if residual_id in oracle.residuals:
                oracle.observe(PhysicalEvent(epoch, residual_id, "physical_discharge", commitment.carrier))
            continue
        if residual_id not in oracle.residuals or not commitment.physical_live:
            continue
        previous_stage, previous_owner = oracle_state.get(
            residual_id, (oracle.residuals[residual_id], oracle.physical_owners[residual_id])
        )
        if commitment.physical_stage != previous_stage:
            kind = "safe_wait" if commitment.physical_stage == "transport" else "physical_takeover"
            oracle.observe(PhysicalEvent(
                epoch, residual_id, kind, commitment.carrier,
                required_backing=commitment.true_req.get(commitment.carrier, 0.0),
                contract_id=commitment.phase_contract_id,
            ))
        elif commitment.carrier != previous_owner:
            oracle.observe(PhysicalEvent(
                epoch, residual_id, "responsibility_handoff", commitment.carrier,
                required_backing=commitment.true_req.get(commitment.carrier, 0.0),
                contract_id=commitment.phase_contract_id,
            ))
        oracle_state[residual_id] = (commitment.physical_stage, commitment.carrier)
        # Observed physical demand includes support roles and later inflation;
        # it is never inferred from current reservation or the certificate bound.
        oracle.resource_requirements[residual_id] = dict(commitment.true_req)

    claims: dict[int, set[int]] = {residual_id: set() for residual_id in oracle.residuals}
    for commitment in known.values():
        residual_id = commitment.assist_for if commitment.assist_for is not None else commitment.ident
        if residual_id in claims:
            claims[residual_id].add(commitment.ident)
    oracle.audit(known.values(), robots, claims, [])
    cumulative = oracle.cumulative_report()
    result.semantic_liability_coverage_violations = max(
        result.semantic_liability_coverage_violations,
        cumulative["semantic_liability_coverage_violations"],
    )
    result.physical_underbacking_events = max(
        result.physical_underbacking_events,
        cumulative["physical_underbacking_events"],
    )
    result.forgotten_liability = max(result.forgotten_liability, cumulative["forgotten_liability"])
    result.durable_record_survival_violations = max(
        result.durable_record_survival_violations,
        cumulative["durable_record_survival_violations"],
    )
    result.record_loss_beyond_fault_model = max(
        result.record_loss_beyond_fault_model,
        cumulative["record_loss_beyond_fault_model"],
    )


def simulate_policy(policy: str, trace: Trace, params: Params) -> PolicyResult:
    start_time = time.perf_counter()
    robots = make_robots(params)
    live: list[Commitment] = []
    known_commitments: dict[int, Commitment] = {}
    liability_oracle = PhysicalLiabilityOracle()
    oracle_state: dict[int, tuple[str, int]] = {}
    result = PolicyResult(policy=policy)
    result.total_initial_energy = params.robots * params.initial_energy

    for epoch in range(params.epochs):
        partition = trace.partitions_by_epoch.get(epoch)
        for commitment in live:
            commitment.network_partition = partition
            commitment.simulation_epoch = epoch

        for robot_id in trace.crashes_by_epoch.get(epoch, []):
            handle_crash(policy, robot_id, robots, live, result)

        for event in trace.inflations_by_epoch.get(epoch, []):
            commitment = choose_live_by_pick(live, event.pick, include_at_risk=False)
            if commitment is not None:
                apply_inflation(policy, commitment, live, robots, partition, result, event.multiplier, params)

        for event in trace.handoffs_by_epoch.get(epoch, []):
            commitment = choose_live_by_pick(live, event.pick, include_at_risk=True)
            if commitment is not None:
                attempt_handoff(policy, commitment, event, partition, robots, result, params, live)

        for event in trace.replays_by_epoch.get(epoch, []):
            commitment = choose_live_by_pick(live, event.pick, include_at_risk=True)
            if commitment is not None:
                apply_replay(policy, commitment, robots, result, event.stale_offset)

        if policy in {"central_commit_aware", "commit_guard"}:
            for commitment in list(live):
                try_recover_at_risk(policy, commitment, partition, robots, result, params, live, epoch)

        for event in trace.lifecycle_attacks_by_epoch.get(epoch, []):
            apply_lifecycle_attack(policy, event, live, robots, result)

        for prop in trace.proposals_by_epoch.get(epoch, []):
            admit(policy, prop, partition, robots, live, result, params)
            for commitment in live:
                known_commitments.setdefault(commitment.ident, commitment)

        process_completion_and_deadlines(policy, epoch, live, robots, result)
        audit_simulated_physical_liabilities(
            liability_oracle, known_commitments, oracle_state, robots, result, epoch
        )
        check_invariants(policy, robots, live, result, f"epoch_{epoch}")
        update_time_integrals(live, robots, result)

    finalize_trace_commitments(policy, live, robots, result)
    audit_simulated_physical_liabilities(
        liability_oracle, known_commitments, oracle_state, robots, result, params.epochs
    )

    result.stranded_robots = sum(1 for r in robots if r.self_level == SELF_STRANDED)
    result.unused_reserved_energy = sum(sum(c.reserved.values()) for c in live)
    result.effective_reserved_energy_at_end = result.unused_reserved_energy
    result.pending_reserved_energy_at_end = sum(
        sum(commitment.pending_reserved.values()) for commitment in live
    )
    result.pending_consumed_backing_at_end = sum(
        sum(commitment.pending_consumed_backing.values()) for commitment in live
    )
    result.physical_locked_energy_at_end = sum(robot.total_reserved for robot in robots)
    result.retained_unavailable_resources += sum(
        sum(robot.reserved.values()) + sum(robot.remote_reserved.values())
        for robot in robots if not robot.active
    )
    result.pending_commitments_at_end = sum(
        1
        for commitment in live
        if commitment.pending_reserved
        or commitment.pending_consumed_backing
        or commitment.pending_operation
    )
    result.pending_uncertain_commitments_at_end = sum(
        1
        for commitment in live
        if commitment.certificate_update_uncertain
        and (
            commitment.pending_reserved
            or commitment.pending_consumed_backing
            or commitment.pending_operation
        )
    )
    result.simulation_runtime_s = time.perf_counter() - start_time
    finalize_result(result, params)
    return result


