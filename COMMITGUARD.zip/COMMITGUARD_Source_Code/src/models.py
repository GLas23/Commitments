"""Discrete-event simulator for COMMITGUARD paper experiments.

The simulator implements five policies, common-random-number workload traces,
commitment lifecycle transitions, resource accounting, safety checks, and
CSV/JSON output for the experiments in Sections 6.1--6.7.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Iterable, Optional

STATUS_LIVE = "live"
STATUS_DEGRADED = "degraded"
STATUS_AT_RISK = "at_risk"
STATUS_DISCHARGED = "discharged"
STATUS_RUPTURED = "ruptured"
STATUS_FORGOTTEN = "forgotten"
ACTIVE_STATUSES = {STATUS_LIVE, STATUS_DEGRADED, STATUS_AT_RISK}

SELF_RETURN = "return"
SELF_SAFE_HALT = "safe_halt"
SELF_STRANDED = "stranded_nonblocking"
SELF_LEVELS = (SELF_RETURN, SELF_SAFE_HALT, SELF_STRANDED)
SELF_FRACTION = {SELF_RETURN: 1.0, SELF_SAFE_HALT: 0.5, SELF_STRANDED: 0.0}
ALLOWED_SELF_DEGRADATION = {SELF_RETURN: SELF_SAFE_HALT, SELF_SAFE_HALT: SELF_STRANDED}

PROTECTED_POLICIES = {"static_worst_case", "central_commit_aware", "commit_guard"}
CERTIFICATE_POLICIES = {"central_commit_aware", "commit_guard"}
STRICT_POLICIES = {"commit_guard"}
LEGAL_RELEASE_REASONS = {"discharge", "terminal_policy_disposition", "handoff_replaced"}

POLICIES = [
    "immediate_only",
    "static_worst_case",
    "priority_cancel",
    "central_commit_aware",
    "commit_guard",
]

POLICY_LABELS = {
    "immediate_only": "Immediate-only",
    "static_worst_case": "Static worst-case reserve",
    "priority_cancel": "Priority-cancel",
    "central_commit_aware": "Central commit-aware",
    "commit_guard": "COMMIT GUARD",
}

CRITICALITY = {0: "low", 1: "medium", 2: "high"}
PROGRESS_ENABLED = True


@dataclass(frozen=True)
class PolicyCapabilities:
    has_commitment_ledger: bool
    has_exact_reservation: bool
    uses_static_worst_case: bool
    has_monotonic_version: bool
    has_certificate_auth: bool
    has_authenticated_certificate: bool
    has_witness_replication: bool
    has_local_resource_ownership: bool
    has_policy_degradation: bool
    has_at_risk_state: bool
    has_replacement_before_release: bool
    rejects_visible_planner_errors: bool
    has_certified_minimum_backing: bool
    requires_global_view: bool


POLICY_CAPABILITIES: dict[str, PolicyCapabilities] = {
    "immediate_only": PolicyCapabilities(
        has_commitment_ledger=False,
        has_exact_reservation=False,
        uses_static_worst_case=False,
        has_monotonic_version=False,
        has_certificate_auth=False,
        has_authenticated_certificate=False,
        has_witness_replication=False,
        has_local_resource_ownership=False,
        has_policy_degradation=False,
        has_at_risk_state=False,
        has_replacement_before_release=False,
        rejects_visible_planner_errors=False,
        has_certified_minimum_backing=False,
        requires_global_view=False,
    ),
    "static_worst_case": PolicyCapabilities(
        has_commitment_ledger=True,
        has_exact_reservation=False,
        uses_static_worst_case=True,
        has_monotonic_version=False,
        has_certificate_auth=False,
        has_authenticated_certificate=False,
        has_witness_replication=False,
        has_local_resource_ownership=False,
        has_policy_degradation=False,
        has_at_risk_state=True,
        has_replacement_before_release=False,
        rejects_visible_planner_errors=True,
        has_certified_minimum_backing=False,
        requires_global_view=False,
    ),
    "priority_cancel": PolicyCapabilities(
        has_commitment_ledger=True,
        has_exact_reservation=True,
        uses_static_worst_case=False,
        has_monotonic_version=False,
        has_certificate_auth=False,
        has_authenticated_certificate=False,
        has_witness_replication=False,
        has_local_resource_ownership=False,
        has_policy_degradation=False,
        has_at_risk_state=False,
        has_replacement_before_release=False,
        rejects_visible_planner_errors=True,
        has_certified_minimum_backing=False,
        requires_global_view=False,
    ),
    "central_commit_aware": PolicyCapabilities(
        has_commitment_ledger=True,
        has_exact_reservation=True,
        uses_static_worst_case=False,
        has_monotonic_version=True,
        has_certificate_auth=True,
        has_authenticated_certificate=True,
        has_witness_replication=False,
        has_local_resource_ownership=False,
        has_policy_degradation=True,
        has_at_risk_state=True,
        has_replacement_before_release=True,
        rejects_visible_planner_errors=True,
        has_certified_minimum_backing=False,
        requires_global_view=True,
    ),
    "commit_guard": PolicyCapabilities(
        has_commitment_ledger=True,
        has_exact_reservation=True,
        uses_static_worst_case=False,
        has_monotonic_version=True,
        has_certificate_auth=True,
        has_authenticated_certificate=True,
        has_witness_replication=True,
        has_local_resource_ownership=True,
        has_policy_degradation=True,
        has_at_risk_state=True,
        has_replacement_before_release=True,
        rejects_visible_planner_errors=True,
        has_certified_minimum_backing=True,
        requires_global_view=False,
    ),
}

def caps(policy: str) -> PolicyCapabilities:
    return POLICY_CAPABILITIES[policy]


@dataclass(frozen=True)
class Params:
    robots: int = 10
    initial_energy: float = 100.0
    epochs: int = 80
    proposal_prob: float = 0.55
    immediate_cost_min: float = 3.0
    immediate_cost_max: float = 7.0
    carrier_bound_min: float = 10.0
    carrier_bound_max: float = 18.0
    support_required_prob: float = 0.45
    support_bound_min: float = 3.0
    support_bound_max: float = 7.0
    min_carrier_low: float = 8.0
    min_carrier_medium: float = 9.0
    min_carrier_high: float = 10.0
    min_support_low: float = 1.0
    min_support_medium: float = 2.0
    min_support_high: float = 3.0
    self_recovery_guarantee: float = 12.0
    partition_start_prob: float = 0.08
    partition_duration_min: int = 2
    partition_duration_max: int = 8
    inflation_prob: float = 0.10
    inflation_multiplier_min: float = 1.10
    inflation_multiplier_max: float = 1.35
    crash_prob: float = 0.002
    settlement_ratio_min: float = 0.90
    settlement_ratio_max: float = 1.00
    static_worst_case_multiplier: float = 1.60
    medium_high_degrade_self_recovery: bool = True
    completion_duration_min: int = 2
    completion_duration_max: int = 12
    deadline_tightness: float = 1.0
    proposal_mode: str = "bernoulli"
    proposal_load_per_robot: float = 0.055
    handoff_prob: float = 0.0
    handoff_replacement_scarcity: float = 0.0
    handoff_crash_prob: float = 0.0
    handoff_old_crash_prob: float = 0.0
    handoff_partition_after_certificate_prob: float = 0.0
    version_replay_prob: float = 0.0
    lifecycle_attack_prob: float = 0.0
    lifecycle_attack_kind: str = "mixed"
    adversarial_proposal_prob: float = 0.0
    attack_mode: str = "mixed"
    adversarial_cost_multiplier: float = 4.0
    bound_error: float = 0.0
    underreport_fraction: float = 0.5
    evidence_delay_max: int = 0
    evidence_missing_prob: float = 0.0
    evidence_invalid_prob: float = 0.0
    witness_count: int = 2
    contract_degradation_enabled: bool = False
    contract_degraded_carrier_requirement: float = 8.0
    contract_degraded_support_requirement: float = 2.0
    contract_degradation_config_source: str = "disabled"
    # Diagnostic switches do not participate in trace generation.
    retire_recovery_enabled: bool = True
    mint_deferred_execution: bool = True
    witness_selection_mode: str = "reachable"
    diagnostic_legacy_threshold: bool = False
    certificate_ack_delay_epochs: int = 0
    retire_recovery_wait_epochs: int = 0


@dataclass(frozen=True)
class Proposal:
    ident: int
    epoch: int
    carrier: int
    support: Optional[int]
    criticality: int
    immediate_cost: float
    carrier_bound: float
    support_bound: float
    true_carrier_bound: float
    true_support_bound: float
    deadline: int
    duration: int
    settlement_ratio: float
    witness_order: tuple[int, ...]
    adversarial: bool = False
    adversarial_kind: str = ""
    ground_truth_attack: str = ""
    requested_self_degradation: str = ""
    uses_remote_rights: bool = False
    silent_cancel_requested: bool = False
    evidence_delay: int = 0
    evidence_valid: bool = True
    evidence_missing: bool = False
    # An explicitly modeled irreversible cost before the physical commit point.
    precommit_preparation_cost: float = 0.0
    physical_execution_success: bool = True

    @property
    def due_epoch(self) -> int:
        return self.epoch + self.deadline

    @property
    def finish_epoch(self) -> int:
        return self.epoch + self.duration

    @property
    def evidence_epoch(self) -> int:
        return self.finish_epoch + self.evidence_delay

    @property
    def participants(self) -> tuple[int, ...]:
        return (self.carrier,) if self.support is None else (self.carrier, self.support)


@dataclass(frozen=True)
class InflationEvent:
    epoch: int
    pick: float
    multiplier: float


@dataclass(frozen=True)
class HandoffEvent:
    epoch: int
    pick: float
    role_pick: float
    target_order: tuple[int, ...]
    replacement_blocked: bool = False
    crash_during: bool = False
    old_crash_before: bool = False
    partition_after_certificate: bool = False
    old_crash_after_certificate: bool = False


@dataclass(frozen=True)
class HandoffEvidence:
    """Trusted simulation input; distinct from final Retire evidence."""
    residual_id: int
    contract_id: str
    kind: str  # safe_wait or physical_takeover
    epoch: int
    trusted: bool
    valid: bool
    physically_observed: bool


@dataclass(frozen=True)
class TwoStageContract:
    contract_id: str
    original_requirement: float
    successor_requirement: float
    safe_wait_authorized: bool = True
    physical_takeover_authorized: bool = True
    witness_recovery_authorized: bool = False


@dataclass(frozen=True)
class PhysicalEvent:
    epoch: int
    residual_id: int
    kind: str
    robot: int
    trusted: bool = True
    required_backing: float = 0.0
    physical_object: str = ""
    contract_id: str = ""
    responsibility_scope: str = ""
    responsibility_units: float = 1.0
    resource_requirements: tuple[tuple[int, float], ...] = ()


@dataclass
class PhysicalLiabilityOracle:
    """Experimental truth derived only from exogenous physical events.

    The mechanism never reads this object when admitting or releasing work.
    Software cancellation and certificate deletion are intentionally ignored.
    """
    events: list[PhysicalEvent] = field(default_factory=list)
    residuals: dict[int, str] = field(default_factory=dict)
    physical_owners: dict[int, int] = field(default_factory=dict)
    required_backing: dict[int, float] = field(default_factory=dict)
    physical_objects: dict[int, str] = field(default_factory=dict)
    contract_ids: dict[int, str] = field(default_factory=dict)
    responsibility_scopes: dict[int, str] = field(default_factory=dict)
    responsibility_units: dict[int, float] = field(default_factory=dict)
    resource_requirements: dict[int, dict[int, float]] = field(default_factory=dict)
    registered_records: dict[int, list[dict[str, object]]] = field(default_factory=dict)
    required_record_ids: dict[int, set[int]] = field(default_factory=dict)
    semantic_violation_history: set[int] = field(default_factory=set)
    physical_underbacking_history: set[int] = field(default_factory=set)
    forgotten_history: set[int] = field(default_factory=set)
    durable_violation_history: set[int] = field(default_factory=set)
    beyond_fault_model_history: set[int] = field(default_factory=set)

    def observe(self, event: PhysicalEvent) -> None:
        self.events.append(event)
        if not event.trusted:
            return
        if event.kind == "physical_commit":
            self.residuals[event.residual_id] = "placement"
            self.physical_owners[event.residual_id] = event.robot
            self.required_backing[event.residual_id] = event.required_backing
            self.physical_objects[event.residual_id] = event.physical_object or f"residual:{event.residual_id}"
            self.contract_ids[event.residual_id] = event.contract_id
            self.responsibility_scopes[event.residual_id] = event.responsibility_scope or "full"
            self.responsibility_units[event.residual_id] = event.responsibility_units
            self.resource_requirements[event.residual_id] = dict(event.resource_requirements)
        elif event.kind == "safe_wait" and self.residuals.get(event.residual_id) == "placement":
            self.residuals[event.residual_id] = "transport"
            self.physical_owners[event.residual_id] = event.robot
            if event.required_backing > 0:
                self.required_backing[event.residual_id] = event.required_backing
        elif event.kind == "physical_takeover" and event.residual_id in self.residuals:
            self.residuals[event.residual_id] = "takeover"
            self.physical_owners[event.residual_id] = event.robot
            if event.required_backing > 0:
                self.required_backing[event.residual_id] = event.required_backing
        elif event.kind == "responsibility_handoff" and event.residual_id in self.residuals:
            self.physical_owners[event.residual_id] = event.robot
            if event.required_backing > 0:
                self.required_backing[event.residual_id] = event.required_backing
        elif event.kind == "physical_discharge":
            self.residuals.pop(event.residual_id, None)
            self.physical_owners.pop(event.residual_id, None)
            self.required_backing.pop(event.residual_id, None)
            self.physical_objects.pop(event.residual_id, None)
            self.contract_ids.pop(event.residual_id, None)
            self.responsibility_scopes.pop(event.residual_id, None)
            self.responsibility_units.pop(event.residual_id, None)
            self.resource_requirements.pop(event.residual_id, None)

    def register_commitment(self, residual_id: int, commitment: Commitment) -> None:
        """Remember the declared durability envelope before a later state loss."""
        effective = commitment.effective_version
        if effective <= 0:
            return
        record = {
            "commitment_id": commitment.ident,
            "version": effective,
            "persisted": set(commitment.certificate_persisted_versions.get(effective, set())),
            "fault_tolerance": commitment.certificate_fault_tolerance,
            "threshold": commitment.certificate_persistence_threshold,
        }
        records = self.registered_records.setdefault(residual_id, [])
        # A certified successor replaces its predecessor's durability envelope.
        # Testing every obsolete quorum would incorrectly charge a later >f loss
        # against an earlier version whose holders legitimately moved on.
        previous = next((r for r in records if r["commitment_id"] == commitment.ident), None)
        if previous is None:
            records.append(record)
        elif int(previous["version"]) < effective and self._effective_record_valid(commitment):
            records[records.index(previous)] = record

    @staticmethod
    def _effective_record_valid(commitment: Commitment) -> bool:
        semantic_record_states = ACTIVE_STATUSES | {STATUS_RUPTURED}
        if not commitment.protected_present or not commitment.physical_live or commitment.status not in semantic_record_states:
            return False
        effective = commitment.effective_version
        if effective <= 0:
            return True
        snapshot = commitment.certificate_history.get(effective)
        metadata = commitment.certificate_metadata.get(effective)
        if snapshot is None or metadata is None:
            return False
        if commitment.version_state_hashes.get(effective) != snapshot_hash(snapshot):
            return False
        predecessor = int(metadata.get("predecessor", -1))
        if commitment.certificate_successors.get(predecessor) != effective:
            return False
        if str(snapshot.get("status", "")) not in semantic_record_states or not bool(snapshot.get("physical_live", False)):
            return False
        inheritance = metadata.get("responsibility_inheritance", {})
        if not isinstance(inheritance, dict):
            return False
        for key in ("carrier", "support", "guarantee", "phase_contract_id", "physical_stage", "assist_for",
                    "physical_object", "responsibility_scope", "responsibility_units"):
            if inheritance.get(key) != snapshot.get(key):
                return False
            if snapshot.get(key) != getattr(commitment, key):
                return False
        return True

    def _semantic_covers(self, residual_id: int, commitment: Commitment) -> bool:
        if not self._effective_record_valid(commitment):
            return False
        if commitment.ident != residual_id and commitment.assist_for != residual_id:
            return False
        if commitment.physical_object != self.physical_objects[residual_id]:
            return False
        if commitment.responsibility_scope != self.responsibility_scopes[residual_id]:
            return False
        if commitment.responsibility_units + 1e-9 < self.responsibility_units[residual_id]:
            return False
        expected_contract = self.contract_ids.get(residual_id, "")
        if expected_contract and commitment.phase_contract_id != expected_contract:
            return False
        stage = self.residuals[residual_id]
        allowed_stages = {
            "placement": {"placement"},
            "transport": {"transport"},
            "takeover": {"takeover"},
        }[stage]
        # The original full obligation continues to name the residual while
        # Transform is unconfirmed. Physical progress is not software discharge.
        # A replacement record, however, must carry the observed stage and a
        # certified/evidenced inheritance; naming assist_for alone is insufficient.
        original_retained = commitment.ident == residual_id and commitment.physical_stage == "placement"
        if not original_retained:
            if commitment.physical_stage not in allowed_stages:
                return False
            if commitment.assist_for is not None and not commitment.phase_evidence_hash:
                return False
        # Energy demand is intentionally absent: it is physical backing, not
        # a measure of the semantic amount of responsibility being inherited.
        return True

    @staticmethod
    def _durable_record_survives(commitment: Commitment, robots: list[Robot]) -> bool:
        if not commitment.protected_present:
            return False
        effective = commitment.effective_version
        if effective <= 0:
            return commitment.protected_present and any(
                0 <= holder < len(robots) and robots[holder].active
                for holder in commitment.participants
            )
        if effective not in commitment.certificate_history or effective not in commitment.certificate_metadata:
            return False
        if not PhysicalLiabilityOracle._effective_record_valid(commitment):
            return False
        persisted = commitment.certificate_persisted_versions.get(effective, set())
        return any(
            0 <= holder < len(robots) and robots[holder].active
            and commitment.certificate_versions.get(holder) == effective
            for holder in persisted
        )

    def _physically_backed(self, residual_id: int, commitment: Commitment, robots: list[Robot]) -> bool:
        needs = self.resource_requirements.get(residual_id) or {
            self.physical_owners[residual_id]: self.required_backing.get(residual_id, 0.0)
        }
        for owner, required in needs.items():
            if not (0 <= owner < len(robots) and robots[owner].active):
                return False
            if robots[owner].energy + 1e-9 < required:
                return False
            if commitment.reserved or commitment.effective_version > 0:
                if (commitment.reserved.get(owner, 0.0) + 1e-9 < required
                        or robots[owner].reserved.get(commitment.ident, 0.0) + 1e-9 < required):
                    return False
        return True

    def audit(
        self, commitments: Iterable[Commitment], robots: list[Robot],
        coverage_claims: dict[int, set[int]], releases: Iterable[tuple[int, bool]],
    ) -> dict[str, int]:
        commitment_list = list(commitments)
        by_id = {c.ident: c for c in commitment_list}
        semantic_uncovered = physical_underbacking = forgotten = 0
        durable_violations = beyond_fault_model = 0
        for residual_id in self.residuals:
            candidate_ids = coverage_claims.get(residual_id, set())
            records = [by_id[cid] for cid in candidate_ids if cid in by_id]
            semantic_records = [c for c in records if self._semantic_covers(residual_id, c)]
            if semantic_records:
                self.required_record_ids[residual_id] = {c.ident for c in semantic_records}
            durable_records = [c for c in semantic_records if self._durable_record_survives(c, robots)]
            if not durable_records:
                forgotten += 1
                self.forgotten_history.add(residual_id)
            if not semantic_records:
                semantic_uncovered += 1
                self.semantic_violation_history.add(residual_id)
            if not any(self._physically_backed(residual_id, c, robots) for c in records):
                physical_underbacking += 1
                self.physical_underbacking_history.add(residual_id)
            if not durable_records:
                guarantees = self.registered_records.get(residual_id, [])
                necessary = self.required_record_ids.get(residual_id)
                if necessary is not None:
                    guarantees = [g for g in guarantees if g["commitment_id"] in necessary]
                in_model_loss = False
                beyond_model_loss = False
                for guarantee in guarantees:
                    persisted = set(guarantee["persisted"])
                    threshold = int(guarantee["threshold"])
                    fault_tolerance = int(guarantee["fault_tolerance"])
                    if len(persisted) < threshold:
                        continue
                    crashes = sum(1 for h in persisted if not (0 <= h < len(robots) and robots[h].active))
                    if crashes <= fault_tolerance:
                        in_model_loss = True
                    else:
                        beyond_model_loss = True
                durable_violations += int(in_model_loss)
                beyond_fault_model += int(not in_model_loss and beyond_model_loss)
                if in_model_loss:
                    self.durable_violation_history.add(residual_id)
                elif beyond_model_loss:
                    self.beyond_fault_model_history.add(residual_id)
            for commitment in records:
                self.register_commitment(residual_id, commitment)
        return {
            "semantic_liability_coverage_violations": semantic_uncovered,
            "liability_coverage_violations": semantic_uncovered,
            "physical_underbacking_events": physical_underbacking,
            "forgotten_liability": forgotten,
            "durable_record_survival_violations": durable_violations,
            "record_loss_beyond_fault_model": beyond_fault_model,
            "illegal_release_events": sum(1 for residual_id, authorized in releases
                                          if residual_id in self.residuals and not authorized),
        }

    def cumulative_report(self) -> dict[str, int]:
        return {
            "semantic_liability_coverage_violations": len(self.semantic_violation_history),
            "physical_underbacking_events": len(self.physical_underbacking_history),
            "forgotten_liability": len(self.forgotten_history),
            "durable_record_survival_violations": len(self.durable_violation_history),
            "record_loss_beyond_fault_model": len(self.beyond_fault_model_history),
        }


@dataclass(frozen=True)
class ReplayEvent:
    epoch: int
    pick: float
    stale_offset: int


@dataclass(frozen=True)
class LifecycleAttackEvent:
    epoch: int
    kind: str
    pick: float


@dataclass(frozen=True)
class PartitionState:
    groups: tuple[frozenset[int], frozenset[int]]
    until_epoch: int


@dataclass(frozen=True)
class Trace:
    proposals_by_epoch: dict[int, list[Proposal]]
    inflations_by_epoch: dict[int, list[InflationEvent]]
    crashes_by_epoch: dict[int, list[int]]
    partitions_by_epoch: dict[int, PartitionState]
    handoffs_by_epoch: dict[int, list[HandoffEvent]]
    replays_by_epoch: dict[int, list[ReplayEvent]]
    lifecycle_attacks_by_epoch: dict[int, list[LifecycleAttackEvent]]


@dataclass
class Robot:
    energy: float
    self_base: float
    self_level: str = SELF_RETURN
    active: bool = True
    reserved: dict[int, float] = field(default_factory=dict)
    remote_reserved: dict[int, float] = field(default_factory=dict)
    pending_execution_cost: dict[int, float] = field(default_factory=dict)

    @property
    def total_reserved(self) -> float:
        return sum(self.reserved.values()) + sum(self.remote_reserved.values()) + sum(self.pending_execution_cost.values())

    @property
    def self_reserve(self) -> float:
        return self.self_base * SELF_FRACTION[self.self_level]

    @property
    def free(self) -> float:
        if not self.active:
            return 0.0
        return self.energy - self.self_reserve - self.total_reserved


@dataclass
class Commitment:
    ident: int
    proposal: Proposal
    initiator: int
    carrier: int
    support: Optional[int]
    criticality: int
    created_epoch: int
    due_epoch: int
    finish_epoch: int
    claimed_req: dict[int, float]
    true_req: dict[int, float]
    certified_min_req: dict[int, float]
    initial_claimed_req: dict[int, float]
    reserved: dict[int, float]
    # ``reserved`` is the effective logical allocation declared by the latest
    # committed certificate.  Pending locks are physically unavailable but do
    # not become effective rights until their candidate certificate commits.
    effective_reserved: dict[int, float] = field(default_factory=dict)
    pending_reserved: dict[int, float] = field(default_factory=dict)
    pending_consumed_backing: dict[int, float] = field(default_factory=dict)
    pending_operation: str = ""
    pending_version: Optional[int] = None
    last_certificate_result: str = ""
    status: str = STATUS_LIVE
    guarantee: str = "full"
    version: int = 1
    effective_version: int = 0
    witnesses: set[int] = field(default_factory=set)
    certificate_versions: dict[int, int] = field(default_factory=dict)
    certificate_history: dict[int, dict[str, object]] = field(default_factory=dict)
    version_state_hashes: dict[int, str] = field(default_factory=dict)
    certificate_candidates: dict[int, dict[str, object]] = field(default_factory=dict)
    certificate_candidate_hashes: dict[int, str] = field(default_factory=dict)
    certificate_acknowledgements: dict[int, set[int]] = field(default_factory=dict)
    certificate_persisted_versions: dict[int, set[int]] = field(default_factory=dict)
    certificate_message_drops: set[int] = field(default_factory=set)
    network_partition: Optional[PartitionState] = None
    handoff_requires_old_guard: bool = False
    phase_contract_id: str = ""
    physical_stage: str = "placement"
    phase_evidence_hash: str = ""
    assist_for: Optional[int] = None
    certificate_metadata: dict[int, dict[str, object]] = field(default_factory=dict)
    certificate_successors: dict[int, int] = field(default_factory=dict)
    certificate_fault_tolerance: int = 0
    certificate_persistence_threshold: int = 1
    certificate_update_uncertain: bool = False
    contract_guarantee_requirements: dict[str, dict[int, float]] = field(default_factory=dict)
    authorized_degradation_edges: set[tuple[str, str]] = field(default_factory=set)
    lifecycle_events: list[dict[str, object]] = field(default_factory=list)
    release_events: list[dict[str, object]] = field(default_factory=list)
    discharge_evidence_validated: bool = False
    terminal_disposition_authorized: bool = False
    rupture_residual_recorded: bool = False
    rupture_backing_snapshot: dict[int, float] = field(default_factory=dict)
    at_risk_backing_snapshot: dict[int, float] = field(default_factory=dict)
    lost_physical_backing: dict[int, float] = field(default_factory=dict)
    protected_present: bool = True
    physical_live: bool = True
    forgotten_released: bool = False
    remote_claims: dict[int, float] = field(default_factory=dict)
    remote_overspend_recorded: bool = False
    at_risk_reason: str = ""
    contract_violation_recorded: bool = False
    underestimate_detected: bool = False
    underestimate_detected_epoch: Optional[int] = None
    forgetting_recorded: bool = False
    discharge_pending_recorded: bool = False
    evidence_failure_recorded: bool = False
    minimum_backing_violation_recorded: bool = False
    retire_recovery_enabled: bool = True
    physical_execution_completed: bool = False
    physical_completion_epoch: Optional[int] = None
    retire_pending_since: Optional[int] = None
    retire_consumed_amounts: dict[int, float] = field(default_factory=dict)
    rescued_recorded: bool = False
    retire_committed_recorded: bool = False
    simulation_epoch: int = 0
    certificate_ack_delay_epochs: int = 0
    certificate_not_before_epoch: int = 0
    retire_recovery_wait_epochs: int = 0
    physical_object: str = ""
    responsibility_scope: str = "full"
    responsibility_units: float = 1.0

    def __post_init__(self) -> None:
        if not self.physical_object:
            residual = self.assist_for if self.assist_for is not None else self.ident
            self.physical_object = f"residual:{residual}"

    @property
    def participants(self) -> tuple[int, ...]:
        return (self.carrier,) if self.support is None else (self.carrier, self.support)


@dataclass
class PolicyResult:
    policy: str
    rescued: int = 0
    missed: int = 0
    rejected: int = 0
    blocked: int = 0
    pre_start_failed: int = 0
    failed: int = 0
    unfinished: int = 0
    deadline_missed: int = 0
    silent_unbacking: int = 0
    at_risk: int = 0
    at_risk_resolved: int = 0
    ruptures: int = 0
    discharges: int = 0
    physical_completed: int = 0
    retire_certificate_committed: int = 0
    retire_pending: int = 0
    retire_recovered: int = 0
    retire_pending_at_end: int = 0
    mint_precommit_execution_cost: float = 0.0
    mint_aborted_after_cost: int = 0
    mint_execution_failures_after_certificate: int = 0
    certificate_confirmation_blocked: int = 0
    witness_unreachable_rejections: int = 0
    pending_lock_duration: int = 0
    blocked_by_pending_resources: int = 0
    stranded_robots: int = 0
    proposals: int = 0
    admitted: int = 0
    top_up_success: int = 0
    top_up_failed: int = 0
    degradation_events: int = 0
    illegal_degradation_violations: int = 0
    unauthorized_degradation_rejections: int = 0
    degradation_support_failures: int = 0
    degradation_policy_state_rejections: int = 0
    contract_degradation_attempts: int = 0
    contract_degradation_certificate_failures: int = 0
    pending_reservation_promotions: int = 0
    pending_reservation_rollbacks: int = 0
    pending_reservation_uncertain: int = 0
    certificate_ledger_mismatch_violations: int = 0
    handoff_attempts: int = 0
    handoff_success: int = 0
    handoff_blocked: int = 0
    handoff_failed: int = 0
    unbacked_window_count: int = 0
    replacement_before_release_violations: int = 0
    handoff_crash_during: int = 0
    handoff_old_crash_before: int = 0
    handoff_partition_after_certificate: int = 0
    commitment_loss: int = 0
    witness_copies_created: int = 0
    certificates_lost: int = 0
    forgotten: int = 0
    forgotten_commitments: int = 0
    physical_commitments_still_live: int = 0
    forgotten_and_resources_reused: int = 0
    orphaned_liability: float = 0.0
    orphaned_physical_liability: float = 0.0
    residual_after_rupture: int = 0
    ruptured_physical_liability: float = 0.0
    lost_physical_capacity: float = 0.0
    ruptured_locked_backing: float = 0.0
    illegal_rupture_release_violations: int = 0
    residual_liability_reuse_violations: int = 0
    observation_censored: int = 0
    certificate_survival_checks: int = 0
    certificate_survivors: int = 0
    witness_survival_rate: float = 0.0
    certificate_message_ops: int = 0
    certificate_candidates_created: int = 0
    certificate_candidates_committed: int = 0
    uncommitted_certificate_updates: int = 0
    insufficient_persistence_rejections: int = 0
    conflicting_certificate_candidates: int = 0
    certificate_survival_guarantee_violations: int = 0
    replay_attempts: int = 0
    replay_effective_attempts: int = 0
    replay_rejected: int = 0
    replay_current_noop: int = 0
    version_replay_accepted: int = 0
    replay_accepted: int = 0
    rollback_silent_unbacking: int = 0
    rollback_double_spend: int = 0
    stale_ownership: int = 0
    resource_reuse_after_rollback: int = 0
    planner_error_proposals: int = 0
    planner_errors_rejected: int = 0
    attack_attempts: int = 0
    immediately_detectable_attacks: int = 0
    admitted_attacks: int = 0
    attack_success: int = 0
    attack_success_rate: float = 0.0
    eventual_physical_violations: int = 0
    detection_rate: float = 0.0
    detection_count: int = 0
    detection_latency_total: int = 0
    detection_latency_mean: float = 0.0
    false_rejection_benign: int = 0
    adversarial_proposals: int = 0
    adversarial_accepted: int = 0
    adversarial_admitted: int = 0
    adversarial_rejected: int = 0
    adversarial_success: int = 0
    adversarial_physical_violation: int = 0
    illegal_degradation_attempts: int = 0
    illegal_degradation_accepted: int = 0
    illegal_degradation_rejected: int = 0
    remote_overspend_attempts: int = 0
    remote_overspend_accepted: int = 0
    remote_overspend_rejected: int = 0
    remote_overspend_blocked: int = 0
    remote_overspend_success: int = 0
    ownership_conflicts: int = 0
    remote_double_spend_events: int = 0
    silent_cancellation_attempts: int = 0
    silent_cancellation_accepted: int = 0
    silent_cancellation_rejected: int = 0
    silent_cancellation_success: int = 0
    illegal_degradation_success: int = 0
    underdeclared_attempts: int = 0
    underdeclared_admitted: int = 0
    minimum_backing_attack_attempts: int = 0
    minimum_backing_enforced: int = 0
    minimum_backing_rejected: int = 0
    minimum_backing_attack_success: int = 0
    minimum_backing_extra_reserved: float = 0.0
    infeasible_mint_events: int = 0
    underdeclared_physical_underbacking: int = 0
    underdeclared_failure_rate: float = 0.0
    lifecycle_attack_attempts: int = 0
    model_underestimate_events: int = 0
    bound_detection_count: int = 0
    bound_detection_latency_total: int = 0
    contract_bound_violations: int = 0
    physical_underbacking_events: int = 0
    semantic_liability_coverage_violations: int = 0
    forgotten_liability: int = 0
    durable_record_survival_violations: int = 0
    record_loss_beyond_fault_model: int = 0
    logical_transition_committed: int = 0
    old_resource_release_executed: int = 0
    retained_unavailable_resources: float = 0.0
    uncertain_commit_blocks: int = 0
    release_after_commit_failures: int = 0
    late_at_risk_discovery: int = 0
    late_detection: int = 0
    mean_detection_latency: float = 0.0
    physical_underbacking_rate: float = 0.0
    discharge_evidence_pending: int = 0
    discharge_evidence_missing: int = 0
    discharge_evidence_invalid: int = 0
    self_recovery_degradation_events: int = 0
    return_to_safe_halt: int = 0
    safe_halt_to_stranded: int = 0
    invariant_violations: int = 0
    capacity_violations: int = 0
    double_spend_violations: int = 0
    backing_violations: int = 0
    version_violations: int = 0
    release_violations: int = 0
    certificate_hash_violations: int = 0
    total_initial_energy: float = 0.0
    energy_consumed: float = 0.0
    total_energy_consumed: float = 0.0
    reserved_backing_consumed: float = 0.0
    reserved_backing_released_unused: float = 0.0
    wasted_reserve_at_discharge: float = 0.0
    wasted_reserved_energy: float = 0.0
    unused_reserved_energy: float = 0.0
    mean_energy_utilization: float = 0.0
    reservation_energy_area: float = 0.0
    reserved_energy_area: float = 0.0
    effective_reservation_energy_area: float = 0.0
    pending_reservation_energy_area: float = 0.0
    total_reserved_energy: float = 0.0
    reserved_energy_mean: float = 0.0
    mean_reserved_energy: float = 0.0
    mean_effective_reserved_energy: float = 0.0
    mean_pending_reserved_energy: float = 0.0
    peak_reserved_energy: float = 0.0
    peak_pending_reserved_energy: float = 0.0
    effective_reserved_energy_at_end: float = 0.0
    pending_reserved_energy_at_end: float = 0.0
    pending_consumed_backing_at_end: float = 0.0
    physical_locked_energy_at_end: float = 0.0
    pending_commitments_at_end: int = 0
    pending_uncertain_commitments_at_end: int = 0
    reserve_efficiency: Optional[float] = None
    reserve_efficiency_defined: bool = False
    total_commitment_lifetime: int = 0
    terminal_commitments: int = 0
    mean_commitment_lifetime: float = 0.0
    active_commitments_area: int = 0
    mean_active_commitments: float = 0.0
    peak_active_commitments: int = 0
    blocked_rate: float = 0.0
    silent_unbacking_rate: float = 0.0
    rescued_per_robot: float = 0.0
    admitted_per_robot: float = 0.0
    certificate_updates: int = 0
    witness_copy_operations: int = 0
    simulated_message_operations: int = 0
    runtime_seconds: float = 0.0
    runtime_per_trace: float = 0.0
    simulation_runtime_s: float = 0.0
    max_version_seen: dict[int, int] = field(default_factory=dict, repr=False)


@dataclass(frozen=True)
class DegradationTransition:
    robot: int
    before: str
    after: str
