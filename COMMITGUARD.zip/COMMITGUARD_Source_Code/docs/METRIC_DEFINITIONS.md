# Metric definitions

All metrics are per trace unless a table explicitly reports a total. Function names below refer to the implementation modules under `src/`; the unified entry point re-exports them.

| Metric | Raw field | Implemented meaning | Primary implementation |
|---|---|---|---|
| Physical Completed | `physical_completed` | A modeled physical execution reaches its settlement event and consumes its actual settlement requirement. It precedes protocol-level Retire confirmation. | `simulation.py::settle_commitment()` |
| Rescued | `rescued` | The policy's successful terminal outcome. For certificate policies it requires committed discharge/Retire; for simpler baselines it follows their modeled terminal rule. | `simulation.py::settle_commitment()` and `commitment.py::transition_discharge()` |
| Retire Pending at End | `retire_pending_at_end` | Physical completion occurred but a certificate-protected Retire remained unresolved when the finite observation window ended. | `simulation.py::finalize_trace_commitments()` |
| Silent Unbacking | `silent_unbacking` | Physical responsibility remains while backing/coverage disappears without an authorized transition or explicit exposed failure. This is driven by modeled physical history, not merely an internal assertion. | cancellation, crash, settlement, and physical-oracle paths in `policies.py`, `simulation.py`, and `security.py` |
| Internal Check Violations | `invariant_violations` | Observations raised by the policy-specific implementation invariant checker. The counter is not synonymous with the independent physical-history oracle and may count a persistent state at more than one check. | `security.py::check_invariants()` |
| Admission Blocking | `blocked` | Admission or protected lifecycle progress is conservatively refused because required view, confirmation, persistence, resource, or protected state is unavailable. | `mark_blocked()` and protected transition paths |
| Physical Underbacking | `physical_underbacking_events` | The true current physical requirement exceeds surviving backing after exogenous loss or demand change. It can coexist with semantic responsibility coverage and therefore does not imply Silent Unbacking. | physical oracle update in `simulation.py` |
| AT-RISK | `at_risk` | An explicit protected state indicating that the currently promised guarantee is no longer sufficiently backed. It retains the responsibility and any valid backing. | `commitment.py::transition_at_risk()`; inflation/crash paths |
| Reservation Efficiency | `reserve_efficiency` | `reserved_backing_consumed / (reserved_backing_consumed + reserved_backing_released_unused)`. Undefined for Immediate-only because it has no future reservation. | `simulation.py::finalize_result()` |
| Successful Top-up | `top_up_success` | Incremental backing needed after liability growth is safely obtained and incorporated. | `commitment.py::attempt_top_up()` |
| Failed Top-up | `top_up_failed` | The increment cannot be safely established; it does not silently remove the original obligation. | `attempt_top_up()` |
| Forgotten Commitment | `forgotten` | A live commitment has no surviving visible current certificate record in the modeled storage state. | `security.py::check_forgetting()` and `simulation.py::handle_crash()` |
| Record Loss Beyond Bound | `record_loss_beyond_fault_model` | Durable record loss after failures exceed the certificate's recorded tolerated crash bound. It is distinct from within-bound P3 failure. | `models.py::PhysicalLiabilityOracle` and `simulation.py::audit_simulated_physical_liabilities()` |
| Successful Handover | `handoff_success` | A configured successor/replacement path is accepted after replacement backing checks; the sweep also includes recovery-triggered paths independent of the active handoff probability. | `commitment.py::attempt_handoff()` |
| Blocked Handover | `handoff_blocked` | A handover attempt cannot safely confirm replacement/ownership conditions and retains the predecessor protection. | `attempt_handoff()` |
| Premature Release | `replacement_before_release_violations` | Old backing is released before valid replacement or discharge. | `commitment.py::attempt_handoff()` |
| Attack attempts/successes | `primary_attack_attempts`, `primary_attack_successes` | Scenario-specific valid denominator and successful unsafe state transition for A1--A4. Denominators are policy-specific and are never replaced by one global count. | `add_primary_attack_metrics()` and `security_attacks_experiment()` |
| Runtime | `simulation_runtime_s` | Wall-clock time of one Python discrete-event trace for the policy. It excludes real network/robot delays. | `simulate_policy()`/`scale_experiment()` |

## Statistical units

- Tables 2--6, 8, and 9 report arithmetic means over traces at a fixed configuration.
- Table 7 reports integer totals across valid attack attempts and success ratios derived from those totals.
- Paired comparisons first subtract policies within the same `trace_id`, then compute the sample mean, sample SD, and two-sided 95% Student-t interval.
- Table 10 reports the median of 200 in-process operation timings per size. The bundled formal file contains the aggregate rows, not the individual 200 timing observations.

## Important distinctions

`Physical Completed` is not a synonym for committed Retire. `Silent Unbacking` is not a synonym for resource shortage. `Forgotten` is not a synonym for beyond-bound durable record loss. Internal invariant observations and physical-history Oracle observations have different scope and must not be added together as though they were disjoint events.
