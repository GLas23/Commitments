# Modularization audit

The source was organized into six modules while retaining `src/commitguard_sim.py` as the command-line and import-compatible facade. Each implementation definition has one owner. The facade links names needed by mutually dependent lifecycle and policy functions; it does not copy or reimplement those functions.

| File | Responsibility |
|---|---|
| `src/models.py` | Constants, policy capabilities, parameters, proposals, events, robots, commitments, results, and physical liability state types. The physical liability oracle class remains here because model defaults refer to it during class creation. |
| `src/simulation.py` | Named random streams, trace generation, epoch execution, settlement, failures, physical completion, timing, and result finalization. |
| `src/commitment.py` | Certificate/version state, witness persistence, effective and pending reservations, resource release, guarantee transitions, Mint, Inflate, Transform, AT-RISK, rupture, and Retire. |
| `src/policies.py` | Proposal validation, five policy admission paths, cancellation, lifecycle attack application, and replay behavior. |
| `src/security.py` | Contract checks, forgetting and ownership checks, and protected invariant verification. |
| `src/experiments.py` | Aggregation, paired Student-t statistics, CSV/JSON output, default and sweep drivers, ablations, and microbenchmark. |
| `src/commitguard_sim.py` | Compatibility exports, module dependency linking, CLI argument parsing, and dispatch. |

## Dependency resolution

Lifecycle functions call policy and security functions, while those functions also call lifecycle transitions. The facade imports the modules once and links their exported names into the module namespaces before the CLI or tests call an experiment. This resolves the existing cycles without changing call order. The `--no-progress` flag is propagated to all modules; that affects display only. The five formal policies and §6.1–§6.7 experiment choices remain unchanged.

## Baseline and regression

- Baseline: cleaned single-file source, default experiment with 500 traces, seed 1; six existing tests and a two-trace smoke test passed before restructuring.
- Modular source: six existing tests and smoke test passed; syntax and import checks passed.
- Default rerun: 500 paired traces × five policies = 2,500 raw rows on each side.
- Exact non-timing comparison: 530,000 CSV cells, zero differences. This includes each policy's `trace_sha256`, admissions, lifecycle counters, physical outcomes, safety violations, resource balances, and pending state metrics.
- Trace SHA-256 mismatches: zero. Runtime fields (`runtime_seconds`, `runtime_per_trace`, `simulation_runtime_s`) were excluded from exact equality because they measure real execution time.
- Formal raw CSVs were carried over byte-for-byte; no formal experiment data or paper targets were changed.
- Tables 1–9 reproduce at paper precision. Table 10 remains `NOT VERIFIED` from primitive timing observations because only aggregate benchmark rows are available.

The 500-trace rerun validates default-workload equivalence. After module organization, all nine formal experiment entry points also completed a two-trace-per-configuration quick run (five microbenchmark repetitions). A full rerun of every 200-trace parameter sweep was not performed as part of this change.

## Scope

The archive contains the paper's Sections 6.1–6.7 implementation and data. It does not restore the removed Section 6.8 experiments. The software-only simulation, Table 10 primitive timing-data limitation, and lack of a granted open-source license remain as described in the existing documentation.
