"""Discrete-event simulator for COMMITGUARD paper experiments.

The simulator implements five policies, common-random-number workload traces,
commitment lifecycle transitions, resource accounting, safety checks, and
CSV/JSON output for the experiments in Sections 6.1--6.7.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Iterable, Optional

STATUS_LIVE = "live"
STATUS_DEGRADED = "degraded"
STATUS_AT_RISK = "at_risk"
STATUS_DISCHARGED = "discharged"
STATUS_RUPTURED = "ruptured"
STATUS_FORGOTTEN = "forgotten"
ACTIVE_STATUSES = {STATUS_LIVE, STATUS_DEGRADED, STATUS_AT_RISK}

SELF_RETURN = "return"
SELF_SAFE_HALT = "safe_halt"
SELF_STRANDED = "stranded_nonblocking"
SELF_LEVELS = (SELF_RETURN, SELF_SAFE_HALT, SELF_STRANDED)
SELF_FRACTION = {SELF_RETURN: 1.0, SELF_SAFE_HALT: 0.5, SELF_STRANDED: 0.0}
ALLOWED_SELF_DEGRADATION = {SELF_RETURN: SELF_SAFE_HALT, SELF_SAFE_HALT: SELF_STRANDED}

PROTECTED_POLICIES = {"static_worst_case", "central_commit_aware", "commit_guard"}
CERTIFICATE_POLICIES = {"central_commit_aware", "commit_guard"}
STRICT_POLICIES = {"commit_guard"}
LEGAL_RELEASE_REASONS = {"discharge", "terminal_policy_disposition", "handoff_replaced"}

POLICIES = [
    "immediate_only",
    "static_worst_case",
    "priority_cancel",
    "central_commit_aware",
    "commit_guard",
]

POLICY_LABELS = {
    "immediate_only": "Immediate-only",
    "static_worst_case": "Static worst-case reserve",
    "priority_cancel": "Priority-cancel",
    "central_commit_aware": "Central commit-aware",
    "commit_guard": "COMMIT GUARD",
}

CRITICALITY = {0: "low", 1: "medium", 2: "high"}
PROGRESS_ENABLED = True


@dataclass(frozen=True)
class PolicyCapabilities:
    has_commitment_ledger: bool
    has_exact_reservation: bool
    uses_static_worst_case: bool
    has_monotonic_version: bool
    has_certificate_auth: bool
    has_authenticated_certificate: bool
    has_witness_replication: bool
    has_local_resource_ownership: bool
    has_policy_degradation: bool
    has_at_risk_state: bool
    has_replacement_before_release: bool
    rejects_visible_planner_errors: bool
    has_certified_minimum_backing: bool
    requires_global_view: bool


POLICY_CAPABILITIES: dict[str, PolicyCapabilities] = {
    "immediate_only": PolicyCapabilities(
        has_commitment_ledger=False,
        has_exact_reservation=False,
        uses_static_worst_case=False,
        has_monotonic_version=False,
        has_certificate_auth=False,
        has_authenticated_certificate=False,
        has_witness_replication=False,
        has_local_resource_ownership=False,
        has_policy_degradation=False,
        has_at_risk_state=False,
        has_replacement_before_release=False,
        rejects_visible_planner_errors=False,
        has_certified_minimum_backing=False,
        requires_global_view=False,
    ),
    "static_worst_case": PolicyCapabilities(
        has_commitment_ledger=True,
        has_exact_reservation=False,
        uses_static_worst_case=True,
        has_monotonic_version=False,
        has_certificate_auth=False,
        has_authenticated_certificate=False,
        has_witness_replication=False,
        has_local_resource_ownership=False,
        has_policy_degradation=False,
        has_at_risk_state=True,
        has_replacement_before_release=False,
        rejects_visible_planner_errors=True,
        has_certified_minimum_backing=False,
        requires_global_view=False,
    ),
    "priority_cancel": PolicyCapabilities(
        has_commitment_ledger=True,
        has_exact_reservation=True,
        uses_static_worst_case=False,
        has_monotonic_version=False,
        has_certificate_auth=False,
        has_authenticated_certificate=False,
        has_witness_replication=False,
        has_local_resource_ownership=False,
        has_policy_degradation=False,
        has_at_risk_state=False,
        has_replacement_before_release=False,
        rejects_visible_planner_errors=True,
        has_certified_minimum_backing=False,
        requires_global_view=False,
    ),
    "central_commit_aware": PolicyCapabilities(
        has_commitment_ledger=True,
        has_exact_reservation=True,
        uses_static_worst_case=False,
        has_monotonic_version=True,
        has_certificate_auth=True,
        has_authenticated_certificate=True,
        has_witness_replication=False,
        has_local_resource_ownership=False,
        has_policy_degradation=True,
        has_at_risk_state=True,
        has_replacement_before_release=True,
        rejects_visible_planner_errors=True,
        has_certified_minimum_backing=False,
        requires_global_view=True,
    ),
    "commit_guard": PolicyCapabilities(
        has_commitment_ledger=True,
        has_exact_reservation=True,
        uses_static_worst_case=False,
        has_monotonic_version=True,
        has_certificate_auth=True,
        has_authenticated_certificate=True,
        has_witness_replication=True,
        has_local_resource_ownership=True,
        has_policy_degradation=True,
        has_at_risk_state=True,
        has_replacement_before_release=True,
        rejects_visible_planner_errors=True,
        has_certified_minimum_backing=True,
        requires_global_view=False,
    ),
}

def caps(policy: str) -> PolicyCapabilities:
    return POLICY_CAPABILITIES[policy]


@dataclass(frozen=True)
class Params:
    robots: int = 10
    initial_energy: float = 100.0
    epochs: int = 80
    proposal_prob: float = 0.55
    immediate_cost_min: float = 3.0
    immediate_cost_max: float = 7.0
    carrier_bound_min: float = 10.0
    carrier_bound_max: float = 18.0
    support_required_prob: float = 0.45
    support_bound_min: float = 3.0
    support_bound_max: float = 7.0
    min_carrier_low: float = 8.0
    min_carrier_medium: float = 9.0
    min_carrier_high: float = 10.0
    min_support_low: float = 1.0
    min_support_medium: float = 2.0
    min_support_high: float = 3.0
    self_recovery_guarantee: float = 12.0
    partition_start_prob: float = 0.08
    partition_duration_min: int = 2
    partition_duration_max: int = 8
    inflation_prob: float = 0.10
    inflation_multiplier_min: float = 1.10
    inflation_multiplier_max: float = 1.35
    crash_prob: float = 0.002
    settlement_ratio_min: float = 0.90
    settlement_ratio_max: float = 1.00
    static_worst_case_multiplier: float = 1.60
    medium_high_degrade_self_recovery: bool = True
    completion_duration_min: int = 2
    completion_duration_max: int = 12
    deadline_tightness: float = 1.0
    proposal_mode: str = "bernoulli"
    proposal_load_per_robot: float = 0.055
    handoff_prob: float = 0.0
    handoff_replacement_scarcity: float = 0.0
    handoff_crash_prob: float = 0.0
    handoff_old_crash_prob: float = 0.0
    handoff_partition_after_certificate_prob: float = 0.0
    version_replay_prob: float = 0.0
    lifecycle_attack_prob: float = 0.0
    lifecycle_attack_kind: str = "mixed"
    adversarial_proposal_prob: float = 0.0
    attack_mode: str = "mixed"
    adversarial_cost_multiplier: float = 4.0
    bound_error: float = 0.0
    underreport_fraction: float = 0.5
    evidence_delay_max: int = 0
    evidence_missing_prob: float = 0.0
    evidence_invalid_prob: float = 0.0
    witness_count: int = 2
    contract_degradation_enabled: bool = False
    contract_degraded_carrier_requirement: float = 8.0
    contract_degraded_support_requirement: float = 2.0
    contract_degradation_config_source: str = "disabled"
    # Diagnostic switches do not participate in trace generation.
    retire_recovery_enabled: bool = True
    mint_deferred_execution: bool = True
    witness_selection_mode: str = "reachable"
    diagnostic_legacy_threshold: bool = False
    certificate_ack_delay_epochs: int = 0
    retire_recovery_wait_epochs: int = 0


@dataclass(frozen=True)
class Proposal:
    ident: int
    epoch: int
    carrier: int
    support: Optional[int]
    criticality: int
    immediate_cost: float
    carrier_bound: float
    support_bound: float
    true_carrier_bound: float
    true_support_bound: float
    deadline: int
    duration: int
    settlement_ratio: float
    witness_order: tuple[int, ...]
    adversarial: bool = False
    adversarial_kind: str = ""
    ground_truth_attack: str = ""
    requested_self_degradation: str = ""
    uses_remote_rights: bool = False
    silent_cancel_requested: bool = False
    evidence_delay: int = 0
    evidence_valid: bool = True
    evidence_missing: bool = False
    # An explicitly modeled irreversible cost before the physical commit point.
    precommit_preparation_cost: float = 0.0
    physical_execution_success: bool = True

    @property
    def due_epoch(self) -> int:
        return self.epoch + self.deadline

    @property
    def finish_epoch(self) -> int:
        return self.epoch + self.duration

    @property
    def evidence_epoch(self) -> int:
        return self.finish_epoch + self.evidence_delay

    @property
    def participants(self) -> tuple[int, ...]:
        return (self.carrier,) if self.support is None else (self.carrier, self.support)


@dataclass(frozen=True)
class InflationEvent:
    epoch: int
    pick: float
    multiplier: float


@dataclass(frozen=True)
class HandoffEvent:
    epoch: int
    pick: float
    role_pick: float
    target_order: tuple[int, ...]
    replacement_blocked: bool = False
    crash_during: bool = False
    old_crash_before: bool = False
    partition_after_certificate: bool = False
    old_crash_after_certificate: bool = False


@dataclass(frozen=True)
class HandoffEvidence:
    """Trusted simulation input; distinct from final Retire evidence."""
    residual_id: int
    contract_id: str
    kind: str  # safe_wait or physical_takeover
    epoch: int
    trusted: bool
    valid: bool
    physically_observed: bool


@dataclass(frozen=True)
class TwoStageContract:
    contract_id: str
    original_requirement: float
    successor_requirement: float
    safe_wait_authorized: bool = True
    physical_takeover_authorized: bool = True
    witness_recovery_authorized: bool = False


@dataclass(frozen=True)
class PhysicalEvent:
    epoch: int
    residual_id: int
    kind: str
    robot: int
    trusted: bool = True
    required_backing: float = 0.0
    physical_object: str = ""
    contract_id: str = ""
    responsibility_scope: str = ""
    responsibility_units: float = 1.0
    resource_requirements: tuple[tuple[int, float], ...] = ()


@dataclass
class PhysicalLiabilityOracle:
    """Experimental truth derived only from exogenous physical events.

    The mechanism never reads this object when admitting or releasing work.
    Software cancellation and certificate deletion are intentionally ignored.
    """
    events: list[PhysicalEvent] = field(default_factory=list)
    residuals: dict[int, str] = field(default_factory=dict)
    physical_owners: dict[int, int] = field(default_factory=dict)
    required_backing: dict[int, float] = field(default_factory=dict)
    physical_objects: dict[int, str] = field(default_factory=dict)
    contract_ids: dict[int, str] = field(default_factory=dict)
    responsibility_scopes: dict[int, str] = field(default_factory=dict)
    responsibility_units: dict[int, float] = field(default_factory=dict)
    resource_requirements: dict[int, dict[int, float]] = field(default_factory=dict)
    registered_records: dict[int, list[dict[str, object]]] = field(default_factory=dict)
    required_record_ids: dict[int, set[int]] = field(default_factory=dict)
    semantic_violation_history: set[int] = field(default_factory=set)
    physical_underbacking_history: set[int] = field(default_factory=set)
    forgotten_history: set[int] = field(default_factory=set)
    durable_violation_history: set[int] = field(default_factory=set)
    beyond_fault_model_history: set[int] = field(default_factory=set)

    def observe(self, event: PhysicalEvent) -> None:
        self.events.append(event)
        if not event.trusted:
            return
        if event.kind == "physical_commit":
            self.residuals[event.residual_id] = "placement"
            self.physical_owners[event.residual_id] = event.robot
            self.required_backing[event.residual_id] = event.required_backing
            self.physical_objects[event.residual_id] = event.physical_object or f"residual:{event.residual_id}"
            self.contract_ids[event.residual_id] = event.contract_id
            self.responsibility_scopes[event.residual_id] = event.responsibility_scope or "full"
            self.responsibility_units[event.residual_id] = event.responsibility_units
            self.resource_requirements[event.residual_id] = dict(event.resource_requirements)
        elif event.kind == "safe_wait" and self.residuals.get(event.residual_id) == "placement":
            self.residuals[event.residual_id] = "transport"
            self.physical_owners[event.residual_id] = event.robot
            if event.required_backing > 0:
                self.required_backing[event.residual_id] = event.required_backing
        elif event.kind == "physical_takeover" and event.residual_id in self.residuals:
            self.residuals[event.residual_id] = "takeover"
            self.physical_owners[event.residual_id] = event.robot
            if event.required_backing > 0:
                self.required_backing[event.residual_id] = event.required_backing
        elif event.kind == "responsibility_handoff" and event.residual_id in self.residuals:
            self.physical_owners[event.residual_id] = event.robot
            if event.required_backing > 0:
                self.required_backing[event.residual_id] = event.required_backing
        elif event.kind == "physical_discharge":
            self.residuals.pop(event.residual_id, None)
            self.physical_owners.pop(event.residual_id, None)
            self.required_backing.pop(event.residual_id, None)
            self.physical_objects.pop(event.residual_id, None)
            self.contract_ids.pop(event.residual_id, None)
            self.responsibility_scopes.pop(event.residual_id, None)
            self.responsibility_units.pop(event.residual_id, None)
            self.resource_requirements.pop(event.residual_id, None)

    def register_commitment(self, residual_id: int, commitment: Commitment) -> None:
        """Remember the declared durability envelope before a later state loss."""
        effective = commitment.effective_version
        if effective <= 0:
            return
        record = {
            "commitment_id": commitment.ident,
            "version": effective,
            "persisted": set(commitment.certificate_persisted_versions.get(effective, set())),
            "fault_tolerance": commitment.certificate_fault_tolerance,
            "threshold": commitment.certificate_persistence_threshold,
        }
        records = self.registered_records.setdefault(residual_id, [])
        # A certified successor replaces its predecessor's durability envelope.
        # Testing every obsolete quorum would incorrectly charge a later >f loss
        # against an earlier version whose holders legitimately moved on.
        previous = next((r for r in records if r["commitment_id"] == commitment.ident), None)
        if previous is None:
            records.append(record)
        elif int(previous["version"]) < effective and self._effective_record_valid(commitment):
            records[records.index(previous)] = record

    @staticmethod
    def _effective_record_valid(commitment: Commitment) -> bool:
        semantic_record_states = ACTIVE_STATUSES | {STATUS_RUPTURED}
        if not commitment.protected_present or not commitment.physical_live or commitment.status not in semantic_record_states:
            return False
        effective = commitment.effective_version
        if effective <= 0:
            return True
        snapshot = commitment.certificate_history.get(effective)
        metadata = commitment.certificate_metadata.get(effective)
        if snapshot is None or metadata is None:
            return False
        if commitment.version_state_hashes.get(effective) != snapshot_hash(snapshot):
            return False
        predecessor = int(metadata.get("predecessor", -1))
        if commitment.certificate_successors.get(predecessor) != effective:
            return False
        if str(snapshot.get("status", "")) not in semantic_record_states or not bool(snapshot.get("physical_live", False)):
            return False
        inheritance = metadata.get("responsibility_inheritance", {})
        if not isinstance(inheritance, dict):
            return False
        for key in ("carrier", "support", "guarantee", "phase_contract_id", "physical_stage", "assist_for",
                    "physical_object", "responsibility_scope", "responsibility_units"):
            if inheritance.get(key) != snapshot.get(key):
                return False
            if snapshot.get(key) != getattr(commitment, key):
                return False
        return True

    def _semantic_covers(self, residual_id: int, commitment: Commitment) -> bool:
        if not self._effective_record_valid(commitment):
            return False
        if commitment.ident != residual_id and commitment.assist_for != residual_id:
            return False
        if commitment.physical_object != self.physical_objects[residual_id]:
            return False
        if commitment.responsibility_scope != self.responsibility_scopes[residual_id]:
            return False
        if commitment.responsibility_units + 1e-9 < self.responsibility_units[residual_id]:
            return False
        expected_contract = self.contract_ids.get(residual_id, "")
        if expected_contract and commitment.phase_contract_id != expected_contract:
            return False
        stage = self.residuals[residual_id]
        allowed_stages = {
            "placement": {"placement"},
            "transport": {"transport"},
            "takeover": {"takeover"},
        }[stage]
        # The original full obligation continues to name the residual while
        # Transform is unconfirmed. Physical progress is not software discharge.
        # A replacement record, however, must carry the observed stage and a
        # certified/evidenced inheritance; naming assist_for alone is insufficient.
        original_retained = commitment.ident == residual_id and commitment.physical_stage == "placement"
        if not original_retained:
            if commitment.physical_stage not in allowed_stages:
                return False
            if commitment.assist_for is not None and not commitment.phase_evidence_hash:
                return False
        # Energy demand is intentionally absent: it is physical backing, not
        # a measure of the semantic amount of responsibility being inherited.
        return True

    @staticmethod
    def _durable_record_survives(commitment: Commitment, robots: list[Robot]) -> bool:
        if not commitment.protected_present:
            return False
        effective = commitment.effective_version
        if effective <= 0:
            return commitment.protected_present and any(
                0 <= holder < len(robots) and robots[holder].active
                for holder in commitment.participants
            )
        if effective not in commitment.certificate_history or effective not in commitment.certificate_metadata:
            return False
        if not PhysicalLiabilityOracle._effective_record_valid(commitment):
            return False
        persisted = commitment.certificate_persisted_versions.get(effective, set())
        return any(
            0 <= holder < len(robots) and robots[holder].active
            and commitment.certificate_versions.get(holder) == effective
            for holder in persisted
        )

    def _physically_backed(self, residual_id: int, commitment: Commitment, robots: list[Robot]) -> bool:
        needs = self.resource_requirements.get(residual_id) or {
            self.physical_owners[residual_id]: self.required_backing.get(residual_id, 0.0)
        }
        for owner, required in needs.items():
            if not (0 <= owner < len(robots) and robots[owner].active):
                return False
            if robots[owner].energy + 1e-9 < required:
                return False
            if commitment.reserved or commitment.effective_version > 0:
                if (commitment.reserved.get(owner, 0.0) + 1e-9 < required
                        or robots[owner].reserved.get(commitment.ident, 0.0) + 1e-9 < required):
                    return False
        return True

    def audit(
        self, commitments: Iterable[Commitment], robots: list[Robot],
        coverage_claims: dict[int, set[int]], releases: Iterable[tuple[int, bool]],
    ) -> dict[str, int]:
        commitment_list = list(commitments)
        by_id = {c.ident: c for c in commitment_list}
        semantic_uncovered = physical_underbacking = forgotten = 0
        durable_violations = beyond_fault_model = 0
        for residual_id in self.residuals:
            candidate_ids = coverage_claims.get(residual_id, set())
            records = [by_id[cid] for cid in candidate_ids if cid in by_id]
            semantic_records = [c for c in records if self._semantic_covers(residual_id, c)]
            if semantic_records:
                self.required_record_ids[residual_id] = {c.ident for c in semantic_records}
            durable_records = [c for c in semantic_records if self._durable_record_survives(c, robots)]
            if not durable_records:
                forgotten += 1
                self.forgotten_history.add(residual_id)
            if not semantic_records:
                semantic_uncovered += 1
                self.semantic_violation_history.add(residual_id)
            if not any(self._physically_backed(residual_id, c, robots) for c in records):
                physical_underbacking += 1
                self.physical_underbacking_history.add(residual_id)
            if not durable_records:
                guarantees = self.registered_records.get(residual_id, [])
                necessary = self.required_record_ids.get(residual_id)
                if necessary is not None:
                    guarantees = [g for g in guarantees if g["commitment_id"] in necessary]
                in_model_loss = False
                beyond_model_loss = False
                for guarantee in guarantees:
                    persisted = set(guarantee["persisted"])
                    threshold = int(guarantee["threshold"])
                    fault_tolerance = int(guarantee["fault_tolerance"])
                    if len(persisted) < threshold:
                        continue
                    crashes = sum(1 for h in persisted if not (0 <= h < len(robots) and robots[h].active))
                    if crashes <= fault_tolerance:
                        in_model_loss = True
                    else:
                        beyond_model_loss = True
                durable_violations += int(in_model_loss)
                beyond_fault_model += int(not in_model_loss and beyond_model_loss)
                if in_model_loss:
                    self.durable_violation_history.add(residual_id)
                elif beyond_model_loss:
                    self.beyond_fault_model_history.add(residual_id)
            for commitment in records:
                self.register_commitment(residual_id, commitment)
        return {
            "semantic_liability_coverage_violations": semantic_uncovered,
            "liability_coverage_violations": semantic_uncovered,
            "physical_underbacking_events": physical_underbacking,
            "forgotten_liability": forgotten,
            "durable_record_survival_violations": durable_violations,
            "record_loss_beyond_fault_model": beyond_fault_model,
            "illegal_release_events": sum(1 for residual_id, authorized in releases
                                          if residual_id in self.residuals and not authorized),
        }

    def cumulative_report(self) -> dict[str, int]:
        return {
            "semantic_liability_coverage_violations": len(self.semantic_violation_history),
            "physical_underbacking_events": len(self.physical_underbacking_history),
            "forgotten_liability": len(self.forgotten_history),
            "durable_record_survival_violations": len(self.durable_violation_history),
            "record_loss_beyond_fault_model": len(self.beyond_fault_model_history),
        }


@dataclass(frozen=True)
class ReplayEvent:
    epoch: int
    pick: float
    stale_offset: int


@dataclass(frozen=True)
class LifecycleAttackEvent:
    epoch: int
    kind: str
    pick: float


@dataclass(frozen=True)
class PartitionState:
    groups: tuple[frozenset[int], frozenset[int]]
    until_epoch: int


@dataclass(frozen=True)
class Trace:
    proposals_by_epoch: dict[int, list[Proposal]]
    inflations_by_epoch: dict[int, list[InflationEvent]]
    crashes_by_epoch: dict[int, list[int]]
    partitions_by_epoch: dict[int, PartitionState]
    handoffs_by_epoch: dict[int, list[HandoffEvent]]
    replays_by_epoch: dict[int, list[ReplayEvent]]
    lifecycle_attacks_by_epoch: dict[int, list[LifecycleAttackEvent]]


@dataclass
class Robot:
    energy: float
    self_base: float
    self_level: str = SELF_RETURN
    active: bool = True
    reserved: dict[int, float] = field(default_factory=dict)
    remote_reserved: dict[int, float] = field(default_factory=dict)
    pending_execution_cost: dict[int, float] = field(default_factory=dict)

    @property
    def total_reserved(self) -> float:
        return sum(self.reserved.values()) + sum(self.remote_reserved.values()) + sum(self.pending_execution_cost.values())

    @property
    def self_reserve(self) -> float:
        return self.self_base * SELF_FRACTION[self.self_level]

    @property
    def free(self) -> float:
        if not self.active:
            return 0.0
        return self.energy - self.self_reserve - self.total_reserved


@dataclass
class Commitment:
    ident: int
    proposal: Proposal
    initiator: int
    carrier: int
    support: Optional[int]
    criticality: int
    created_epoch: int
    due_epoch: int
    finish_epoch: int
    claimed_req: dict[int, float]
    true_req: dict[int, float]
    certified_min_req: dict[int, float]
    initial_claimed_req: dict[int, float]
    reserved: dict[int, float]
    # ``reserved`` is the effective logical allocation declared by the latest
    # committed certificate.  Pending locks are physically unavailable but do
    # not become effective rights until their candidate certificate commits.
    effective_reserved: dict[int, float] = field(default_factory=dict)
    pending_reserved: dict[int, float] = field(default_factory=dict)
    pending_consumed_backing: dict[int, float] = field(default_factory=dict)
    pending_operation: str = ""
    pending_version: Optional[int] = None
    last_certificate_result: str = ""
    status: str = STATUS_LIVE
    guarantee: str = "full"
    version: int = 1
    effective_version: int = 0
    witnesses: set[int] = field(default_factory=set)
    certificate_versions: dict[int, int] = field(default_factory=dict)
    certificate_history: dict[int, dict[str, object]] = field(default_factory=dict)
    version_state_hashes: dict[int, str] = field(default_factory=dict)
    certificate_candidates: dict[int, dict[str, object]] = field(default_factory=dict)
    certificate_candidate_hashes: dict[int, str] = field(default_factory=dict)
    certificate_acknowledgements: dict[int, set[int]] = field(default_factory=dict)
    certificate_persisted_versions: dict[int, set[int]] = field(default_factory=dict)
    certificate_message_drops: set[int] = field(default_factory=set)
    network_partition: Optional[PartitionState] = None
    handoff_requires_old_guard: bool = False
    phase_contract_id: str = ""
    physical_stage: str = "placement"
    phase_evidence_hash: str = ""
    assist_for: Optional[int] = None
    certificate_metadata: dict[int, dict[str, object]] = field(default_factory=dict)
    certificate_successors: dict[int, int] = field(default_factory=dict)
    certificate_fault_tolerance: int = 0
    certificate_persistence_threshold: int = 1
    certificate_update_uncertain: bool = False
    contract_guarantee_requirements: dict[str, dict[int, float]] = field(default_factory=dict)
    authorized_degradation_edges: set[tuple[str, str]] = field(default_factory=set)
    lifecycle_events: list[dict[str, object]] = field(default_factory=list)
    release_events: list[dict[str, object]] = field(default_factory=list)
    discharge_evidence_validated: bool = False
    terminal_disposition_authorized: bool = False
    rupture_residual_recorded: bool = False
    rupture_backing_snapshot: dict[int, float] = field(default_factory=dict)
    at_risk_backing_snapshot: dict[int, float] = field(default_factory=dict)
    lost_physical_backing: dict[int, float] = field(default_factory=dict)
    protected_present: bool = True
    physical_live: bool = True
    forgotten_released: bool = False
    remote_claims: dict[int, float] = field(default_factory=dict)
    remote_overspend_recorded: bool = False
    at_risk_reason: str = ""
    contract_violation_recorded: bool = False
    underestimate_detected: bool = False
    underestimate_detected_epoch: Optional[int] = None
    forgetting_recorded: bool = False
    discharge_pending_recorded: bool = False
    evidence_failure_recorded: bool = False
    minimum_backing_violation_recorded: bool = False
    retire_recovery_enabled: bool = True
    physical_execution_completed: bool = False
    physical_completion_epoch: Optional[int] = None
    retire_pending_since: Optional[int] = None
    retire_consumed_amounts: dict[int, float] = field(default_factory=dict)
    rescued_recorded: bool = False
    retire_committed_recorded: bool = False
    simulation_epoch: int = 0
    certificate_ack_delay_epochs: int = 0
    certificate_not_before_epoch: int = 0
    retire_recovery_wait_epochs: int = 0
    physical_object: str = ""
    responsibility_scope: str = "full"
    responsibility_units: float = 1.0

    def __post_init__(self) -> None:
        if not self.physical_object:
            residual = self.assist_for if self.assist_for is not None else self.ident
            self.physical_object = f"residual:{residual}"

    @property
    def participants(self) -> tuple[int, ...]:
        return (self.carrier,) if self.support is None else (self.carrier, self.support)


@dataclass
class PolicyResult:
    policy: str
    rescued: int = 0
    missed: int = 0
    rejected: int = 0
    blocked: int = 0
    pre_start_failed: int = 0
    failed: int = 0
    unfinished: int = 0
    deadline_missed: int = 0
    silent_unbacking: int = 0
    at_risk: int = 0
    at_risk_resolved: int = 0
    ruptures: int = 0
    discharges: int = 0
    physical_completed: int = 0
    retire_certificate_committed: int = 0
    retire_pending: int = 0
    retire_recovered: int = 0
    retire_pending_at_end: int = 0
    mint_precommit_execution_cost: float = 0.0
    mint_aborted_after_cost: int = 0
    mint_execution_failures_after_certificate: int = 0
    certificate_confirmation_blocked: int = 0
    witness_unreachable_rejections: int = 0
    pending_lock_duration: int = 0
    blocked_by_pending_resources: int = 0
    stranded_robots: int = 0
    proposals: int = 0
    admitted: int = 0
    top_up_success: int = 0
    top_up_failed: int = 0
    degradation_events: int = 0
    illegal_degradation_violations: int = 0
    unauthorized_degradation_rejections: int = 0
    degradation_support_failures: int = 0
    degradation_policy_state_rejections: int = 0
    contract_degradation_attempts: int = 0
    contract_degradation_certificate_failures: int = 0
    pending_reservation_promotions: int = 0
    pending_reservation_rollbacks: int = 0
    pending_reservation_uncertain: int = 0
    certificate_ledger_mismatch_violations: int = 0
    handoff_attempts: int = 0
    handoff_success: int = 0
    handoff_blocked: int = 0
    handoff_failed: int = 0
    unbacked_window_count: int = 0
    replacement_before_release_violations: int = 0
    handoff_crash_during: int = 0
    handoff_old_crash_before: int = 0
    handoff_partition_after_certificate: int = 0
    commitment_loss: int = 0
    witness_copies_created: int = 0
    certificates_lost: int = 0
    forgotten: int = 0
    forgotten_commitments: int = 0
    physical_commitments_still_live: int = 0
    forgotten_and_resources_reused: int = 0
    orphaned_liability: float = 0.0
    orphaned_physical_liability: float = 0.0
    residual_after_rupture: int = 0
    ruptured_physical_liability: float = 0.0
    lost_physical_capacity: float = 0.0
    ruptured_locked_backing: float = 0.0
    illegal_rupture_release_violations: int = 0
    residual_liability_reuse_violations: int = 0
    observation_censored: int = 0
    certificate_survival_checks: int = 0
    certificate_survivors: int = 0
    witness_survival_rate: float = 0.0
    certificate_message_ops: int = 0
    certificate_candidates_created: int = 0
    certificate_candidates_committed: int = 0
    uncommitted_certificate_updates: int = 0
    insufficient_persistence_rejections: int = 0
    conflicting_certificate_candidates: int = 0
    certificate_survival_guarantee_violations: int = 0
    replay_attempts: int = 0
    replay_effective_attempts: int = 0
    replay_rejected: int = 0
    replay_current_noop: int = 0
    version_replay_accepted: int = 0
    replay_accepted: int = 0
    rollback_silent_unbacking: int = 0
    rollback_double_spend: int = 0
    stale_ownership: int = 0
    resource_reuse_after_rollback: int = 0
    planner_error_proposals: int = 0
    planner_errors_rejected: int = 0
    attack_attempts: int = 0
    immediately_detectable_attacks: int = 0
    admitted_attacks: int = 0
    attack_success: int = 0
    attack_success_rate: float = 0.0
    eventual_physical_violations: int = 0
    detection_rate: float = 0.0
    detection_count: int = 0
    detection_latency_total: int = 0
    detection_latency_mean: float = 0.0
    false_rejection_benign: int = 0
    adversarial_proposals: int = 0
    adversarial_accepted: int = 0
    adversarial_admitted: int = 0
    adversarial_rejected: int = 0
    adversarial_success: int = 0
    adversarial_physical_violation: int = 0
    illegal_degradation_attempts: int = 0
    illegal_degradation_accepted: int = 0
    illegal_degradation_rejected: int = 0
    remote_overspend_attempts: int = 0
    remote_overspend_accepted: int = 0
    remote_overspend_rejected: int = 0
    remote_overspend_blocked: int = 0
    remote_overspend_success: int = 0
    ownership_conflicts: int = 0
    remote_double_spend_events: int = 0
    silent_cancellation_attempts: int = 0
    silent_cancellation_accepted: int = 0
    silent_cancellation_rejected: int = 0
    silent_cancellation_success: int = 0
    illegal_degradation_success: int = 0
    underdeclared_attempts: int = 0
    underdeclared_admitted: int = 0
    minimum_backing_attack_attempts: int = 0
    minimum_backing_enforced: int = 0
    minimum_backing_rejected: int = 0
    minimum_backing_attack_success: int = 0
    minimum_backing_extra_reserved: float = 0.0
    infeasible_mint_events: int = 0
    underdeclared_physical_underbacking: int = 0
    underdeclared_failure_rate: float = 0.0
    lifecycle_attack_attempts: int = 0
    model_underestimate_events: int = 0
    bound_detection_count: int = 0
    bound_detection_latency_total: int = 0
    contract_bound_violations: int = 0
    physical_underbacking_events: int = 0
    semantic_liability_coverage_violations: int = 0
    forgotten_liability: int = 0
    durable_record_survival_violations: int = 0
    record_loss_beyond_fault_model: int = 0
    logical_transition_committed: int = 0
    old_resource_release_executed: int = 0
    retained_unavailable_resources: float = 0.0
    uncertain_commit_blocks: int = 0
    release_after_commit_failures: int = 0
    late_at_risk_discovery: int = 0
    late_detection: int = 0
    mean_detection_latency: float = 0.0
    physical_underbacking_rate: float = 0.0
    discharge_evidence_pending: int = 0
    discharge_evidence_missing: int = 0
    discharge_evidence_invalid: int = 0
    self_recovery_degradation_events: int = 0
    return_to_safe_halt: int = 0
    safe_halt_to_stranded: int = 0
    invariant_violations: int = 0
    capacity_violations: int = 0
    double_spend_violations: int = 0
    backing_violations: int = 0
    version_violations: int = 0
    release_violations: int = 0
    certificate_hash_violations: int = 0
    total_initial_energy: float = 0.0
    energy_consumed: float = 0.0
    total_energy_consumed: float = 0.0
    reserved_backing_consumed: float = 0.0
    reserved_backing_released_unused: float = 0.0
    wasted_reserve_at_discharge: float = 0.0
    wasted_reserved_energy: float = 0.0
    unused_reserved_energy: float = 0.0
    mean_energy_utilization: float = 0.0
    reservation_energy_area: float = 0.0
    reserved_energy_area: float = 0.0
    effective_reservation_energy_area: float = 0.0
    pending_reservation_energy_area: float = 0.0
    total_reserved_energy: float = 0.0
    reserved_energy_mean: float = 0.0
    mean_reserved_energy: float = 0.0
    mean_effective_reserved_energy: float = 0.0
    mean_pending_reserved_energy: float = 0.0
    peak_reserved_energy: float = 0.0
    peak_pending_reserved_energy: float = 0.0
    effective_reserved_energy_at_end: float = 0.0
    pending_reserved_energy_at_end: float = 0.0
    pending_consumed_backing_at_end: float = 0.0
    physical_locked_energy_at_end: float = 0.0
    pending_commitments_at_end: int = 0
    pending_uncertain_commitments_at_end: int = 0
    reserve_efficiency: Optional[float] = None
    reserve_efficiency_defined: bool = False
    total_commitment_lifetime: int = 0
    terminal_commitments: int = 0
    mean_commitment_lifetime: float = 0.0
    active_commitments_area: int = 0
    mean_active_commitments: float = 0.0
    peak_active_commitments: int = 0
    blocked_rate: float = 0.0
    silent_unbacking_rate: float = 0.0
    rescued_per_robot: float = 0.0
    admitted_per_robot: float = 0.0
    certificate_updates: int = 0
    witness_copy_operations: int = 0
    simulated_message_operations: int = 0
    runtime_seconds: float = 0.0
    runtime_per_trace: float = 0.0
    simulation_runtime_s: float = 0.0
    max_version_seen: dict[int, int] = field(default_factory=dict, repr=False)


@dataclass(frozen=True)
class DegradationTransition:
    robot: int
    before: str
    after: str


def weighted_criticality(rng: random.Random) -> int:
    x = rng.random()
    if x < 0.50:
        return 0
    if x < 0.80:
        return 1
    return 2


def stream_seed(seed: int, name: str) -> int:
    digest = hashlib.sha256(f"{seed}:{name}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def rng_stream(seed: int, name: str) -> random.Random:
    return random.Random(stream_seed(seed, name))


def epoch_rng(seed: int, family: str, epoch: int) -> random.Random:
    return random.Random(stream_seed(seed, f"{family}:{epoch}"))


def poisson(rng: random.Random, lam: float) -> int:
    if lam <= 0:
        return 0
    if lam < 30:
        threshold = math.exp(-lam)
        k = 0
        product = 1.0
        while product > threshold:
            k += 1
            product *= rng.random()
        return k - 1
    return max(0, int(round(rng.gauss(lam, math.sqrt(lam)))))


def proposal_count_for_epoch(params: Params, arrival_rng: random.Random) -> int:
    if params.proposal_mode == "poisson_per_robot":
        return poisson(arrival_rng, params.proposal_load_per_robot * params.robots)
    return 1 if arrival_rng.random() < params.proposal_prob else 0


def maybe_adversarial(rng: random.Random, params: Params) -> tuple[bool, str]:
    if rng.random() >= params.adversarial_proposal_prob:
        return False, ""
    if params.attack_mode != "mixed":
        return True, params.attack_mode
    return True, rng.choice(
        [
            "duplicate_participant",
            "impossible_cost",
            "underdeclared_bound",
            "unauthorized_degradation",
            "remote_right_overspend",
            "silent_cancellation",
        ]
    )


def true_factor_from_bound_error(rng: random.Random, epsilon: float) -> float:
    if epsilon >= 0:
        return 1.0 + rng.uniform(0.0, epsilon)
    return max(0.05, 1.0 - rng.uniform(0.0, abs(epsilon)))


def duration_before_deadline(timing_rng: random.Random, params: Params, deadline: int) -> int:
    lower = max(1, params.completion_duration_min)
    if params.deadline_tightness <= 1.0:
        upper = min(params.completion_duration_max, max(lower, int(math.floor(deadline * params.deadline_tightness))))
    else:
        upper = max(lower, int(math.ceil(deadline * params.deadline_tightness)))
    return timing_rng.randint(lower, max(lower, upper))


def generate_trace(params: Params, seed: int) -> Trace:
    arrival_rng = rng_stream(seed, "task_arrival")
    assignment_rng = rng_stream(seed, "assignment")
    cost_rng = rng_stream(seed, "cost")
    criticality_rng = rng_stream(seed, "criticality")
    timing_rng = rng_stream(seed, "duration_deadline")
    crash_rng = rng_stream(seed, "crash")
    adversarial_rng = rng_stream(seed, "adversarial")
    evidence_rng = rng_stream(seed, "evidence")
    proposals: dict[int, list[Proposal]] = {e: [] for e in range(params.epochs)}
    inflations: dict[int, list[InflationEvent]] = {e: [] for e in range(params.epochs)}
    crashes: dict[int, list[int]] = {e: [] for e in range(params.epochs)}
    handoffs: dict[int, list[HandoffEvent]] = {e: [] for e in range(params.epochs)}
    replays: dict[int, list[ReplayEvent]] = {e: [] for e in range(params.epochs)}
    lifecycle_attacks: dict[int, list[LifecycleAttackEvent]] = {e: [] for e in range(params.epochs)}
    partitions: dict[int, PartitionState] = {}

    ident = 0
    for epoch in range(params.epochs):
        for _ in range(proposal_count_for_epoch(params, arrival_rng)):
            carrier = assignment_rng.randrange(params.robots)
            support = None
            support_bound = 0.0
            if assignment_rng.random() < params.support_required_prob:
                choices = [r for r in range(params.robots) if r != carrier]
                support = assignment_rng.choice(choices)
                support_bound = cost_rng.uniform(params.support_bound_min, params.support_bound_max)

            adversarial, adversarial_kind = maybe_adversarial(adversarial_rng, params)
            immediate_cost = cost_rng.uniform(params.immediate_cost_min, params.immediate_cost_max)
            carrier_bound = cost_rng.uniform(params.carrier_bound_min, params.carrier_bound_max)
            deadline = timing_rng.randint(6, 14)
            duration = duration_before_deadline(timing_rng, params, deadline)
            true_factor = true_factor_from_bound_error(cost_rng, params.bound_error)
            true_support_factor = true_factor_from_bound_error(cost_rng, params.bound_error)
            original_carrier_bound = carrier_bound
            original_support_bound = support_bound
            requested_self_degradation = ""
            uses_remote_rights = False
            silent_cancel_requested = False

            if adversarial and adversarial_kind == "duplicate_participant":
                support = carrier
                support_bound = cost_rng.uniform(params.support_bound_min, params.support_bound_max)
            elif adversarial and adversarial_kind == "impossible_cost":
                immediate_cost *= params.adversarial_cost_multiplier
                carrier_bound *= params.adversarial_cost_multiplier
                support_bound *= params.adversarial_cost_multiplier
            elif adversarial and adversarial_kind == "underdeclared_bound":
                true_factor *= params.adversarial_cost_multiplier
                true_support_factor *= params.adversarial_cost_multiplier
            elif adversarial and adversarial_kind == "unauthorized_degradation":
                requested_self_degradation = SELF_STRANDED
            elif adversarial and adversarial_kind == "remote_right_overspend":
                uses_remote_rights = True
            elif adversarial and adversarial_kind == "silent_cancellation":
                silent_cancel_requested = True
            elif adversarial and adversarial_kind == "malicious_underreport":
                fraction = min(1.0, max(0.0, params.underreport_fraction))
                carrier_bound = original_carrier_bound * fraction
                support_bound = original_support_bound * fraction

            true_carrier_bound_base = original_carrier_bound if adversarial and adversarial_kind == "malicious_underreport" else carrier_bound
            true_support_bound_base = original_support_bound if adversarial and adversarial_kind == "malicious_underreport" else support_bound

            witness_order = list(range(params.robots))
            assignment_rng.shuffle(witness_order)
            evidence_missing = evidence_rng.random() < params.evidence_missing_prob
            evidence_valid = not evidence_missing and evidence_rng.random() >= params.evidence_invalid_prob
            evidence_delay = evidence_rng.randint(0, max(0, params.evidence_delay_max))
            proposals[epoch].append(
                Proposal(
                    ident=ident,
                    epoch=epoch,
                    carrier=carrier,
                    support=support,
                    criticality=weighted_criticality(criticality_rng),
                    immediate_cost=immediate_cost,
                    carrier_bound=carrier_bound,
                    support_bound=support_bound,
                    true_carrier_bound=true_carrier_bound_base * true_factor,
                    true_support_bound=true_support_bound_base * true_support_factor,
                    deadline=deadline,
                    duration=duration,
                    settlement_ratio=cost_rng.uniform(params.settlement_ratio_min, params.settlement_ratio_max),
                    witness_order=tuple(witness_order),
                    adversarial=adversarial,
                    adversarial_kind=adversarial_kind,
                    ground_truth_attack=adversarial_kind if adversarial else "",
                    requested_self_degradation=requested_self_degradation,
                    uses_remote_rights=uses_remote_rights,
                    silent_cancel_requested=silent_cancel_requested,
                    evidence_delay=evidence_delay,
                    evidence_valid=evidence_valid,
                    evidence_missing=evidence_missing,
                )
            )
            ident += 1

        inflation_epoch_rng = epoch_rng(seed, "inflation", epoch)
        inflation_gate = inflation_epoch_rng.random()
        inflation_pick = inflation_epoch_rng.random()
        inflation_multiplier = inflation_epoch_rng.uniform(params.inflation_multiplier_min, params.inflation_multiplier_max)
        if inflation_gate < params.inflation_prob:
            inflations[epoch].append(InflationEvent(epoch=epoch, pick=inflation_pick, multiplier=inflation_multiplier))

        handoff_epoch_rng = epoch_rng(seed, "handoff", epoch)
        handoff_gate = handoff_epoch_rng.random()
        handoff_pick = handoff_epoch_rng.random()
        handoff_role_pick = handoff_epoch_rng.random()
        order = list(range(params.robots))
        handoff_epoch_rng.shuffle(order)
        replacement_blocked_gate = handoff_epoch_rng.random()
        crash_during_gate = handoff_epoch_rng.random()
        old_crash_gate = handoff_epoch_rng.random()
        partition_after_certificate_gate = handoff_epoch_rng.random()
        if handoff_gate < params.handoff_prob:
            handoffs[epoch].append(
                HandoffEvent(
                    epoch=epoch,
                    pick=handoff_pick,
                    role_pick=handoff_role_pick,
                    target_order=tuple(order),
                    replacement_blocked=replacement_blocked_gate < params.handoff_replacement_scarcity,
                    crash_during=crash_during_gate < params.handoff_crash_prob,
                    old_crash_before=old_crash_gate < params.handoff_old_crash_prob,
                    partition_after_certificate=partition_after_certificate_gate < params.handoff_partition_after_certificate_prob,
                )
            )

        replay_epoch_rng = epoch_rng(seed, "replay", epoch)
        replay_gate = replay_epoch_rng.random()
        replay_pick = replay_epoch_rng.random()
        replay_stale_offset = replay_epoch_rng.randint(1, 3)
        if replay_gate < params.version_replay_prob:
            replays[epoch].append(ReplayEvent(epoch=epoch, pick=replay_pick, stale_offset=replay_stale_offset))

        lifecycle_epoch_rng = epoch_rng(seed, "lifecycle_attack", epoch)
        lifecycle_gate = lifecycle_epoch_rng.random()
        lifecycle_pick = lifecycle_epoch_rng.random()
        lifecycle_kind = params.lifecycle_attack_kind
        if lifecycle_kind == "mixed":
            lifecycle_kind = lifecycle_epoch_rng.choice(["silent_cancellation", "unauthorized_degradation"])
        if lifecycle_gate < params.lifecycle_attack_prob:
            lifecycle_attacks[epoch].append(LifecycleAttackEvent(epoch=epoch, kind=lifecycle_kind, pick=lifecycle_pick))

        for robot in range(params.robots):
            if crash_rng.random() < params.crash_prob:
                crashes[epoch].append(robot)

    active_until = -1
    active_state: Optional[PartitionState] = None
    for epoch in range(params.epochs):
        partition_epoch_rng = epoch_rng(seed, "partition", epoch)
        partition_gate = partition_epoch_rng.random()
        robot_ids = list(range(params.robots))
        partition_epoch_rng.shuffle(robot_ids)
        cut = partition_epoch_rng.randint(1, params.robots - 1)
        duration = partition_epoch_rng.randint(params.partition_duration_min, params.partition_duration_max)
        if active_state is not None and epoch < active_until:
            partitions[epoch] = active_state
            continue
        active_state = None
        if partition_gate < params.partition_start_prob:
            g1 = frozenset(robot_ids[:cut])
            g2 = frozenset(robot_ids[cut:])
            active_until = epoch + duration
            active_state = PartitionState((g1, g2), active_until)
            partitions[epoch] = active_state

    return Trace(proposals, inflations, crashes, partitions, handoffs, replays, lifecycle_attacks)


def make_robots(params: Params) -> list[Robot]:
    level = SELF_STRANDED if params.self_recovery_guarantee <= 1e-9 else SELF_RETURN
    return [Robot(params.initial_energy, params.self_recovery_guarantee, self_level=level) for _ in range(params.robots)]


def same_partition_group(partition: Optional[PartitionState], participants: Iterable[int]) -> bool:
    if partition is None:
        return True
    ps = list(dict.fromkeys(participants))
    return any(all(p in group for p in ps) for group in partition.groups)


def all_team_connected(partition: Optional[PartitionState]) -> bool:
    return partition is None


def active_participants(participants: Iterable[int], robots: list[Robot]) -> bool:
    return all(0 <= r < len(robots) and robots[r].active for r in participants)


def valid_visible_proposal(prop: Proposal, params: Params) -> bool:
    if not (0 <= prop.carrier < params.robots):
        return False
    if prop.support is not None and not (0 <= prop.support < params.robots):
        return False
    if prop.support is not None and prop.support == prop.carrier:
        return False
    public_amounts = (prop.immediate_cost, prop.carrier_bound, prop.support_bound, prop.settlement_ratio)
    if any(not math.isfinite(value) or value < 0 for value in public_amounts):
        return False
    if prop.deadline <= 0 or prop.duration <= 0:
        return False
    return True


def validate_simulator_ground_truth(prop: Proposal) -> bool:
    hidden_amounts = (prop.true_carrier_bound, prop.true_support_bound)
    return all(math.isfinite(value) and value >= 0 for value in hidden_amounts)


def valid_proposal(prop: Proposal, params: Params) -> bool:
    return valid_visible_proposal(prop, params) and validate_simulator_ground_truth(prop)


def claimed_requirement(prop: Proposal) -> dict[int, float]:
    req = {prop.carrier: prop.carrier_bound}
    if prop.support is not None:
        req[prop.support] = prop.support_bound
    return req


def true_requirement(prop: Proposal) -> dict[int, float]:
    req = {prop.carrier: prop.true_carrier_bound}
    if prop.support is not None:
        req[prop.support] = prop.true_support_bound
    return req


def minimum_thresholds(params: Params, prefix: str) -> dict[int, float]:
    return {
        0: getattr(params, f"{prefix}_low"),
        1: getattr(params, f"{prefix}_medium"),
        2: getattr(params, f"{prefix}_high"),
    }


def certified_minimum_requirement(prop: Proposal, params: Params) -> dict[int, float]:
    """Policy-visible minimum backing; never reads hidden true demand fields."""
    carrier_min = minimum_thresholds(params, "min_carrier").get(prop.criticality, params.min_carrier_low)
    support_min = minimum_thresholds(params, "min_support").get(prop.criticality, params.min_support_low)
    req = {prop.carrier: carrier_min}
    if prop.support is not None:
        req[prop.support] = support_min
    return req


def merge_requirement_max(base: dict[int, float], floor: dict[int, float]) -> dict[int, float]:
    merged = dict(base)
    for robot_id, amount in floor.items():
        merged[robot_id] = max(merged.get(robot_id, 0.0), amount)
    return merged


def enforced_requirement(policy: str, prop: Proposal, params: Params) -> dict[int, float]:
    req = claimed_requirement(prop)
    if caps(policy).has_certified_minimum_backing:
        req = merge_requirement_max(req, certified_minimum_requirement(prop, params))
    return req


def minimum_backing_gap(prop: Proposal, params: Params) -> float:
    claimed = claimed_requirement(prop)
    certified = certified_minimum_requirement(prop, params)
    return sum(max(0.0, amount - claimed.get(robot_id, 0.0)) for robot_id, amount in certified.items())


def lacks_certified_minimum_backing(commitment: Commitment) -> bool:
    for robot_id, minimum in commitment.certified_min_req.items():
        if commitment.reserved.get(robot_id, 0.0) + 1e-9 < minimum:
            return True
    return False


def record_minimum_backing_mint(policy: str, prop: Proposal, commitment: Commitment, result: PolicyResult, params: Params) -> None:
    if prop.adversarial_kind != "malicious_underreport":
        return
    gap = minimum_backing_gap(prop, params)
    underbacked = lacks_certified_minimum_backing(commitment)
    if underbacked and not commitment.minimum_backing_violation_recorded:
        result.minimum_backing_attack_success += 1
        result.infeasible_mint_events += 1
        commitment.minimum_backing_violation_recorded = True
        if caps(policy).has_certified_minimum_backing:
            raise AssertionError("COMMIT GUARD minted a malicious-underreport proposal below its certified minimum backing")
    if caps(policy).has_certified_minimum_backing and gap > 1e-9 and not underbacked:
        result.minimum_backing_enforced += 1
        result.minimum_backing_extra_reserved += gap


def can_cover(robots: list[Robot], req: dict[int, float], carrier: Optional[int] = None, immediate_cost: float = 0.0) -> bool:
    for robot_id, amount in req.items():
        extra = immediate_cost if carrier is not None and robot_id == carrier else 0.0
        if robot_id < 0 or robot_id >= len(robots) or not robots[robot_id].active:
            return False
        if robots[robot_id].free + 1e-9 < amount + extra:
            return False
    return True


def choose_witnesses(
    prop: Proposal, participants: Iterable[int], robots: list[Robot], params: Params,
    partition: Optional[PartitionState] = None,
) -> set[int]:
    if params.witness_count <= 0:
        return set()
    chosen: list[int] = []
    participant_set = set(participants)
    for robot_id in prop.witness_order:
        if robot_id in participant_set:
            continue
        if (0 <= robot_id < len(robots) and robots[robot_id].active
                and (params.witness_selection_mode == "legacy_active"
                     or same_partition_group(partition, (*participant_set, robot_id)))):
            chosen.append(robot_id)
        if len(chosen) >= params.witness_count:
            break
    return set(chosen)


def certificate_holders(commitment: Commitment) -> set[int]:
    return set(commitment.participants) | set(commitment.witnesses)


def _snapshot_map(value: dict[int, float]) -> dict[str, float]:
    return {str(k): float(v) for k, v in sorted(value.items())}


def _native_snapshot_map(value: object) -> dict[int, float]:
    return {int(k): float(v) for k, v in dict(value).items()}  # type: ignore[arg-type]


def commitment_state_snapshot(
    commitment: Commitment,
    target_state: Optional[dict[str, object]] = None,
) -> dict[str, object]:
    snapshot: dict[str, object] = {
        "ident": commitment.ident,
        "version": commitment.version,
        "carrier": commitment.carrier,
        "support": commitment.support,
        "status": commitment.status,
        "guarantee": commitment.guarantee,
        "claimed_req": _snapshot_map(commitment.claimed_req),
        "true_req": _snapshot_map(commitment.true_req),
        "certified_min_req": _snapshot_map(commitment.certified_min_req),
        "initial_claimed_req": _snapshot_map(commitment.initial_claimed_req),
        "reserved": _snapshot_map(commitment.reserved),
        "physical_live": commitment.physical_live,
        "protected_present": commitment.protected_present,
        "phase_contract_id": commitment.phase_contract_id,
        "physical_stage": commitment.physical_stage,
        "phase_evidence_hash": commitment.phase_evidence_hash,
        "assist_for": commitment.assist_for,
        "physical_object": commitment.physical_object,
        "responsibility_scope": commitment.responsibility_scope,
        "responsibility_units": commitment.responsibility_units,
    }
    for key, value in (target_state or {}).items():
        if key in {"claimed_req", "true_req", "certified_min_req", "initial_claimed_req", "reserved"}:
            snapshot[key] = _snapshot_map({int(k): float(v) for k, v in dict(value).items()})  # type: ignore[arg-type]
        else:
            snapshot[key] = value
    snapshot["version"] = commitment.version
    return snapshot


def apply_effective_snapshot(commitment: Commitment, snapshot: dict[str, object]) -> None:
    """Install only a persisted candidate as the effective logical state."""
    commitment.carrier = int(snapshot["carrier"])
    support = snapshot.get("support")
    commitment.support = None if support is None else int(support)
    commitment.status = str(snapshot["status"])
    commitment.guarantee = str(snapshot["guarantee"])
    commitment.claimed_req = _native_snapshot_map(snapshot["claimed_req"])
    commitment.true_req = _native_snapshot_map(snapshot["true_req"])
    commitment.certified_min_req = _native_snapshot_map(snapshot["certified_min_req"])
    commitment.initial_claimed_req = _native_snapshot_map(snapshot["initial_claimed_req"])
    effective = _native_snapshot_map(snapshot["reserved"])
    commitment.effective_reserved = dict(effective)
    commitment.reserved = dict(effective)
    commitment.physical_live = bool(snapshot.get("physical_live", commitment.physical_live))
    commitment.protected_present = bool(snapshot.get("protected_present", commitment.protected_present))
    commitment.phase_contract_id = str(snapshot.get("phase_contract_id", commitment.phase_contract_id))
    commitment.physical_stage = str(snapshot.get("physical_stage", commitment.physical_stage))
    commitment.phase_evidence_hash = str(snapshot.get("phase_evidence_hash", commitment.phase_evidence_hash))
    commitment.assist_for = snapshot.get("assist_for", commitment.assist_for)
    commitment.physical_object = str(snapshot.get("physical_object", commitment.physical_object))
    commitment.responsibility_scope = str(snapshot.get("responsibility_scope", commitment.responsibility_scope))
    commitment.responsibility_units = float(snapshot.get("responsibility_units", commitment.responsibility_units))


def snapshot_hash(snapshot: dict[str, object]) -> str:
    body = json.dumps(snapshot, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


def configure_certificate_persistence(policy: str, commitment: Commitment, params: Params) -> None:
    if not caps(policy).has_certificate_auth:
        commitment.certificate_fault_tolerance = 0
        commitment.certificate_persistence_threshold = 1
        return
    if caps(policy).has_witness_replication:
        commitment.certificate_fault_tolerance = (
            min(params.witness_count, len(commitment.witnesses))
            if params.diagnostic_legacy_threshold else params.witness_count
        )
    else:
        commitment.certificate_fault_tolerance = 0
    commitment.certificate_persistence_threshold = commitment.certificate_fault_tolerance + 1


def save_version_snapshot(
    commitment: Commitment,
    event: str = "snapshot",
    predecessor: Optional[int] = None,
    resource_changes: Optional[dict[int, float]] = None,
    authorization_reason: str = "",
    target_state: Optional[dict[str, object]] = None,
) -> dict[str, object]:
    predecessor_version = commitment.effective_version if predecessor is None else predecessor
    snapshot = commitment_state_snapshot(commitment, target_state)
    candidate = {
        "version": commitment.version,
        "predecessor": predecessor_version,
        "transition_type": event,
        "state": snapshot,
        "resource_changes": {
            str(robot_id): amount for robot_id, amount in sorted((resource_changes or {}).items())
        },
        "authorization_reason": authorization_reason,
        "responsibility_inheritance": {
            "physical_live": snapshot["physical_live"],
            "carrier": snapshot["carrier"],
            "support": snapshot["support"],
            "guarantee": snapshot["guarantee"],
            "phase_contract_id": snapshot["phase_contract_id"],
            "physical_stage": snapshot["physical_stage"],
            "phase_evidence_hash": snapshot["phase_evidence_hash"],
            "assist_for": snapshot["assist_for"],
            "physical_object": snapshot["physical_object"],
            "responsibility_scope": snapshot["responsibility_scope"],
            "responsibility_units": snapshot["responsibility_units"],
        },
    }
    commitment.certificate_candidates[commitment.version] = candidate
    commitment.certificate_candidate_hashes[commitment.version] = snapshot_hash(candidate)
    return candidate


def promote_certificate_candidate(commitment: Commitment, version: int, acknowledgements: set[int]) -> None:
    candidate = commitment.certificate_candidates[version]
    predecessor = int(candidate["predecessor"])
    snapshot = dict(candidate["state"])
    commitment.certificate_history[version] = snapshot
    commitment.version_state_hashes[version] = snapshot_hash(snapshot)
    commitment.certificate_metadata[version] = {
        key: value for key, value in candidate.items() if key != "state"
    }
    commitment.certificate_successors[predecessor] = version
    commitment.effective_version = version
    commitment.certificate_update_uncertain = False
    commitment.last_certificate_result = "committed"
    apply_effective_snapshot(commitment, snapshot)
    for holder in acknowledgements:
        commitment.certificate_versions[holder] = version


def publish_certificate(
    policy: str, commitment: Commitment, robots: list[Robot], result: PolicyResult,
    partition: Optional[PartitionState] = None,
) -> bool:
    candidate = commitment.certificate_candidates.get(commitment.version)
    if candidate is None:
        candidate = save_version_snapshot(commitment)
    expected_candidate_hash = commitment.certificate_candidate_hashes.get(commitment.version)
    if expected_candidate_hash != snapshot_hash(candidate):
        commitment.certificate_update_uncertain = True
        commitment.last_certificate_result = "rejected"
        result.certificate_hash_violations += 1
        result.uncommitted_certificate_updates += 1
        return False
    if commitment.version == commitment.effective_version:
        return (
            commitment.version_state_hashes.get(commitment.effective_version)
            == snapshot_hash(dict(candidate["state"]))
        )
    predecessor = int(candidate["predecessor"])
    if policy == "central_commit_aware" and predecessor > 0 and not has_latest_certificate(commitment, robots):
        # A global controller cannot authorize a successor from an in-memory
        # certificate whose sole persisted view is no longer available.
        commitment.certificate_update_uncertain = True
        commitment.last_certificate_result = "uncertain"
        result.uncommitted_certificate_updates += 1
        result.certificate_confirmation_blocked += 1
        result.uncertain_commit_blocks += 1
        return False
    existing_successor = commitment.certificate_successors.get(predecessor)
    if existing_successor is not None and existing_successor != commitment.version:
        commitment.certificate_update_uncertain = True
        commitment.last_certificate_result = "rejected"
        result.conflicting_certificate_candidates += 1
        result.uncommitted_certificate_updates += 1
        return False

    if not caps(policy).has_certificate_auth:
        promote_certificate_candidate(commitment, commitment.version, set())
        result.logical_transition_committed += 1
        return True

    candidate_state = dict(candidate["state"])
    candidate_participants = {int(candidate_state["carrier"])}
    if candidate_state.get("support") is not None:
        candidate_participants.add(int(candidate_state["support"]))
    old_state = commitment.certificate_history.get(predecessor, {})
    old_participants: set[int] = set()
    if old_state:
        old_participants.add(int(old_state["carrier"]))
        if old_state.get("support") is not None:
            old_participants.add(int(old_state["support"]))
    transition = str(candidate.get("transition_type", ""))
    if (
        transition == "discharge"
        and commitment.simulation_epoch < commitment.certificate_not_before_epoch
    ):
        commitment.certificate_acknowledgements[commitment.version] = set()
        commitment.certificate_persisted_versions[commitment.version] = set()
        commitment.certificate_update_uncertain = True
        commitment.last_certificate_result = "uncertain"
        result.certificate_candidates_created += 1
        result.uncommitted_certificate_updates += 1
        result.certificate_confirmation_blocked += 1
        result.uncertain_commit_blocks += 1
        result.insufficient_persistence_rejections += 1
        return False
    # Releasing or moving old rights requires the old resource owners' ACKs.
    old_required = old_participants if transition in {"policy_degradation", "discharge"} else set()
    if transition == "handoff":
        old_required = old_participants if commitment.handoff_requires_old_guard else {
            holder for holder in old_participants if 0 <= holder < len(robots) and robots[holder].active
        }
    required = candidate_participants | old_required
    holders = required | set(commitment.witnesses)
    active_partition = partition if partition is not None else commitment.network_partition
    origin = commitment.initiator
    if not (0 <= origin < len(robots) and robots[origin].active):
        origin = next((h for h in sorted(old_participants | set(commitment.witnesses))
                       if 0 <= h < len(robots) and robots[h].active
                       and commitment.certificate_versions.get(h) == predecessor), -1)
    reachable = {
        holder for holder in holders
        if 0 <= holder < len(robots) and robots[holder].active
        and origin >= 0 and same_partition_group(active_partition, (origin, holder))
        and holder not in commitment.certificate_message_drops
    }
    # A signed Retire ACK for this exact immutable candidate remains valid when
    # its owner subsequently crashes. Persistence still requires live reachable
    # holders, so a stale ACK cannot manufacture a quorum.
    prior_acks = (
        commitment.certificate_acknowledgements.get(commitment.version, set())
        if transition == "discharge" and commitment.retire_recovery_enabled else set()
    )
    acknowledgements = reachable | prior_acks
    persisted = reachable if required.issubset(acknowledgements) else set()
    commitment.certificate_acknowledgements[commitment.version] = set(acknowledgements)
    commitment.certificate_persisted_versions[commitment.version] = set(persisted)
    result.certificate_message_ops += len(holders)
    result.witness_copies_created += len(persisted)
    result.certificate_candidates_created += 1
    participants_confirmed = required.issubset(acknowledgements)
    persistence_confirmed = len(persisted) >= commitment.certificate_persistence_threshold
    if not participants_confirmed or not persistence_confirmed:
        commitment.certificate_update_uncertain = True
        commitment.last_certificate_result = "uncertain"
        result.uncommitted_certificate_updates += 1
        result.certificate_confirmation_blocked += 1
        result.uncertain_commit_blocks += 1
        if not persistence_confirmed:
            result.insufficient_persistence_rejections += 1
            if active_partition is not None and any(
                0 <= holder < len(robots) and robots[holder].active
                and origin >= 0 and not same_partition_group(active_partition, (origin, holder))
                for holder in holders
            ):
                result.witness_unreachable_rejections += 1
        return False

    promote_certificate_candidate(commitment, commitment.version, persisted)
    result.certificate_candidates_committed += 1
    result.logical_transition_committed += 1
    return True


def has_latest_certificate(commitment: Commitment, robots: list[Robot]) -> bool:
    effective = commitment.effective_version
    if effective <= 0 or effective not in commitment.certificate_history:
        return False
    snapshot = commitment.certificate_history[effective]
    if commitment.version_state_hashes.get(effective) != snapshot_hash(snapshot):
        return False
    if effective not in commitment.certificate_metadata:
        return False
    persisted = commitment.certificate_persisted_versions.get(effective, set())
    return any(
        commitment.certificate_versions.get(holder) == effective
        and 0 <= holder < len(robots) and robots[holder].active
        for holder in persisted
    )


def record_version(
    policy: str,
    commitment: Commitment,
    result: PolicyResult,
    robots: list[Robot],
    event: str,
    resource_changes: Optional[dict[int, float]] = None,
    authorization_reason: str = "",
    target_state: Optional[dict[str, object]] = None,
    partition: Optional[PartitionState] = None,
) -> bool:
    if not caps(policy).has_commitment_ledger:
        return True
    pending_operation_before = commitment.pending_operation
    pending_version_before = commitment.pending_version
    old_candidate = commitment.version
    predecessor = commitment.effective_version
    commitment.version = max(commitment.version, commitment.effective_version) + 1
    if commitment.version <= old_candidate:
        result.version_violations += 1
        result.invariant_violations += 1
    save_version_snapshot(
        commitment,
        event=event,
        predecessor=predecessor,
        resource_changes=resource_changes,
        authorization_reason=authorization_reason,
        target_state=target_state,
    )
    committed = publish_certificate(policy, commitment, robots, result, partition)
    if committed and pending_version_before is not None:
        matching_prepare = {
            "mint": "mint:prepare",
            "top_up": "top_up:prepare",
            "handoff": "handoff:prepare",
        }.get(event)
        superseded_prepare = (
            pending_operation_before.endswith(":prepare")
            and pending_operation_before != matching_prepare
            and pending_version_before != commitment.effective_version
            and not commitment.pending_consumed_backing
        )
        if superseded_prepare:
            # A different successor of the old effective certificate has now
            # committed.  The losing prepare never crossed the physical commit
            # point and can no longer become effective, so its provisional lock
            # is safe to roll back.  Uncertain consumed backing is deliberately
            # excluded because it may already encode physical consequences.
            rollback_pending_reservation(commitment, robots, result)
    return committed


def record_invariant_violation(policy: str, result: PolicyResult, field_name: str, message: str) -> None:
    setattr(result, field_name, getattr(result, field_name) + 1)
    result.invariant_violations += 1
    if strict_invariant_enforced(policy):
        raise AssertionError(f"COMMIT GUARD invariant violation: {field_name}: {message}")


def remember_version(policy: str, commitment: Commitment, result: PolicyResult) -> None:
    observed_version = commitment.effective_version if caps(policy).has_certificate_auth else commitment.version
    previous = result.max_version_seen.get(commitment.ident, 0)
    if observed_version < previous:
        record_invariant_violation(policy, result, "version_violations", f"commitment {commitment.ident} regressed from {previous} to {observed_version}")
    else:
        result.max_version_seen[commitment.ident] = observed_version


def mark_missed(result: PolicyResult, field_name: str) -> None:
    setattr(result, field_name, getattr(result, field_name) + 1)
    result.missed += 1


def mark_blocked(result: PolicyResult) -> None:
    result.blocked += 1


def expected_physical_lock(commitment: Commitment, robot_id: int) -> float:
    return max(
        0.0,
        commitment.reserved.get(robot_id, 0.0)
        + commitment.pending_reserved.get(robot_id, 0.0)
        - commitment.pending_consumed_backing.get(robot_id, 0.0),
    )


def sync_robot_lock(commitment: Commitment, robots: list[Robot], robot_id: int) -> None:
    if not (0 <= robot_id < len(robots)):
        return
    amount = expected_physical_lock(commitment, robot_id)
    if amount > 1e-9:
        robots[robot_id].reserved[commitment.ident] = amount
    else:
        robots[robot_id].reserved.pop(commitment.ident, None)


def sync_all_robot_locks(commitment: Commitment, robots: list[Robot]) -> None:
    robot_ids = set(commitment.reserved) | set(commitment.pending_reserved) | set(commitment.pending_consumed_backing)
    robot_ids.update(i for i, robot in enumerate(robots) if commitment.ident in robot.reserved)
    for robot_id in robot_ids:
        sync_robot_lock(commitment, robots, robot_id)


def reserve_amounts(commitment: Commitment, robots: list[Robot]) -> None:
    sync_all_robot_locks(commitment, robots)


def stage_pending_reservation(
    commitment: Commitment,
    robots: list[Robot],
    target_reserved: dict[int, float],
    operation: str,
) -> None:
    """Lock additions without changing the effective logical allocation."""
    for robot_id in set(commitment.reserved) | set(target_reserved):
        extra = max(0.0, target_reserved.get(robot_id, 0.0) - commitment.reserved.get(robot_id, 0.0))
        if extra > 1e-9:
            commitment.pending_reserved[robot_id] = extra
        elif commitment.pending_operation == operation:
            commitment.pending_reserved.pop(robot_id, None)
    commitment.pending_operation = operation
    commitment.pending_version = commitment.version + 1
    sync_all_robot_locks(commitment, robots)


def rollback_pending_reservation(commitment: Commitment, robots: list[Robot], result: PolicyResult) -> None:
    if commitment.pending_reserved or commitment.pending_consumed_backing:
        result.pending_reservation_rollbacks += 1
    commitment.pending_reserved.clear()
    commitment.pending_consumed_backing.clear()
    commitment.pending_operation = ""
    commitment.pending_version = None
    sync_all_robot_locks(commitment, robots)


def reconcile_committed_reservation(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    physical_before_commit: dict[int, float],
    operation: str,
) -> None:
    """Convert additions to effective rights and retain removals as conservative locks."""
    commitment.pending_reserved.clear()
    commitment.pending_consumed_backing.clear()
    for robot_id in set(physical_before_commit) | set(commitment.reserved):
        surplus = max(0.0, physical_before_commit.get(robot_id, 0.0) - commitment.reserved.get(robot_id, 0.0))
        if surplus > 1e-9:
            commitment.pending_reserved[robot_id] = surplus
    commitment.pending_operation = f"{operation}:post_commit_release" if commitment.pending_reserved else ""
    commitment.pending_version = commitment.effective_version if commitment.pending_reserved else None
    result.pending_reservation_promotions += 1
    sync_all_robot_locks(commitment, robots)


def release_pending_locks(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    reason: str,
) -> dict[int, float]:
    expected_transition = {
        "authorized_degradation": "policy_degradation",
        "handoff_replaced": "handoff",
    }.get(reason)
    metadata = commitment.certificate_metadata.get(commitment.effective_version, {})
    expected_operation = (
        f"{expected_transition}:post_commit_release" if expected_transition is not None else ""
    )
    if reason == "handoff_replaced" and commitment.handoff_requires_old_guard:
        old_owners = {
            int(robot_id) for robot_id, delta in dict(metadata.get("resource_changes", {})).items()
            if float(delta) < -1e-9
        }
        if not old_owners.issubset(
            commitment.certificate_acknowledgements.get(commitment.effective_version, set())
        ):
            result.release_after_commit_failures += 1
            return {}
    if (
        expected_transition is None
        or metadata.get("transition_type") != expected_transition
        or commitment.pending_version != commitment.effective_version
        or commitment.pending_operation != expected_operation
    ):
        if metadata.get("transition_type") == expected_transition:
            result.release_after_commit_failures += 1
        return {}
    released = dict(commitment.pending_reserved)
    for amount in released.values():
        result.reserved_backing_released_unused += max(0.0, amount)
    commitment.pending_reserved.clear()
    commitment.pending_operation = ""
    commitment.pending_version = None
    sync_all_robot_locks(commitment, robots)
    active_release = sum(
        amount for robot_id, amount in released.items()
        if 0 <= robot_id < len(robots) and robots[robot_id].active
    )
    unavailable = sum(released.values()) - active_release
    if active_release > 1e-9:
        result.old_resource_release_executed += 1
    result.retained_unavailable_resources += max(0.0, unavailable)
    return released


def physical_reservation_map(commitment: Commitment) -> dict[int, float]:
    robot_ids = set(commitment.reserved) | set(commitment.pending_reserved) | set(commitment.pending_consumed_backing)
    return {robot_id: expected_physical_lock(commitment, robot_id) for robot_id in robot_ids if expected_physical_lock(commitment, robot_id) > 1e-9}


def record_reservation_release_accounting(
    commitment: Commitment,
    result: PolicyResult,
    used_by_commitment: Optional[dict[int, float]] = None,
    count_discharge_waste: bool = False,
) -> None:
    if not commitment.reserved:
        return
    consumed = 0.0
    released_unused = 0.0
    used = used_by_commitment or {}
    for robot_id, reserved_amount in commitment.reserved.items():
        used_amount = min(max(0.0, used.get(robot_id, 0.0)), max(0.0, reserved_amount))
        consumed += used_amount
        released_unused += max(0.0, reserved_amount - used_amount)
    result.reserved_backing_consumed += consumed
    result.reserved_backing_released_unused += released_unused
    if count_discharge_waste:
        result.wasted_reserve_at_discharge += released_unused


def consume_reserved_backing_pending_certificate(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    used_by_commitment: Optional[dict[int, float]],
) -> None:
    """Retire physically consumed backing without treating it as reusable capacity."""
    for robot_id, used_amount in (used_by_commitment or {}).items():
        current = max(0.0, commitment.reserved.get(robot_id, 0.0))
        already_consumed = max(0.0, commitment.pending_consumed_backing.get(robot_id, 0.0))
        consumed = min(max(0.0, current - already_consumed), max(0.0, used_amount))
        if consumed <= 1e-9:
            continue
        result.reserved_backing_consumed += consumed
        commitment.pending_consumed_backing[robot_id] = already_consumed + consumed
        commitment.pending_operation = "discharge:certificate_uncertain"
        commitment.pending_version = commitment.version
        sync_robot_lock(commitment, robots, robot_id)


def release_one_reservation(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    robot_id: int,
) -> float:
    amount = max(0.0, commitment.reserved.get(robot_id, 0.0))
    if amount > 1e-9:
        result.reserved_backing_released_unused += amount
    if 0 <= robot_id < len(robots):
        robots[robot_id].reserved.pop(commitment.ident, None)
    commitment.reserved.pop(robot_id, None)
    commitment.effective_reserved.pop(robot_id, None)
    commitment.pending_reserved.pop(robot_id, None)
    commitment.pending_consumed_backing.pop(robot_id, None)
    return amount


def release_remote_claims(commitment: Commitment, robots: list[Robot]) -> None:
    for robot_id in list(commitment.remote_claims):
        if 0 <= robot_id < len(robots):
            robots[robot_id].remote_reserved.pop(commitment.ident, None)
    commitment.remote_claims.clear()


def release_reservations(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    policy: str,
    reason: str,
    used_by_commitment: Optional[dict[int, float]] = None,
) -> bool:
    physical_reservations = physical_reservation_map(commitment)
    release_amount = sum(max(0.0, amount) for amount in physical_reservations.values())
    metadata = commitment.certificate_metadata.get(commitment.effective_version, {})
    transition_type = metadata.get("transition_type", "")
    authorized = False
    if reason == "precommit_abort":
        authorized = not commitment.physical_live and commitment.effective_version == 0
    elif reason == "discharge":
        authorized = (
            not commitment.physical_live
            and commitment.discharge_evidence_validated
            and (not caps(policy).has_certificate_auth or transition_type == "discharge")
        )
    elif reason == "terminal_policy_disposition":
        authorized = (
            not commitment.physical_live
            and commitment.terminal_disposition_authorized
            and (not caps(policy).has_certificate_auth or transition_type == "terminal_policy_disposition")
        )
    elif reason == "handoff_replaced":
        authorized = transition_type == "handoff" and commitment.effective_version > 0
    elif not lifecycle_protected(policy):
        authorized = reason in LEGAL_RELEASE_REASONS or reason in {
            "unsafe_cancel",
            "unsafe_failure",
            "deadline_failure",
            "trace_end_cleanup",
        }

    commitment.release_events.append(
        {
            "reason": reason,
            "authorized": authorized,
            "amount": release_amount,
            "effective_version": commitment.effective_version,
            "physical_live": commitment.physical_live,
            "evidence_validated": commitment.discharge_evidence_validated,
            "terminal_disposition_authorized": commitment.terminal_disposition_authorized,
            "executed": authorized or not lifecycle_protected(policy),
        }
    )
    if lifecycle_protected(policy) and not authorized:
        if commitment.status == STATUS_RUPTURED or commitment.physical_live:
            result.illegal_rupture_release_violations += 1
        return False
    consumed = 0.0
    released_unused = 0.0
    used = used_by_commitment or {}
    for robot_id, amount in physical_reservations.items():
        used_amount = min(max(0.0, used.get(robot_id, 0.0)), amount)
        consumed += used_amount
        released_unused += max(0.0, amount - used_amount)
    result.reserved_backing_consumed += consumed
    result.reserved_backing_released_unused += released_unused
    if reason == "discharge":
        result.wasted_reserve_at_discharge += released_unused
    active_release = sum(
        amount for robot_id, amount in physical_reservations.items()
        if 0 <= robot_id < len(robots) and robots[robot_id].active
    )
    unavailable = release_amount - active_release
    if active_release > 1e-9:
        result.old_resource_release_executed += 1
    result.retained_unavailable_resources += max(0.0, unavailable)
    for robot_id in set(commitment.reserved) | set(commitment.pending_reserved) | set(commitment.pending_consumed_backing):
        if 0 <= robot_id < len(robots):
            robots[robot_id].reserved.pop(commitment.ident, None)
    commitment.reserved.clear()
    commitment.effective_reserved.clear()
    commitment.pending_reserved.clear()
    commitment.pending_consumed_backing.clear()
    commitment.pending_operation = ""
    commitment.pending_version = None
    release_remote_claims(commitment, robots)
    return True


def self_snapshot(robots: list[Robot], robot_ids: Iterable[int]) -> dict[int, str]:
    return {r: robots[r].self_level for r in set(robot_ids) if 0 <= r < len(robots)}


def restore_self_snapshot(robots: list[Robot], snapshot: dict[int, str]) -> None:
    for robot_id, level in snapshot.items():
        robots[robot_id].self_level = level


def degrade_robot_one_step(robot_id: int, robots: list[Robot], result: PolicyResult) -> Optional[DegradationTransition]:
    robot = robots[robot_id]
    if not robot.active:
        return None
    next_level = ALLOWED_SELF_DEGRADATION.get(robot.self_level)
    if next_level is None:
        return None
    transition = DegradationTransition(robot=robot_id, before=robot.self_level, after=next_level)
    robot.self_level = next_level
    result.self_recovery_degradation_events += 1
    if transition.before == SELF_RETURN and transition.after == SELF_SAFE_HALT:
        result.return_to_safe_halt += 1
    elif transition.before == SELF_SAFE_HALT and transition.after == SELF_STRANDED:
        result.safe_halt_to_stranded += 1
    return transition


def degrade_self_to_cover(
    robots: list[Robot],
    req: dict[int, float],
    carrier: Optional[int],
    immediate_cost: float,
    criticality: int,
    allow: bool,
    result: PolicyResult,
) -> list[DegradationTransition]:
    if not allow or criticality < 1:
        return []
    planned: list[DegradationTransition] = []
    for robot_id, amount in req.items():
        if robot_id < 0 or robot_id >= len(robots) or not robots[robot_id].active:
            return []
        extra = immediate_cost if carrier is not None and robot_id == carrier else 0.0
        robot = robots[robot_id]
        level = robot.self_level
        projected_free = robot.energy - robot.self_base * SELF_FRACTION[level] - robot.total_reserved
        while projected_free + 1e-9 < amount + extra:
            next_level = ALLOWED_SELF_DEGRADATION.get(level)
            if next_level is None:
                return []
            planned.append(DegradationTransition(robot=robot_id, before=level, after=next_level))
            level = next_level
            projected_free = robot.energy - robot.self_base * SELF_FRACTION[level] - robot.total_reserved

    transitions: list[DegradationTransition] = []
    for planned_transition in planned:
        if robots[planned_transition.robot].self_level != planned_transition.before:
            return []
        transition = degrade_robot_one_step(planned_transition.robot, robots, result)
        if transition is None or transition.after != planned_transition.after:
            return []
        transitions.append(transition)
    return transitions


def static_reservation_from_initial(claimed_req: dict[int, float], params: Params) -> dict[int, float]:
    return {robot_id: amount * params.static_worst_case_multiplier for robot_id, amount in claimed_req.items()}


def spend_energy(robots: list[Robot], robot_id: int, amount: float, result: PolicyResult) -> None:
    robots[robot_id].energy -= amount
    result.energy_consumed += amount


def record_terminal(commitment: Commitment, result: PolicyResult, epoch: Optional[int] = None) -> None:
    result.terminal_commitments += 1
    terminal_epoch = commitment.due_epoch if epoch is None else epoch
    result.total_commitment_lifetime += max(0, terminal_epoch - commitment.created_epoch)


def create_commitment(
    policy: str,
    prop: Proposal,
    robots: list[Robot],
    result: PolicyResult,
    params: Params,
    partition: Optional[PartitionState] = None,
    phase_contract_id: str = "",
    assist_for: Optional[int] = None,
) -> Optional[Commitment]:
    initial_bound = claimed_requirement(prop)
    initial_true = true_requirement(prop)
    certified_min_req = certified_minimum_requirement(prop, params)
    enforced_req = enforced_requirement(policy, prop, params)
    reservation_req = static_reservation_from_initial(initial_bound, params) if caps(policy).uses_static_worst_case else dict(enforced_req)
    allow_degrade = caps(policy).has_policy_degradation and params.medium_high_degrade_self_recovery
    snapshot = self_snapshot(robots, reservation_req)
    before_self_degradation_events = result.self_recovery_degradation_events
    before_return_to_safe_halt = result.return_to_safe_halt
    before_safe_halt_to_stranded = result.safe_halt_to_stranded
    total_immediate = prop.immediate_cost + prop.precommit_preparation_cost
    transitions = degrade_self_to_cover(robots, reservation_req, prop.carrier, total_immediate, prop.criticality, allow_degrade, result)

    if not can_cover(robots, reservation_req, carrier=prop.carrier, immediate_cost=total_immediate):
        restore_self_snapshot(robots, snapshot)
        result.self_recovery_degradation_events = before_self_degradation_events
        result.return_to_safe_halt = before_return_to_safe_halt
        result.safe_halt_to_stranded = before_safe_halt_to_stranded
        return None

    transactional_mint = caps(policy).has_certificate_auth
    deferred_action = transactional_mint and params.mint_deferred_execution
    if prop.precommit_preparation_cost > 0:
        spend_energy(robots, prop.carrier, prop.precommit_preparation_cost, result)
        result.mint_precommit_execution_cost += prop.precommit_preparation_cost
    if not deferred_action:
        spend_energy(robots, prop.carrier, prop.immediate_cost, result)
    else:
        # This is a temporary physical lock, distinct from the candidate's
        # future-liability backing and from the effective certificate ledger.
        robots[prop.carrier].pending_execution_cost[prop.ident] = prop.immediate_cost
    commitment = Commitment(
        ident=prop.ident,
        proposal=prop,
        initiator=prop.carrier,
        carrier=prop.carrier,
        support=prop.support,
        criticality=prop.criticality,
        created_epoch=prop.epoch,
        due_epoch=prop.due_epoch,
        finish_epoch=prop.finish_epoch,
        claimed_req=dict(initial_bound),
        true_req=dict(initial_true),
        certified_min_req=dict(certified_min_req),
        initial_claimed_req=dict(initial_bound),
        reserved={} if transactional_mint else dict(reservation_req),
        effective_reserved={} if transactional_mint else dict(reservation_req),
        pending_reserved=dict(reservation_req) if transactional_mint else {},
        pending_operation="mint:prepare" if transactional_mint else "",
        status=STATUS_LIVE,
        guarantee="full",
        contract_guarantee_requirements={"full": dict(initial_bound)},
        network_partition=partition,
        phase_contract_id=phase_contract_id,
        assist_for=assist_for,
        retire_recovery_enabled=params.retire_recovery_enabled,
        simulation_epoch=prop.epoch,
        certificate_ack_delay_epochs=params.certificate_ack_delay_epochs,
        retire_recovery_wait_epochs=params.retire_recovery_wait_epochs,
    )
    reserve_amounts(commitment, robots)
    if caps(policy).has_witness_replication:
        commitment.witnesses = choose_witnesses(prop, commitment.participants, robots, params, partition)
    configure_certificate_persistence(policy, commitment, params)
    if caps(policy).has_commitment_ledger:
        save_version_snapshot(
            commitment,
            event="mint",
            predecessor=0,
            resource_changes=dict(reservation_req),
            authorization_reason="admission_check_passed",
            target_state={"reserved": dict(reservation_req)},
        )
    if not publish_certificate(policy, commitment, robots, result):
        robots[prop.carrier].pending_execution_cost.pop(prop.ident, None)
        commitment.physical_live = False
        release_reservations(commitment, robots, result, policy, "precommit_abort")
        if prop.precommit_preparation_cost > 0:
            result.mint_aborted_after_cost += 1
        if deferred_action:
            restore_self_snapshot(robots, snapshot)
            result.self_recovery_degradation_events = before_self_degradation_events
            result.return_to_safe_halt = before_return_to_safe_halt
            result.safe_halt_to_stranded = before_safe_halt_to_stranded
        return None
    if transactional_mint:
        physical_before_commit = dict(reservation_req)
        reconcile_committed_reservation(
            commitment, robots, result, physical_before_commit, "mint"
        )
    if deferred_action:
        robots[prop.carrier].pending_execution_cost.pop(prop.ident, None)
        if not prop.physical_execution_success:
            result.mint_execution_failures_after_certificate += 1
            commitment.physical_live = False
            transition_at_risk(commitment, robots, result, policy, "mint_execution_failed_after_certificate")
            return commitment
        spend_energy(robots, prop.carrier, prop.immediate_cost, result)
    record_minimum_backing_mint(policy, prop, commitment, result, params)
    if params.contract_degradation_enabled and caps(policy).has_policy_degradation:
        target_requirement = {
            commitment.carrier: params.contract_degraded_carrier_requirement,
        }
        if commitment.support is not None:
            target_requirement[commitment.support] = params.contract_degraded_support_requirement
        if all(
            0.0 <= target_requirement[robot_id] <= commitment.claimed_req.get(robot_id, -1.0) + 1e-9
            for robot_id in target_requirement
        ):
            configure_contract_degradation(
                commitment,
                "full",
                "reduced_settlement",
                target_requirement,
            )
    return commitment


def lower_priority_live(live: list[Commitment], criticality: int) -> list[Commitment]:
    return sorted(
        [c for c in live if c.status in ACTIVE_STATUSES and c.criticality < criticality],
        key=lambda c: (c.criticality, -c.due_epoch, c.ident),
    )


def cancel_one_lower_priority(
    live: list[Commitment],
    robots: list[Robot],
    criticality: int,
    result: PolicyResult,
    policy: str,
) -> bool:
    candidates = lower_priority_live(live, criticality)
    if not candidates:
        return False
    old = candidates[0]
    old.status = STATUS_RUPTURED
    release_reservations(old, robots, result, policy, "unsafe_cancel")
    live.remove(old)
    result.silent_unbacking += 1
    mark_missed(result, "failed")
    return True


def declared_need_exceeds_single_robot_capacity(prop: Proposal, params: Params) -> bool:
    declared = prop.immediate_cost + max(prop.carrier_bound, prop.support_bound)
    return declared > params.initial_energy - params.self_recovery_guarantee + 1e-9


def partition_group_for_robot(partition: Optional[PartitionState], robot_id: int) -> Optional[frozenset[int]]:
    if partition is None:
        return None
    for group in partition.groups:
        if robot_id in group:
            return group
    return None


def remote_overspend_victim(
    prop: Proposal,
    partition: Optional[PartitionState],
    robots: list[Robot],
    live: list[Commitment],
) -> Optional[int]:
    if not (prop.adversarial and prop.adversarial_kind == "remote_right_overspend" and prop.uses_remote_rights):
        return None
    if partition is None or not (0 <= prop.carrier < len(robots)) or not robots[prop.carrier].active:
        return None
    requester_group = partition_group_for_robot(partition, prop.carrier)
    if requester_group is None:
        return None
    participant_set = set(prop.participants)
    live_reserved_ids_by_robot: dict[int, set[int]] = {}
    for commitment in live:
        if not commitment.protected_present or commitment.status not in {STATUS_LIVE, STATUS_DEGRADED}:
            continue
        for robot_id, amount in commitment.reserved.items():
            if amount > 1e-9:
                live_reserved_ids_by_robot.setdefault(robot_id, set()).add(commitment.ident)

    remote_candidates = sorted(
        robot_id
        for group in partition.groups
        if group != requester_group
        for robot_id in group
        if 0 <= robot_id < len(robots)
        and robots[robot_id].active
        and robot_id not in participant_set
        and robots[robot_id].reserved
        and any(commitment_id in live_reserved_ids_by_robot.get(robot_id, set()) for commitment_id in robots[robot_id].reserved)
    )
    return remote_candidates[0] if remote_candidates else None


def remote_overspend_amount(prop: Proposal, victim: int, robots: list[Robot]) -> float:
    existing_reserved = sum(robots[victim].reserved.values())
    requested_remote_amount = max(prop.carrier_bound, prop.support_bound, 1.0)
    if existing_reserved <= 1e-9:
        return 0.0
    return min(existing_reserved, max(1.0, requested_remote_amount))


def apply_remote_overspend_attack(
    policy: str,
    prop: Proposal,
    commitment: Commitment,
    victim: Optional[int],
    robots: list[Robot],
    result: PolicyResult,
) -> None:
    if victim is None:
        return
    amount = remote_overspend_amount(prop, victim, robots)
    if amount <= 1e-9 or policy == "immediate_only":
        return
    result.remote_overspend_accepted += 1
    commitment.remote_claims[victim] = commitment.remote_claims.get(victim, 0.0) + amount
    robots[victim].remote_reserved[commitment.ident] = robots[victim].remote_reserved.get(commitment.ident, 0.0) + amount


def visible_planner_error(policy: str, prop: Proposal, params: Params, partition: Optional[PartitionState]) -> bool:
    if not valid_visible_proposal(prop, params):
        return True
    if prop.requested_self_degradation:
        return True
    if prop.silent_cancel_requested:
        return True
    if prop.uses_remote_rights and partition is not None and caps(policy).has_local_resource_ownership:
        return True
    if declared_need_exceeds_single_robot_capacity(prop, params):
        return True
    return False


def admit(
    policy: str,
    prop: Proposal,
    partition: Optional[PartitionState],
    robots: list[Robot],
    live: list[Commitment],
    result: PolicyResult,
    params: Params,
) -> None:
    result.proposals += 1

    visible_error = visible_planner_error(policy, prop, params, partition)
    remote_victim = remote_overspend_victim(prop, partition, robots, live)
    if prop.adversarial:
        result.adversarial_proposals += 1
        result.attack_attempts += 1
        if visible_error:
            result.immediately_detectable_attacks += 1
        if prop.adversarial_kind == "unauthorized_degradation":
            result.illegal_degradation_attempts += 1
        elif prop.adversarial_kind == "remote_right_overspend":
            if remote_victim is not None:
                result.remote_overspend_attempts += 1
        elif prop.adversarial_kind == "silent_cancellation":
            result.silent_cancellation_attempts += 1
        elif prop.adversarial_kind == "underdeclared_bound":
            result.underdeclared_attempts += 1
        elif prop.adversarial_kind == "malicious_underreport":
            result.minimum_backing_attack_attempts += 1

    if visible_error:
        result.planner_error_proposals += 1
        if caps(policy).rejects_visible_planner_errors:
            result.planner_errors_rejected += 1
            if prop.adversarial:
                result.adversarial_rejected += 1
                result.detection_count += 1
                if prop.adversarial_kind == "unauthorized_degradation":
                    result.illegal_degradation_rejected += 1
                elif prop.adversarial_kind == "remote_right_overspend":
                    if remote_victim is not None:
                        result.remote_overspend_rejected += 1
                elif prop.adversarial_kind == "silent_cancellation":
                    result.silent_cancellation_rejected += 1
            else:
                result.false_rejection_benign += 1
            mark_missed(result, "rejected")
            return

    if not valid_visible_proposal(prop, params) and prop.support is not None and not (0 <= prop.support < params.robots):
        mark_missed(result, "rejected")
        return

    if not valid_visible_proposal(prop, params) and not (0 <= prop.carrier < params.robots):
        mark_missed(result, "rejected")
        return

    if not validate_simulator_ground_truth(prop):
        mark_missed(result, "rejected")
        return

    if prop.adversarial:
        result.adversarial_accepted += 1
        if prop.adversarial_kind == "unauthorized_degradation":
            result.illegal_degradation_accepted += 1
        elif prop.adversarial_kind == "remote_right_overspend":
            pass
        elif prop.adversarial_kind == "silent_cancellation":
            result.silent_cancellation_accepted += 1

    if prop.silent_cancel_requested:
        result.attack_success += 1
        result.adversarial_physical_violation += 1
        result.silent_unbacking += 1
        result.commitment_loss += 1
        mark_missed(result, "failed")
        return

    if not active_participants(prop.participants, robots):
        mark_missed(result, "pre_start_failed")
        return

    if caps(policy).requires_global_view and not all_team_connected(partition):
        if prop.adversarial and prop.adversarial_kind == "remote_right_overspend" and remote_victim is not None:
            result.remote_overspend_blocked += 1
        mark_blocked(result)
        return

    if caps(policy).has_local_resource_ownership and not same_partition_group(partition, prop.participants):
        if prop.adversarial and prop.adversarial_kind == "remote_right_overspend" and remote_victim is not None:
            result.remote_overspend_blocked += 1
        mark_blocked(result)
        return

    if policy == "immediate_only":
        carrier = robots[prop.carrier]
        if carrier.active and carrier.free + 1e-9 >= prop.immediate_cost:
            spend_energy(robots, prop.carrier, prop.immediate_cost, result)
            commitment = Commitment(
                ident=prop.ident,
                proposal=prop,
                initiator=prop.carrier,
                carrier=prop.carrier,
                support=prop.support,
                criticality=prop.criticality,
                created_epoch=prop.epoch,
                due_epoch=prop.due_epoch,
                finish_epoch=prop.finish_epoch,
                claimed_req=claimed_requirement(prop),
                true_req=true_requirement(prop),
                certified_min_req=certified_minimum_requirement(prop, params),
                initial_claimed_req=claimed_requirement(prop),
                reserved={},
                contract_guarantee_requirements={"full": claimed_requirement(prop)},
            )
            configure_certificate_persistence(policy, commitment, params)
            save_version_snapshot(commitment, event="mint", predecessor=0, authorization_reason="immediate_execution")
            publish_certificate(policy, commitment, robots, result)
            record_minimum_backing_mint(policy, prop, commitment, result, params)
            live.append(commitment)
            result.admitted += 1
            if prop.adversarial:
                result.adversarial_admitted += 1
                result.admitted_attacks += 1
                if prop.adversarial_kind == "underdeclared_bound":
                    result.underdeclared_admitted += 1
            apply_remote_overspend_attack(policy, prop, commitment, remote_victim, robots, result)
            result.silent_unbacking += 1
        else:
            mark_missed(result, "rejected")
        return

    commitment = create_commitment(policy, prop, robots, result, params, partition)
    if commitment is None and policy == "priority_cancel":
        while commitment is None and cancel_one_lower_priority(live, robots, prop.criticality, result, policy):
            commitment = create_commitment(policy, prop, robots, result, params)

    if commitment is None:
        if policy == "commit_guard":
            attempted = enforced_requirement(policy, prop, params)
            pending_by_robot = {
                robot_id: sum(
                    max(0.0, c.pending_reserved.get(robot_id, 0.0))
                    for c in live if c.protected_present
                ) + sum(robots[robot_id].pending_execution_cost.values())
                for robot_id in attempted
            }
            if any(amount > 1e-9 for amount in pending_by_robot.values()) and all(
                0 <= robot_id < len(robots) and robots[robot_id].active
                and robots[robot_id].free + pending_by_robot[robot_id] + 1e-9
                >= amount + (prop.immediate_cost if robot_id == prop.carrier else 0.0)
                for robot_id, amount in attempted.items()
            ):
                result.blocked_by_pending_resources += 1
        if prop.adversarial_kind == "malicious_underreport" and caps(policy).has_certified_minimum_backing and minimum_backing_gap(prop, params) > 1e-9:
            result.minimum_backing_rejected += 1
        mark_missed(result, "rejected")
        return

    live.append(commitment)
    result.admitted += 1
    if prop.adversarial:
        result.adversarial_admitted += 1
        result.admitted_attacks += 1
        if prop.adversarial_kind == "underdeclared_bound":
            result.underdeclared_admitted += 1
    apply_remote_overspend_attack(policy, prop, commitment, remote_victim, robots, result)
    check_invariants(policy, robots, live, result, "admit")


def transition_at_risk(commitment: Commitment, robots: list[Robot], result: PolicyResult, policy: str, reason: str) -> None:
    if commitment.status == STATUS_AT_RISK:
        return
    if not caps(policy).has_at_risk_state:
        commitment.status = STATUS_RUPTURED
        commitment.at_risk_reason = f"no_at_risk_state:{reason}"
        result.ruptures += 1
        result.commitment_loss += 1
        result.silent_unbacking += 1
        record_rupture_residual(commitment, result, robots)
        release_reservations(commitment, robots, result, policy, "terminal_policy_disposition")
        commitment.physical_live = True
        record_terminal(commitment, result)
        return
    commitment.status = STATUS_AT_RISK
    commitment.at_risk_reason = reason
    commitment.at_risk_backing_snapshot = dict(commitment.reserved)
    result.at_risk += 1
    commitment.lifecycle_events.append(
        {"transition": "at_risk", "reason": reason, "from_guarantee": commitment.guarantee}
    )
    record_version(policy, commitment, result, robots, "at_risk", authorization_reason=reason)


def record_rupture_residual(commitment: Commitment, result: PolicyResult, robots: Optional[list[Robot]] = None) -> None:
    if not commitment.physical_live or commitment.rupture_residual_recorded:
        return
    residual = sum(max(0.0, amount) for amount in commitment.true_req.values())
    lost_capacity = 0.0
    locked_backing = 0.0
    if robots is not None:
        for robot_id, amount in commitment.reserved.items():
            if 0 <= robot_id < len(robots) and robots[robot_id].active:
                locked_backing += max(0.0, amount)
            else:
                already_recorded = commitment.lost_physical_backing.get(robot_id, 0.0)
                lost_capacity += max(0.0, amount - already_recorded)
                commitment.lost_physical_backing[robot_id] = max(already_recorded, max(0.0, amount))
    result.residual_after_rupture += 1
    result.ruptured_physical_liability += residual
    result.lost_physical_capacity += lost_capacity
    result.ruptured_locked_backing += locked_backing
    commitment.rupture_residual_recorded = True


def transition_rupture(commitment: Commitment, robots: list[Robot], result: PolicyResult, policy: str, reason: str) -> None:
    if commitment.status == STATUS_RUPTURED:
        return
    commitment.status = STATUS_RUPTURED
    commitment.at_risk_reason = reason
    result.ruptures += 1
    commitment.physical_live = True
    commitment.rupture_backing_snapshot = dict(commitment.reserved)
    commitment.lifecycle_events.append(
        {"transition": "rupture", "reason": reason, "residual_retained": True}
    )
    record_version(policy, commitment, result, robots, "rupture", authorization_reason=reason)
    record_rupture_residual(commitment, result, robots)
    record_terminal(commitment, result)


def transition_discharge(
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    policy: str,
    used_by_commitment: Optional[dict[int, float]] = None,
    epoch: Optional[int] = None,
) -> bool:
    previous_status = commitment.status
    if epoch is not None:
        commitment.simulation_epoch = epoch
        commitment.certificate_not_before_epoch = max(
            commitment.certificate_not_before_epoch,
            epoch + commitment.certificate_ack_delay_epochs,
        )
    commitment.discharge_evidence_validated = True
    old_reserved = dict(commitment.reserved)
    physical_before_commit = {
        robot_id: robots[robot_id].reserved.get(commitment.ident, 0.0)
        for robot_id in range(len(robots))
        if commitment.ident in robots[robot_id].reserved
    }
    resource_changes = {
        robot_id: -amount for robot_id, amount in commitment.reserved.items()
    }
    committed = record_version(
        policy,
        commitment,
        result,
        robots,
        "discharge",
        resource_changes=resource_changes,
        authorization_reason="validated_physical_discharge_evidence",
        target_state={
            "status": STATUS_DISCHARGED,
            "physical_live": False,
            "reserved": {},
        },
    )
    if not committed:
        commitment.status = STATUS_AT_RISK if caps(policy).has_at_risk_state else previous_status
        commitment.physical_live = False
        commitment.at_risk_reason = "discharge_certificate_unconfirmed"
        if commitment.retire_pending_since is None:
            commitment.retire_pending_since = epoch
            result.retire_pending += 1
        consume_reserved_backing_pending_certificate(
            commitment, robots, result, used_by_commitment
        )
        commitment.at_risk_backing_snapshot = dict(commitment.reserved)
        result.at_risk += 1
        return False
    reconcile_committed_reservation(
        commitment, robots, result, physical_before_commit, "discharge"
    )
    result.discharges += 1
    if not commitment.retire_committed_recorded:
        commitment.retire_committed_recorded = True
        if caps(policy).has_certificate_auth:
            result.retire_certificate_committed += 1
    commitment.lifecycle_events.append(
        {"transition": "discharge", "reason": "validated_physical_discharge_evidence"}
    )
    if not release_reservations(commitment, robots, result, policy, "discharge", used_by_commitment=used_by_commitment):
        return False
    record_terminal(commitment, result)
    return True


def recover_pending_retire(
    policy: str, commitment: Commitment, partition: Optional[PartitionState],
    robots: list[Robot], result: PolicyResult, epoch: int,
) -> bool:
    """Retry an already evidenced Retire without replaying the physical action."""
    if not (commitment.retire_recovery_enabled and commitment.physical_execution_completed
            and commitment.discharge_evidence_validated
            and commitment.at_risk_reason == "discharge_certificate_unconfirmed"
            and not commitment.retire_committed_recorded):
        return False
    if (
        commitment.retire_pending_since is not None
        and epoch < commitment.retire_pending_since + commitment.retire_recovery_wait_epochs
    ):
        return False
    commitment.simulation_epoch = epoch
    physical_before_commit = physical_reservation_map(commitment)
    predecessor = commitment.effective_version
    candidate_versions = sorted(
        version for version, candidate in commitment.certificate_candidates.items()
        if candidate.get("transition_type") == "discharge"
        and int(candidate.get("predecessor", -1)) == predecessor
        and commitment.certificate_candidate_hashes.get(version) == snapshot_hash(candidate)
    )
    if candidate_versions:
        commitment.version = candidate_versions[-1]
        committed = publish_certificate(policy, commitment, robots, result, partition)
    elif predecessor not in commitment.certificate_successors:
        committed = record_version(
            policy, commitment, result, robots, "discharge",
            resource_changes={robot_id: -amount for robot_id, amount in commitment.reserved.items()},
            authorization_reason="retry_validated_physical_discharge_evidence",
            target_state={"status": STATUS_DISCHARGED, "physical_live": False, "reserved": {}},
            partition=partition,
        )
    else:
        return False
    if not committed:
        return False
    # The already-spent portion was accounted when the first Retire failed.
    # Only the remaining physical lock is now released as unused backing.
    reconcile_committed_reservation(commitment, robots, result, physical_before_commit, "discharge")
    if not release_reservations(commitment, robots, result, policy, "discharge"):
        return False
    commitment.retire_committed_recorded = True
    result.retire_certificate_committed += 1
    result.retire_recovered += 1
    result.discharges += 1
    result.at_risk_resolved += 1
    if not commitment.rescued_recorded:
        commitment.rescued_recorded = True
        result.rescued += 1
        if commitment.proposal.adversarial:
            result.adversarial_success += 1
    commitment.lifecycle_events.append({
        "transition": "retire_recovered", "epoch": epoch,
        "physical_completion_epoch": commitment.physical_completion_epoch,
        "certificate_version": commitment.effective_version,
    })
    record_terminal(commitment, result, epoch)
    return True


def apply_inflation(
    policy: str,
    commitment: Commitment,
    live: list[Commitment],
    robots: list[Robot],
    partition: Optional[PartitionState],
    result: PolicyResult,
    multiplier: float,
    params: Params,
) -> None:
    for robot_id in list(commitment.claimed_req):
        commitment.claimed_req[robot_id] *= multiplier
    for robot_id in list(commitment.true_req):
        commitment.true_req[robot_id] *= multiplier

    if policy == "immediate_only":
        return

    if policy == "static_worst_case":
        if not is_backed_by_reserved(commitment, robots, use_true=False):
            transition_at_risk(commitment, robots, result, policy, "static_envelope_exceeded")
        return

    attempt_top_up(policy, commitment, live, robots, partition, result, params, reason="inflation")


def is_backed_by_reserved(commitment: Commitment, robots: list[Robot], use_true: bool) -> bool:
    req = commitment.true_req if use_true else commitment.claimed_req
    for robot_id, amount in req.items():
        if robot_id < 0 or robot_id >= len(robots) or not robots[robot_id].active:
            return False
        if commitment.reserved.get(robot_id, 0.0) + 1e-9 < amount:
            return False
    return True


def reserve_delta_to_bound(
    policy: str,
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    params: Params,
) -> bool:
    transactional = caps(policy).has_certificate_auth
    current_physical = {
        robot_id: expected_physical_lock(commitment, robot_id)
        for robot_id in set(commitment.reserved) | set(commitment.pending_reserved) | set(commitment.claimed_req)
    }
    deltas = {
        robot_id: max(0.0, amount - current_physical.get(robot_id, 0.0))
        for robot_id, amount in commitment.claimed_req.items()
    }
    snapshot = self_snapshot(robots, deltas)
    before_self_degradations = result.self_recovery_degradation_events
    before_return_to_safe_halt = result.return_to_safe_halt
    before_safe_halt_to_stranded = result.safe_halt_to_stranded
    allow_degrade = caps(policy).has_policy_degradation and params.medium_high_degrade_self_recovery
    transitions = degrade_self_to_cover(robots, deltas, None, 0.0, commitment.criticality, allow_degrade, result)
    if not all(robots[r].active and robots[r].free + 1e-9 >= delta for r, delta in deltas.items()):
        restore_self_snapshot(robots, snapshot)
        result.self_recovery_degradation_events = before_self_degradations
        result.return_to_safe_halt = before_return_to_safe_halt
        result.safe_halt_to_stranded = before_safe_halt_to_stranded
        return False
    target_reserved = dict(commitment.reserved)
    for robot_id, amount in commitment.claimed_req.items():
        target_reserved[robot_id] = max(target_reserved.get(robot_id, 0.0), amount)
    if transactional:
        stage_pending_reservation(commitment, robots, target_reserved, "top_up:prepare")
    else:
        commitment.reserved = target_reserved
        commitment.effective_reserved = dict(target_reserved)
        reserve_amounts(commitment, robots)
    return True


def configure_contract_degradation(
    commitment: Commitment,
    source_guarantee: str,
    target_guarantee: str,
    target_requirement: dict[int, float],
) -> None:
    """Install an author-provided contract edge; the simulator never invents its cost."""
    commitment.contract_guarantee_requirements[target_guarantee] = dict(target_requirement)
    commitment.authorized_degradation_edges.add((source_guarantee, target_guarantee))


def attempt_policy_degradation(
    policy: str,
    commitment: Commitment,
    robots: list[Robot],
    result: PolicyResult,
    target_guarantee: str = "reduced_settlement",
    reason: str = "top_up_insufficient",
) -> bool:
    result.contract_degradation_attempts += 1
    if not caps(policy).has_policy_degradation:
        return False
    if caps(policy).has_certificate_auth and (
        commitment.pending_reserved
        or commitment.pending_consumed_backing
        or commitment.pending_operation
    ):
        result.degradation_policy_state_rejections += 1
        return False
    if commitment.status not in ACTIVE_STATUSES or commitment.criticality >= 2:
        result.degradation_policy_state_rejections += 1
        return False
    transition_edge = (commitment.guarantee, target_guarantee)
    if transition_edge not in commitment.authorized_degradation_edges:
        result.unauthorized_degradation_rejections += 1
        return False
    target_requirement = commitment.contract_guarantee_requirements.get(target_guarantee)
    if target_requirement is None:
        result.unauthorized_degradation_rejections += 1
        return False
    if set(target_requirement) != set(commitment.claimed_req):
        result.illegal_degradation_violations += 1
        return False
    if any(amount < -1e-9 for amount in target_requirement.values()):
        result.illegal_degradation_violations += 1
        return False
    if any(
        target_requirement[robot_id] > commitment.claimed_req.get(robot_id, 0.0) + 1e-9
        for robot_id in target_requirement
    ):
        result.illegal_degradation_violations += 1
        return False
    if any(
        commitment.reserved.get(robot_id, 0.0) + 1e-9 < amount
        for robot_id, amount in target_requirement.items()
    ):
        result.degradation_support_failures += 1
        return False

    previous_guarantee = commitment.guarantee
    before_reserved = dict(commitment.reserved)
    physical_before_commit = {
        robot_id: robots[robot_id].reserved.get(commitment.ident, 0.0)
        for robot_id in range(len(robots))
        if commitment.ident in robots[robot_id].reserved
    }
    resource_changes = {
        robot_id: target_requirement[robot_id] - commitment.reserved.get(robot_id, 0.0)
        for robot_id in target_requirement
    }
    target_state = {
        "claimed_req": dict(target_requirement),
        "true_req": dict(target_requirement),
        "reserved": dict(target_requirement),
        "status": STATUS_DEGRADED,
        "guarantee": target_guarantee,
    }
    if not record_version(
        policy,
        commitment,
        result,
        robots,
        "policy_degradation",
        resource_changes=resource_changes,
        authorization_reason=reason,
        target_state=target_state,
    ):
        result.contract_degradation_certificate_failures += 1
        return False

    commitment.at_risk_reason = ""
    reconcile_committed_reservation(
        commitment, robots, result, physical_before_commit, "policy_degradation"
    )
    released = release_pending_locks(
        commitment, robots, result, "authorized_degradation"
    )
    commitment.release_events.append(
        {
            "reason": "authorized_degradation",
            "authorized": True,
            "amount": sum(released.values()),
            "effective_version": commitment.effective_version,
            "physical_live": commitment.physical_live,
            "transition_edge": [previous_guarantee, target_guarantee],
            "executed": True,
        }
    )
    commitment.lifecycle_events.append(
        {
            "transition": "degrade",
            "from_guarantee": previous_guarantee,
            "to_guarantee": target_guarantee,
            "reason": reason,
            "resource_released": {str(k): v for k, v in sorted(released.items())},
            "certificate_version": commitment.effective_version,
        }
    )
    result.degradation_events += 1
    return True


def attempt_top_up(
    policy: str,
    commitment: Commitment,
    live: list[Commitment],
    robots: list[Robot],
    partition: Optional[PartitionState],
    result: PolicyResult,
    params: Params,
    reason: str,
) -> bool:
    if caps(policy).has_certificate_auth and (
        commitment.pending_consumed_backing
        or (
            commitment.pending_operation
            and commitment.pending_operation != "top_up:prepare"
        )
    ):
        result.top_up_failed += 1
        if commitment.status != STATUS_AT_RISK:
            transition_at_risk(
                commitment, robots, result, policy, f"{reason}_pending_transaction"
            )
        return False
    if caps(policy).requires_global_view and not all_team_connected(partition):
        result.top_up_failed += 1
        transition_at_risk(commitment, robots, result, policy, f"{reason}_needs_global_view")
        return False
    if caps(policy).has_local_resource_ownership and not same_partition_group(partition, commitment.participants):
        result.top_up_failed += 1
        transition_at_risk(commitment, robots, result, policy, f"{reason}_participants_partitioned")
        return False
    if not active_participants(commitment.participants, robots):
        result.top_up_failed += 1
        transition_at_risk(commitment, robots, result, policy, f"{reason}_participant_unavailable")
        return False

    before_reserved = dict(commitment.reserved)
    previous_status = commitment.status
    if reserve_delta_to_bound(policy, commitment, robots, result, params):
        target_reserved = dict(commitment.reserved)
        for robot_id, amount in commitment.claimed_req.items():
            target_reserved[robot_id] = max(target_reserved.get(robot_id, 0.0), amount)
        target_status = commitment.status
        if target_status == STATUS_AT_RISK:
            target_status = STATUS_DEGRADED if commitment.guarantee != "full" else STATUS_LIVE
        resource_changes = {
            robot_id: target_reserved.get(robot_id, 0.0) - before_reserved.get(robot_id, 0.0)
            for robot_id in set(target_reserved) | set(before_reserved)
        }
        physical_before_commit = {
            robot_id: robots[robot_id].reserved.get(commitment.ident, 0.0)
            for robot_id in range(len(robots))
            if commitment.ident in robots[robot_id].reserved
        }
        if not record_version(
            policy,
            commitment,
            result,
            robots,
            "top_up",
            resource_changes=resource_changes,
            authorization_reason=reason,
            target_state={"reserved": target_reserved, "status": target_status},
        ):
            commitment.at_risk_reason = f"{reason}_certificate_unconfirmed"
            if commitment.last_certificate_result == "rejected":
                rollback_pending_reservation(commitment, robots, result)
            else:
                result.pending_reservation_uncertain += 1
                if caps(policy).has_at_risk_state and commitment.status != STATUS_AT_RISK:
                    commitment.status = STATUS_AT_RISK
                    commitment.at_risk_backing_snapshot = dict(commitment.reserved)
                    result.at_risk += 1
            result.top_up_failed += 1
            return False
        reconcile_committed_reservation(
            commitment, robots, result, physical_before_commit, "top_up"
        )
        commitment.at_risk_reason = ""
        result.top_up_success += 1
        if previous_status == STATUS_AT_RISK:
            result.at_risk_resolved += 1
        return True

    if policy == "priority_cancel":
        while not is_backed_by_reserved(commitment, robots, use_true=False):
            if not cancel_one_lower_priority(live, robots, commitment.criticality, result, policy):
                break
        if reserve_delta_to_bound(policy, commitment, robots, result, params):
            result.top_up_success += 1
            return True
        result.silent_unbacking += 1
        result.top_up_failed += 1
        return False

    was_at_risk_before_degradation = commitment.status == STATUS_AT_RISK
    if attempt_policy_degradation(policy, commitment, robots, result, reason=reason):
        result.top_up_success += 1
        if was_at_risk_before_degradation:
            result.at_risk_resolved += 1
        return True

    result.top_up_failed += 1
    transition_at_risk(commitment, robots, result, policy, f"{reason}_insufficient_local_rights")
    return False


def choose_live_by_pick(live: list[Commitment], pick: float, include_at_risk: bool = False) -> Optional[Commitment]:
    statuses = ACTIVE_STATUSES if include_at_risk else {STATUS_LIVE, STATUS_DEGRADED}
    candidates = [c for c in live if c.protected_present and c.status in statuses]
    if not candidates:
        return None
    index = min(len(candidates) - 1, int(pick * len(candidates)))
    return candidates[index]


def lifecycle_protected(policy: str) -> bool:
    return policy in PROTECTED_POLICIES


def record_lifecycle_integrity_loss(
    commitment: Commitment,
    policy: str,
    live: list[Commitment],
    robots: list[Robot],
    result: PolicyResult,
    epoch: int,
    release_backing: bool,
    reason: str,
) -> None:
    released = sum(commitment.reserved.values())
    if release_backing and released > 1e-9:
        release_reservations(commitment, robots, result, policy, reason)
        result.forgotten_and_resources_reused += 1
        result.silent_unbacking += 1
        result.release_violations += 1
        result.invariant_violations += 1
    commitment.protected_present = False
    commitment.status = STATUS_FORGOTTEN
    result.commitment_loss += 1
    result.attack_success += 1
    result.adversarial_physical_violation += 1
    if commitment.physical_live:
        result.physical_commitments_still_live += 1
        result.orphaned_liability += sum(commitment.true_req.values())
    if commitment in live:
        live.remove(commitment)
    record_terminal(commitment, result, epoch)


def apply_lifecycle_attack(
    policy: str,
    event: LifecycleAttackEvent,
    live: list[Commitment],
    robots: list[Robot],
    result: PolicyResult,
) -> None:
    commitment = choose_live_by_pick(live, event.pick, include_at_risk=False)
    if commitment is None or not commitment.physical_live:
        return

    result.lifecycle_attack_attempts += 1
    if event.kind == "silent_cancellation":
        result.silent_cancellation_attempts += 1
        if lifecycle_protected(policy):
            result.silent_cancellation_rejected += 1
            result.detection_count += 1
            return
        result.silent_cancellation_accepted += 1
        result.silent_cancellation_success += 1
        record_lifecycle_integrity_loss(
            commitment,
            policy,
            live,
            robots,
            result,
            event.epoch,
            release_backing=(policy != "immediate_only"),
            reason="unsafe_lifecycle_cancel",
        )
        return

    if event.kind == "unauthorized_degradation":
        result.illegal_degradation_attempts += 1
        if lifecycle_protected(policy):
            result.illegal_degradation_rejected += 1
            result.detection_count += 1
            return
        result.illegal_degradation_accepted += 1
        result.illegal_degradation_success += 1
        result.illegal_degradation_violations += 1
        for robot_id in commitment.participants:
            if 0 <= robot_id < len(robots) and robots[robot_id].active:
                robots[robot_id].self_level = SELF_STRANDED
        commitment.guarantee = "illegal_abandonment"
        record_lifecycle_integrity_loss(
            commitment,
            policy,
            live,
            robots,
            result,
            event.epoch,
            release_backing=(policy != "immediate_only"),
            reason="unsafe_lifecycle_degradation",
        )


def restore_snapshot_without_changing_physical_truth(commitment: Commitment, robots: list[Robot], snapshot: dict[str, object]) -> None:
    for robot in robots:
        robot.reserved.pop(commitment.ident, None)
        robot.remote_reserved.pop(commitment.ident, None)

    old_true = dict(commitment.true_req)
    commitment.carrier = int(snapshot["carrier"])
    support = snapshot["support"]
    commitment.support = None if support is None else int(support)
    commitment.status = str(snapshot["status"])
    commitment.guarantee = str(snapshot["guarantee"])
    commitment.claimed_req = {int(k): float(v) for k, v in dict(snapshot["claimed_req"]).items()}
    commitment.initial_claimed_req = {int(k): float(v) for k, v in dict(snapshot["initial_claimed_req"]).items()}
    commitment.reserved = {int(k): float(v) for k, v in dict(snapshot["reserved"]).items()}
    commitment.effective_reserved = dict(commitment.reserved)
    commitment.pending_reserved.clear()
    commitment.pending_consumed_backing.clear()
    commitment.pending_operation = ""
    commitment.pending_version = None
    commitment.remote_claims.clear()
    commitment.true_req = old_true
    commitment.protected_present = bool(snapshot.get("protected_present", True))

    for robot_id, amount in commitment.reserved.items():
        if 0 <= robot_id < len(robots) and robots[robot_id].active:
            robots[robot_id].reserved[commitment.ident] = amount


def handoff_role(commitment: Commitment, role_pick: float) -> str:
    if commitment.support is not None and role_pick < 0.5:
        return "support"
    return "carrier"


def replacement_target(event: HandoffEvent, commitment: Commitment, robots: list[Robot]) -> Optional[int]:
    current = set(commitment.participants)
    for robot_id in event.target_order:
        if robot_id not in current and 0 <= robot_id < len(robots) and robots[robot_id].active:
            return robot_id
    return None


def move_participant_maps(commitment: Commitment, old_robot: int, new_robot: int, new_reserved_amount: float) -> bool:
    if old_robot not in commitment.claimed_req or old_robot not in commitment.true_req:
        return False
    bound = commitment.claimed_req.pop(old_robot)
    true = commitment.true_req.pop(old_robot)
    certified_minimum = commitment.certified_min_req.pop(old_robot, 0.0)
    initial = commitment.initial_claimed_req.pop(old_robot, bound)
    commitment.reserved.pop(old_robot, None)
    commitment.claimed_req[new_robot] = bound
    commitment.true_req[new_robot] = true
    commitment.certified_min_req[new_robot] = certified_minimum
    commitment.initial_claimed_req[new_robot] = initial
    commitment.reserved[new_robot] = new_reserved_amount
    commitment.effective_reserved = dict(commitment.reserved)
    for requirement in commitment.contract_guarantee_requirements.values():
        if old_robot in requirement:
            requirement[new_robot] = requirement.pop(old_robot)
    if old_robot == commitment.carrier:
        commitment.carrier = new_robot
    elif old_robot == commitment.support:
        commitment.support = new_robot
    return True


def reserve_replacement_target(
    policy: str,
    commitment: Commitment,
    old_robot: int,
    new_robot: int,
    robots: list[Robot],
    result: PolicyResult,
    params: Params,
) -> Optional[tuple[float, bool]]:
    amount = max(commitment.reserved.get(old_robot, 0.0), commitment.claimed_req.get(old_robot, 0.0))
    already_locked = robots[new_robot].reserved.get(commitment.ident, 0.0)
    req = {new_robot: max(0.0, amount - already_locked)}
    snapshot = self_snapshot(robots, [new_robot])
    before_self_degradations = result.self_recovery_degradation_events
    before_return_to_safe_halt = result.return_to_safe_halt
    before_safe_halt_to_stranded = result.safe_halt_to_stranded
    allow_degrade = caps(policy).has_policy_degradation and params.medium_high_degrade_self_recovery
    transitions = degrade_self_to_cover(robots, req, None, 0.0, commitment.criticality, allow_degrade, result)
    if not can_cover(robots, req):
        restore_self_snapshot(robots, snapshot)
        result.self_recovery_degradation_events = before_self_degradations
        result.return_to_safe_halt = before_return_to_safe_halt
        result.safe_halt_to_stranded = before_safe_halt_to_stranded
        return None
    if caps(policy).has_certificate_auth:
        commitment.pending_reserved[new_robot] = amount
        commitment.pending_operation = "handoff:prepare"
        commitment.pending_version = commitment.version + 1
        sync_robot_lock(commitment, robots, new_robot)
    else:
        robots[new_robot].reserved[commitment.ident] = amount
    return amount, bool(transitions)


def handoff_target_state(
    commitment: Commitment,
    old_robot: int,
    new_robot: int,
    replacement_amount: float,
    status: str,
) -> dict[str, object]:
    def moved(values: dict[int, float], default: float = 0.0) -> dict[int, float]:
        target = dict(values)
        amount = target.pop(old_robot, default)
        target[new_robot] = amount
        return target

    carrier = new_robot if commitment.carrier == old_robot else commitment.carrier
    support = new_robot if commitment.support == old_robot else commitment.support
    reserved = dict(commitment.reserved)
    reserved.pop(old_robot, None)
    reserved[new_robot] = replacement_amount
    return {
        "carrier": carrier,
        "support": support,
        "status": status,
        "claimed_req": moved(commitment.claimed_req),
        "true_req": moved(commitment.true_req),
        "certified_min_req": moved(commitment.certified_min_req),
        "initial_claimed_req": moved(commitment.initial_claimed_req),
        "reserved": reserved,
    }


def attempt_handoff(
    policy: str,
    commitment: Commitment,
    event: HandoffEvent,
    partition: Optional[PartitionState],
    robots: list[Robot],
    result: PolicyResult,
    params: Params,
    live: list[Commitment],
    phase_contract: Optional[TwoStageContract] = None,
    phase_evidence: Optional[HandoffEvidence] = None,
) -> bool:
    commitment.network_partition = partition
    result.handoff_attempts += 1
    if phase_contract is not None:
        if (
            phase_evidence is None
            or not phase_evidence.trusted or not phase_evidence.valid
            or not phase_evidence.physically_observed
            or phase_evidence.residual_id != commitment.ident
            or phase_evidence.contract_id != phase_contract.contract_id
            or phase_evidence.kind not in {"safe_wait", "physical_takeover"}
            or (phase_evidence.kind == "safe_wait" and not phase_contract.safe_wait_authorized)
            or (phase_evidence.kind == "physical_takeover" and not phase_contract.physical_takeover_authorized)
            or commitment.phase_contract_id != phase_contract.contract_id
            or abs(commitment.claimed_req.get(commitment.carrier, 0.0) - phase_contract.original_requirement) > 1e-9
        ):
            result.handoff_blocked += 1
            return False
        commitment.handoff_requires_old_guard = True
    if caps(policy).has_certificate_auth and (
        commitment.pending_consumed_backing
        or (
            commitment.pending_operation
            and commitment.pending_operation != "handoff:prepare"
        )
    ):
        # Serialize protected lifecycle updates.  In particular, a Retire with
        # physical consequences but an uncertain certificate cannot be
        # overwritten by a new Handoff prepare or cleared by that prepare's
        # rollback path.
        result.handoff_blocked += 1
        return False
    target = replacement_target(event, commitment, robots)
    if target is None:
        result.handoff_failed += 1
        return False
    if event.replacement_blocked:
        result.handoff_blocked += 1
        return False
    role = handoff_role(commitment, event.role_pick)
    old_robot = commitment.support if role == "support" else commitment.carrier
    if phase_contract is not None and old_robot != commitment.carrier:
        result.handoff_blocked += 1
        return False
    if old_robot is None:
        result.handoff_failed += 1
        return False
    if old_robot not in commitment.claimed_req or old_robot not in commitment.true_req:
        result.handoff_failed += 1
        record_invariant_violation(policy, result, "backing_violations", f"handoff source {old_robot} missing requirement map for commitment {commitment.ident}")
        transition_at_risk(commitment, robots, result, policy, "handoff_missing_source_requirement")
        return False
    if event.old_crash_before:
        result.handoff_old_crash_before += 1
        result.handoff_failed += 1
        handle_crash(policy, old_robot, robots, live, result)
        return False

    if caps(policy).requires_global_view and not all_team_connected(partition):
        result.handoff_blocked += 1
        return False
    if caps(policy).has_local_resource_ownership and not same_partition_group(partition, list(commitment.participants) + [target]):
        result.handoff_blocked += 1
        return False

    if policy == "immediate_only":
        if not move_participant_maps(commitment, old_robot, target, 0.0):
            result.handoff_failed += 1
            record_invariant_violation(policy, result, "backing_violations", f"handoff source {old_robot} missing during immediate handoff")
            return False
        result.handoff_success += 1
        return True

    if policy == "priority_cancel" or not caps(policy).has_replacement_before_release:
        if old_robot in commitment.reserved:
            release_one_reservation(commitment, robots, result, old_robot)
        amount = commitment.claimed_req.get(old_robot, 0.0)
        if event.crash_during:
            result.handoff_crash_during += 1
            result.replacement_before_release_violations += 1
            result.unbacked_window_count += 1
            result.silent_unbacking += 1
            transition_at_risk(commitment, robots, result, policy, "handoff_target_crashed_after_old_release")
            handle_crash(policy, target, robots, live, result)
            return False
        if not can_cover(robots, {target: amount}):
            result.replacement_before_release_violations += 1
            result.unbacked_window_count += 1
            result.silent_unbacking += 1
            transition_at_risk(commitment, robots, result, policy, "handoff_released_before_replacement")
            return False
        robots[target].reserved[commitment.ident] = amount
        if not move_participant_maps(commitment, old_robot, target, amount):
            robots[target].reserved.pop(commitment.ident, None)
            result.handoff_failed += 1
            record_invariant_violation(policy, result, "backing_violations", f"handoff source {old_robot} missing after unsafe replacement reserve")
            transition_at_risk(commitment, robots, result, policy, "handoff_missing_source_after_release")
            return False
        result.handoff_success += 1
        return True

    was_at_risk = commitment.status == STATUS_AT_RISK
    previous_at_risk_reason = commitment.at_risk_reason
    replacement = reserve_replacement_target(policy, commitment, old_robot, target, robots, result, params)
    if replacement is None:
        result.handoff_failed += 1
        return False
    replacement_amount, degraded_self = replacement
    if phase_contract is not None and replacement_amount + 1e-9 < phase_contract.successor_requirement:
        if caps(policy).has_certificate_auth:
            rollback_pending_reservation(commitment, robots, result)
        else:
            robots[target].reserved.pop(commitment.ident, None)
        result.handoff_blocked += 1
        return False

    if event.crash_during:
        if caps(policy).has_certificate_auth:
            rollback_pending_reservation(commitment, robots, result)
        else:
            robots[target].reserved.pop(commitment.ident, None)
        result.handoff_crash_during += 1
        result.handoff_failed += 1
        handle_crash(policy, target, robots, live, result)
        return False

    old_reserved_released_unused = max(0.0, commitment.reserved.get(old_robot, 0.0))
    # A replacement repairs only the selected participant.  An AT-RISK
    # commitment may still be under-backed at another participant, so do not
    # clear the risk overlay merely because this one handoff can commit.
    target_status = commitment.status
    target_state = handoff_target_state(
        commitment, old_robot, target, replacement_amount, target_status
    )
    if phase_contract is not None and phase_evidence is not None:
        target_state["physical_stage"] = "transport" if phase_evidence.kind == "safe_wait" else "takeover"
        target_state["phase_contract_id"] = phase_contract.contract_id
        target_state["phase_evidence_hash"] = snapshot_hash(asdict(phase_evidence))
    if was_at_risk:
        target_claimed = _native_snapshot_map(target_state["claimed_req"])
        target_reserved = _native_snapshot_map(target_state["reserved"])
        target_participants = {int(target_state["carrier"])}
        if target_state.get("support") is not None:
            target_participants.add(int(target_state["support"]))
        replacement_fully_restores_backing = all(
            0 <= robot_id < len(robots)
            and robots[robot_id].active
            and target_reserved.get(robot_id, 0.0) + 1e-9 >= amount
            for robot_id, amount in target_claimed.items()
        ) and target_participants.issubset(set(target_claimed))
        if replacement_fully_restores_backing:
            target_state["status"] = STATUS_LIVE
    physical_before_commit = {
        robot_id: robots[robot_id].reserved.get(commitment.ident, 0.0)
        for robot_id in range(len(robots))
        if commitment.ident in robots[robot_id].reserved
    }
    resource_changes = {
        old_robot: -old_reserved_released_unused,
        target: replacement_amount,
    }
    certificate_committed = record_version(
        policy,
        commitment,
        result,
        robots,
        "handoff",
        resource_changes=resource_changes,
        authorization_reason=(
            "trusted_stage_evidence_and_successor_backing"
            if phase_contract is not None else "replacement_backing_confirmed_before_release"
        ),
        target_state=target_state,
        partition=partition,
    )
    if not certificate_committed:
        commitment.at_risk_reason = "handoff_certificate_unconfirmed"
        if commitment.last_certificate_result == "rejected":
            rollback_pending_reservation(commitment, robots, result)
        else:
            result.pending_reservation_uncertain += 1
        result.handoff_failed += 1
        return False
    for requirement in commitment.contract_guarantee_requirements.values():
        if old_robot in requirement:
            requirement[target] = requirement.pop(old_robot)
    reconcile_committed_reservation(
        commitment, robots, result, physical_before_commit, "handoff"
    )
    backed_after_handoff = is_backed_by_reserved(commitment, robots, use_true=False)
    if backed_after_handoff:
        commitment.at_risk_reason = ""
    elif was_at_risk:
        commitment.at_risk_reason = previous_at_risk_reason or "handoff_partial_recovery"
    if event.partition_after_certificate:
        result.handoff_partition_after_certificate += 1
        # The link fails after the effective version has been persisted.  The
        # old owner can act on its local ACK; a missing ACK still retains locks.
        old_group = frozenset({old_robot})
        other_group = frozenset(set(range(len(robots))) - {old_robot})
        commitment.network_partition = PartitionState((old_group, other_group), event.epoch + 1)
    if event.old_crash_after_certificate:
        robots[old_robot].active = False
        robots[old_robot].energy = 0.0
    released = release_pending_locks(commitment, robots, result, "handoff_replaced")
    local_release_executed = 0 <= old_robot < len(robots) and robots[old_robot].active
    if commitment.status == STATUS_AT_RISK:
        # The committed handoff lawfully moves the retained liability from the
        # old participant to its replacement.  Refresh the risk snapshot to
        # the certified post-handoff allocation so the detector protects the
        # replacement backing rather than treating the authorized old release
        # as silent reuse.
        commitment.at_risk_backing_snapshot = dict(commitment.reserved)
    commitment.release_events.append(
        {
            "reason": "handoff_replaced",
            "authorized": True,
            "amount": sum(released.values()),
            "effective_version": commitment.effective_version,
            "physical_live": commitment.physical_live,
            "replacement_robot": target,
            "released_robot": old_robot,
            "executed": local_release_executed,
            "logical_ledger_cleanup": True,
            "retained_unavailable": not local_release_executed,
        }
    )
    commitment.lifecycle_events.append(
        {
            "transition": "handoff",
            "from_participant": old_robot,
            "to_participant": target,
            "certificate_version": commitment.effective_version,
        }
    )
    if was_at_risk and backed_after_handoff:
        result.at_risk_resolved += 1
    result.handoff_success += 1
    check_invariants(policy, robots, live, result, "handoff")
    return True


def attempt_assist(
    old: Commitment, new_robot: int, new_ident: int, contract: TwoStageContract,
    partition: Optional[PartitionState], robots: list[Robot], result: PolicyResult,
    params: Params,
) -> Optional[Commitment]:
    """Mint B's independent obligation; A's certificate and rights are untouched."""
    if new_robot in old.participants or new_ident == old.ident or contract.contract_id != old.phase_contract_id:
        return None
    if new_robot < 0 or new_robot >= len(robots) or not robots[new_robot].active:
        return None
    proposal = replace(
        old.proposal, ident=new_ident, carrier=new_robot, support=None,
        immediate_cost=0.0, carrier_bound=contract.successor_requirement,
        support_bound=0.0, true_carrier_bound=contract.successor_requirement,
        true_support_bound=0.0,
    )
    return create_commitment(
        "commit_guard", proposal, robots, result, params, partition,
        phase_contract_id=contract.contract_id, assist_for=old.ident,
    )


def confirm_assist_takeover(
    old: Commitment, assist: Commitment, evidence: HandoffEvidence,
    contract: TwoStageContract, partition: Optional[PartitionState],
    robots: list[Robot], result: PolicyResult,
) -> bool:
    """Preauthorized witness recovery may certify B's coverage without freeing A.

    This is an abstract witness confirmation, not a general two-certificate
    atomic commit protocol.  If the contract lacks this edge, both records stay.
    """
    if not (
        contract.witness_recovery_authorized
        and evidence.trusted and evidence.valid and evidence.physically_observed
        and evidence.kind == "physical_takeover"
        and evidence.contract_id == contract.contract_id
        and evidence.residual_id == old.ident
        and assist.assist_for == old.ident
        and assist.phase_contract_id == contract.contract_id
        and assist.status in ACTIVE_STATUSES
        and has_latest_certificate(old, robots)
        and has_latest_certificate(assist, robots)
        and assist.reserved.get(assist.carrier, 0.0) + 1e-9 >= contract.successor_requirement
    ):
        return False
    assist.network_partition = partition
    committed = record_version(
        "commit_guard", assist, result, robots, "assist_takeover",
        authorization_reason=f"preauthorized_witness_recovery_from_{old.ident}",
        target_state={
            "physical_stage": "takeover",
            "phase_evidence_hash": snapshot_hash(asdict(evidence)),
            "assist_for": old.ident,
        },
        partition=partition,
    )
    if committed:
        old.lifecycle_events.append({
            "transition": "successor_coverage_observed",
            "successor": assist.ident,
            "successor_effective_version": assist.effective_version,
            "old_backing_retained": True,
        })
    return committed


def try_recover_at_risk(
    policy: str,
    commitment: Commitment,
    partition: Optional[PartitionState],
    robots: list[Robot],
    result: PolicyResult,
    params: Params,
    live: list[Commitment],
    epoch: Optional[int] = None,
) -> None:
    if commitment.status != STATUS_AT_RISK:
        return
    if policy == "central_commit_aware" and not has_latest_certificate(commitment, robots):
        # No successor can be certified without the effective predecessor.
        # Retain the old resource lock until an existing copy becomes reachable
        # or a separately authorized physical disposition is available.
        return
    if commitment.at_risk_reason == "discharge_certificate_unconfirmed":
        recovery_epoch = commitment.physical_completion_epoch if epoch is None else epoch
        if recover_pending_retire(policy, commitment, partition, robots, result, recovery_epoch or 0):
            if commitment in live:
                live.remove(commitment)
        return
    if commitment.at_risk_reason in {
        "invalid_or_missing_discharge_evidence",
    }:
        return
    inactive = [p for p in commitment.participants if not robots[p].active]
    if inactive:
        order = [r for r in range(len(robots)) if r not in commitment.participants]
        role_pick = 0.0 if commitment.support in inactive else 1.0
        event = HandoffEvent(epoch=0, pick=0.0, role_pick=role_pick, target_order=tuple(order))
        attempt_handoff(policy, commitment, event, partition, robots, result, params, live)
        return
    attempt_top_up(policy, commitment, live, robots, partition, result, params, reason="at_risk_recovery")


def apply_replay(policy: str, commitment: Commitment, robots: list[Robot], result: PolicyResult, stale_offset: int) -> None:
    result.replay_attempts += 1
    current_version = commitment.effective_version if caps(policy).has_certificate_auth else commitment.version
    stale_version = max(1, current_version - stale_offset)
    if stale_version >= current_version:
        result.replay_current_noop += 1
        return
    result.replay_effective_attempts += 1
    if caps(policy).has_monotonic_version:
        result.replay_rejected += 1
        result.detection_count += 1
        return
    result.version_replay_accepted += 1
    result.replay_accepted += 1
    result.attack_success += 1
    result.version_violations += 1
    result.invariant_violations += 1
    result.silent_unbacking += 1
    snapshot = commitment.certificate_history.get(stale_version)
    if snapshot is not None:
        current_participants = set(commitment.participants)
        restore_snapshot_without_changing_physical_truth(commitment, robots, snapshot)
        commitment.version = stale_version
        commitment.effective_version = stale_version
        if set(commitment.participants) != current_participants:
            result.stale_ownership += 1
        if not is_backed_by_reserved(commitment, robots, use_true=True):
            result.rollback_silent_unbacking += 1
            result.resource_reuse_after_rollback += 1
            result.unbacked_window_count += 1
            result.physical_underbacking_events += 1
        for robot in robots:
            if robot.active and policy != "immediate_only" and robot.total_reserved > robot.energy - robot.self_reserve + 1e-9:
                result.rollback_double_spend += 1
                break
        result.max_version_seen[commitment.ident] = commitment.version


def handle_crash(policy: str, robot_id: int, robots: list[Robot], live: list[Commitment], result: PolicyResult) -> None:
    if not robots[robot_id].active:
        return
    robots[robot_id].active = False
    robots[robot_id].energy = 0.0
    for commitment in list(live):
        if commitment.status not in ACTIVE_STATUSES:
            continue
        if robot_id in commitment.participants:
            # A completed Retire may still have an old effective certificate,
            # but its consumed backing is no longer physical capacity to lose.
            lost_backing = (0.0 if commitment.physical_execution_completed else
                            max(0.0, commitment.reserved.get(robot_id, 0.0)))
            previously_recorded = commitment.lost_physical_backing.get(robot_id, 0.0)
            if lost_backing > previously_recorded + 1e-9:
                result.lost_physical_capacity += lost_backing - previously_recorded
                commitment.lost_physical_backing[robot_id] = lost_backing
            if policy in PROTECTED_POLICIES:
                transition_at_risk(commitment, robots, result, policy, "participant_crash")
            elif policy == "immediate_only":
                result.forgotten += 1
                result.silent_unbacking += 1
            else:
                result.silent_unbacking += 1


def requirement_underestimated(commitment: Commitment) -> bool:
    return any(true_amount > commitment.claimed_req.get(robot_id, 0.0) + 1e-9 for robot_id, true_amount in commitment.true_req.items())


def record_model_underestimate(commitment: Commitment, result: PolicyResult) -> None:
    if commitment.contract_violation_recorded:
        return
    if requirement_underestimated(commitment):
        commitment.contract_violation_recorded = True
        result.model_underestimate_events += 1
        result.contract_bound_violations += 1


def record_bound_detection(commitment: Commitment, result: PolicyResult, epoch: int) -> None:
    if not requirement_underestimated(commitment):
        return
    record_model_underestimate(commitment, result)
    if commitment.underestimate_detected:
        return
    commitment.underestimate_detected = True
    commitment.underestimate_detected_epoch = epoch
    latency = max(0, epoch - commitment.created_epoch)
    result.bound_detection_count += 1
    result.late_at_risk_discovery += 1
    result.bound_detection_latency_total += latency
    result.detection_latency_total += latency
    if commitment.proposal.adversarial and commitment.proposal.adversarial_kind == "underdeclared_bound":
        result.detection_count += 1


def settle_commitment(commitment: Commitment, policy: str, robots: list[Robot], result: PolicyResult, epoch: int) -> bool:
    if commitment.physical_execution_completed:
        return False
    record_bound_detection(commitment, result, epoch)
    if commitment.status == STATUS_AT_RISK and policy in PROTECTED_POLICIES:
        if not commitment.physical_live and commitment.discharge_evidence_validated:
            # The physical action completed, but the Retire certificate is
            # uncertain.  Keep the old rights conservatively locked for
            # recovery instead of manufacturing a physical rupture.
            return False
        transition_rupture(commitment, robots, result, policy, "settlement_attempted_while_at_risk")
        mark_missed(result, "failed")
        return False

    if not active_participants(commitment.participants, robots):
        if policy in PROTECTED_POLICIES:
            transition_rupture(commitment, robots, result, policy, "participant_unavailable_at_settlement")
        else:
            release_reservations(commitment, robots, result, policy, "unsafe_failure")
        if commitment.proposal.adversarial:
            result.adversarial_physical_violation += 1
        mark_missed(result, "failed")
        return False

    actual_need = {robot_id: amount * commitment.proposal.settlement_ratio for robot_id, amount in commitment.true_req.items()}
    if policy == "immediate_only":
        ok = all(robots[r].energy + 1e-9 >= amount for r, amount in actual_need.items())
    else:
        ok = all(commitment.reserved.get(r, 0.0) + 1e-9 >= amount for r, amount in actual_need.items())

    if ok:
        for robot_id, amount in actual_need.items():
            spend_energy(robots, robot_id, amount, result)
        commitment.physical_execution_completed = True
        commitment.physical_completion_epoch = epoch
        commitment.retire_consumed_amounts = dict(actual_need)
        result.physical_completed += 1
        discharged = transition_discharge(
            commitment,
            robots,
            result,
            policy,
            used_by_commitment=actual_need if policy != "immediate_only" else None,
            epoch=epoch,
        )
        if discharged:
            if not commitment.rescued_recorded:
                commitment.rescued_recorded = True
                result.rescued += 1
                if commitment.proposal.adversarial:
                    result.adversarial_success += 1
            return True
        return False

    if policy in PROTECTED_POLICIES:
        transition_rupture(commitment, robots, result, policy, "insufficient_reserved_backing_at_settlement")
    else:
        release_reservations(commitment, robots, result, policy, "unsafe_failure")
    if commitment.proposal.adversarial:
        result.adversarial_physical_violation += 1
        if commitment.proposal.adversarial_kind == "underdeclared_bound":
            result.underdeclared_physical_underbacking += 1
    if not ok:
        result.physical_underbacking_events += 1
    mark_missed(result, "failed")
    return False


def discharge_evidence_ready(commitment: Commitment, epoch: int) -> bool:
    return epoch >= commitment.proposal.evidence_epoch


def valid_discharge_evidence(commitment: Commitment) -> bool:
    return not commitment.proposal.evidence_missing and commitment.proposal.evidence_valid


def process_completion_and_deadlines(policy: str, epoch: int, live: list[Commitment], robots: list[Robot], result: PolicyResult) -> None:
    for commitment in list(live):
        if not commitment.protected_present or commitment.status not in ACTIVE_STATUSES:
            continue
        if commitment.physical_execution_completed:
            continue
        if epoch >= commitment.finish_epoch and not discharge_evidence_ready(commitment, epoch):
            if not commitment.discharge_pending_recorded:
                commitment.discharge_pending_recorded = True
                result.discharge_evidence_pending += 1
            continue
        if epoch >= commitment.finish_epoch and epoch <= commitment.due_epoch and discharge_evidence_ready(commitment, epoch):
            if not valid_discharge_evidence(commitment):
                if not commitment.evidence_failure_recorded:
                    commitment.evidence_failure_recorded = True
                    if commitment.proposal.evidence_missing:
                        result.discharge_evidence_missing += 1
                    else:
                        result.discharge_evidence_invalid += 1
                if policy in PROTECTED_POLICIES:
                    transition_at_risk(commitment, robots, result, policy, "invalid_or_missing_discharge_evidence")
                else:
                    live.remove(commitment)
                    release_reservations(commitment, robots, result, policy, "unsafe_failure")
                    mark_missed(result, "failed")
                continue
            settled = settle_commitment(commitment, policy, robots, result, epoch)
            if settled or policy not in PROTECTED_POLICIES:
                live.remove(commitment)

    for commitment in list(live):
        if not commitment.protected_present or commitment.status not in ACTIVE_STATUSES:
            continue
        if commitment.physical_execution_completed:
            continue
        if epoch >= commitment.due_epoch and (
            commitment.finish_epoch > commitment.due_epoch
            or not discharge_evidence_ready(commitment, epoch)
            or not valid_discharge_evidence(commitment)
        ):
            if policy in PROTECTED_POLICIES:
                transition_rupture(commitment, robots, result, policy, "deadline_expired_before_completion_or_evidence")
            else:
                live.remove(commitment)
                release_reservations(commitment, robots, result, policy, "deadline_failure")
            mark_missed(result, "deadline_missed")


def check_contract_claim(commitment: Commitment, result: PolicyResult) -> None:
    record_model_underestimate(commitment, result)


def release_forgotten_view(commitment: Commitment, robots: list[Robot], result: PolicyResult, policy: str) -> None:
    if commitment.forgotten_released:
        return
    if (policy == "commit_guard" and (
        commitment.physical_live
        or commitment.certificate_update_uncertain
        or commitment.pending_operation
    )) or (policy == "central_commit_aware" and (
        commitment.physical_live
        or commitment.certificate_update_uncertain
        or commitment.pending_operation
        or not commitment.retire_committed_recorded
    )):
        # Losing access to the latest effective certificate never authorizes an
        # uncommitted Retire.  This includes the window where trusted physical
        # discharge has occurred but its successor certificate is uncertain:
        # keep the old effective right and any consumed/pending accounting
        # locked for recovery rather than manufacturing a bookkeeping retire.
        # Central has no witnesses or local ownership mechanism: after its sole
        # durable view is lost, it cannot safely infer discharge or reclaim the
        # lock.  This is an explicit availability limit, not a new capability.
        transition_at_risk(
            commitment, robots, result, policy, "certificate_copies_unavailable"
        )
        return
    released = sum(commitment.reserved.values())
    record_reservation_release_accounting(commitment, result)
    for robot_id in list(commitment.reserved):
        if 0 <= robot_id < len(robots):
            robots[robot_id].reserved.pop(commitment.ident, None)
    commitment.reserved.clear()
    commitment.effective_reserved.clear()
    commitment.pending_reserved.clear()
    commitment.pending_consumed_backing.clear()
    commitment.pending_operation = ""
    commitment.pending_version = None
    release_remote_claims(commitment, robots)
    commitment.protected_present = False
    commitment.status = STATUS_FORGOTTEN
    commitment.forgotten_released = True
    commitment.release_events.append(
        {
            "reason": "certificate_view_forgotten",
            "authorized": False,
            "executed": True,
            "amount": released,
            "effective_version": commitment.effective_version,
            "physical_live": commitment.physical_live,
        }
    )
    result.forgotten_and_resources_reused += 1 if released > 1e-9 else 0
    result.commitment_loss += 1
    if commitment.physical_live:
        result.physical_commitments_still_live += 1
        result.orphaned_liability += sum(commitment.true_req.values())


def check_forgetting(policy: str, commitment: Commitment, robots: list[Robot], result: PolicyResult) -> None:
    if not (caps(policy).has_commitment_ledger and caps(policy).has_certificate_auth) or commitment.forgetting_recorded or not commitment.protected_present:
        return
    result.certificate_survival_checks += 1
    if not has_latest_certificate(commitment, robots):
        commitment.forgetting_recorded = True
        result.forgotten += 1
        result.forgotten_commitments += 1
        result.certificates_lost += 1
        release_forgotten_view(commitment, robots, result, policy)
    else:
        result.certificate_survivors += 1


def check_remote_ownership_conflicts(policy: str, robots: list[Robot], live: list[Commitment], result: PolicyResult, where: str) -> None:
    live_by_id = {commitment.ident: commitment for commitment in live if commitment.protected_present}
    for robot_id, robot in enumerate(robots):
        if not robot.remote_reserved:
            continue
        local_reserved = sum(robot.reserved.values())
        remote_reserved = sum(robot.remote_reserved.values())
        has_local_overlap = local_reserved > 1e-9 and remote_reserved > 1e-9
        has_remote_overlap = len(robot.remote_reserved) > 1
        has_capacity_conflict = robot.active and local_reserved + remote_reserved > robot.energy - robot.self_reserve + 1e-9
        if not (has_local_overlap or has_remote_overlap or has_capacity_conflict):
            continue
        for commitment_id in list(robot.remote_reserved):
            commitment = live_by_id.get(commitment_id)
            if commitment is None:
                result.release_violations += 1
                result.invariant_violations += 1
                continue
            if commitment.remote_overspend_recorded:
                continue
            if has_local_overlap or has_remote_overlap:
                record_invariant_violation(policy, result, "double_spend_violations", f"remote claim {commitment_id} overlaps resource ownership on robot {robot_id} at {where}")
                result.remote_double_spend_events += 1
            if has_capacity_conflict:
                record_invariant_violation(policy, result, "capacity_violations", f"remote claim {commitment_id} exceeds local capacity on robot {robot_id} at {where}")
            result.stale_ownership += 1
            result.ownership_conflicts += 1
            result.remote_overspend_success += 1
            result.attack_success += 1
            result.adversarial_success += 1
            result.adversarial_physical_violation += 1
            commitment.remote_overspend_recorded = True


def check_invariants(policy: str, robots: list[Robot], live: list[Commitment], result: PolicyResult, where: str) -> None:
    for i, robot in enumerate(robots):
        if robot.energy < -1e-9:
            record_invariant_violation(policy, result, "capacity_violations", f"robot {i} negative energy at {where}")
        if robot.self_level not in SELF_LEVELS:
            record_invariant_violation(policy, result, "illegal_degradation_violations", f"robot {i} illegal level {robot.self_level}")
        if robot.active and policy != "immediate_only" and robot.total_reserved > robot.energy - robot.self_reserve + 1e-9:
            record_invariant_violation(policy, result, "capacity_violations", f"robot {i} over-reserved at {where}")
        for cid, amount in robot.reserved.items():
            if amount < -1e-9:
                record_invariant_violation(policy, result, "double_spend_violations", f"negative reservation {cid} at {where}")
        for cid, amount in robot.remote_reserved.items():
            if amount < -1e-9:
                record_invariant_violation(policy, result, "double_spend_violations", f"negative remote reservation {cid} at {where}")
        for cid, amount in robot.pending_execution_cost.items():
            if amount < -1e-9:
                record_invariant_violation(policy, result, "double_spend_violations", f"negative pending Mint cost {cid} at {where}")

    check_remote_ownership_conflicts(policy, robots, live, result, where)

    active_ids = {
        c.ident
        for c in live
        if c.protected_present and (c.status in ACTIVE_STATUSES or c.physical_live)
    }
    for robot in robots:
        for cid in robot.reserved:
            if cid not in active_ids:
                record_invariant_violation(policy, result, "release_violations", f"reservation for inactive commitment {cid} remains at {where}")
        for cid in robot.remote_reserved:
            if cid not in active_ids:
                record_invariant_violation(policy, result, "release_violations", f"remote claim for inactive commitment {cid} remains at {where}")

    for commitment in live:
        if lifecycle_protected(policy) and commitment.physical_live and not commitment.protected_present:
            record_invariant_violation(
                policy,
                result,
                "release_violations",
                f"commitment {commitment.ident} removed from protected state while physical liability remains",
            )
        if caps(policy).has_certificate_auth and commitment.effective_version > 0:
            effective = commitment.effective_version
            snapshot = commitment.certificate_history.get(effective)
            metadata = commitment.certificate_metadata.get(effective)
            acknowledgements = commitment.certificate_acknowledgements.get(effective, set())
            if snapshot is None or metadata is None:
                record_invariant_violation(
                    policy,
                    result,
                    "version_violations",
                    f"commitment {commitment.ident} effective certificate {effective} lacks committed state",
                )
            else:
                expected_hash = commitment.version_state_hashes.get(effective)
                if expected_hash != snapshot_hash(snapshot):
                    record_invariant_violation(
                        policy,
                        result,
                        "certificate_hash_violations",
                        f"commitment {commitment.ident} effective certificate {effective} hash mismatch",
                    )
                predecessor = int(metadata.get("predecessor", -1))
                if predecessor >= effective or commitment.certificate_successors.get(predecessor) != effective:
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} effective certificate {effective} has invalid predecessor chain",
                    )
                committed_versions = set(commitment.certificate_history)
                if committed_versions and effective != max(committed_versions):
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} effective certificate {effective} is not the committed chain head",
                    )
                if int(snapshot.get("version", -1)) != effective:
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} certificate {effective} carries a different state version",
                    )
                required_participants = {int(snapshot["carrier"])}
                if snapshot.get("support") is not None:
                    required_participants.add(int(snapshot["support"]))
                if not required_participants.issubset(acknowledgements):
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} certificate {effective} lacks participant confirmation",
                    )
                persisted_copies = commitment.certificate_persisted_versions.get(effective, acknowledgements)
                if len(persisted_copies) < commitment.certificate_persistence_threshold:
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} certificate {effective} lacks persistence quorum",
                    )
                certificate_reserved = _native_snapshot_map(snapshot.get("reserved", {}))
                if certificate_reserved != commitment.effective_reserved or commitment.reserved != commitment.effective_reserved:
                    result.certificate_ledger_mismatch_violations += 1
                    record_invariant_violation(
                        policy,
                        result,
                        "backing_violations",
                        f"commitment {commitment.ident} effective certificate reservation differs from effective logical ledger",
                    )
                stable_state_mismatches: list[str] = []
                if int(snapshot.get("carrier", -1)) != commitment.carrier:
                    stable_state_mismatches.append("carrier")
                snapshot_support = snapshot.get("support")
                native_support = None if snapshot_support is None else int(snapshot_support)
                if native_support != commitment.support:
                    stable_state_mismatches.append("support")
                if str(snapshot.get("guarantee", "")) != commitment.guarantee:
                    stable_state_mismatches.append("guarantee")
                for stage_field in ("phase_contract_id", "physical_stage", "phase_evidence_hash", "assist_for",
                                    "physical_object", "responsibility_scope", "responsibility_units"):
                    if snapshot.get(stage_field) != getattr(commitment, stage_field):
                        stable_state_mismatches.append(stage_field)
                if _native_snapshot_map(snapshot.get("certified_min_req", {})) != commitment.certified_min_req:
                    stable_state_mismatches.append("certified_min_req")
                if _native_snapshot_map(snapshot.get("initial_claimed_req", {})) != commitment.initial_claimed_req:
                    stable_state_mismatches.append("initial_claimed_req")
                if bool(snapshot.get("protected_present", True)) != commitment.protected_present:
                    stable_state_mismatches.append("protected_present")

                # AT-RISK/RUPTURED is an explicit operational overlay when an
                # exogenous change occurred but the successor certificate is
                # uncertain.  In that conservative state the physical truth
                # and current requirement may legitimately be newer than the
                # last effective certificate; participant identity and the
                # certified guarantee still may not change silently.
                uncertain_risk_overlay = (
                    commitment.certificate_update_uncertain
                    and commitment.status in {STATUS_AT_RISK, STATUS_RUPTURED}
                )
                if not uncertain_risk_overlay:
                    if str(snapshot.get("status", "")) != commitment.status:
                        stable_state_mismatches.append("status")
                    if _native_snapshot_map(snapshot.get("claimed_req", {})) != commitment.claimed_req:
                        stable_state_mismatches.append("claimed_req")
                    if _native_snapshot_map(snapshot.get("true_req", {})) != commitment.true_req:
                        stable_state_mismatches.append("true_req")
                    if bool(snapshot.get("physical_live", commitment.physical_live)) != commitment.physical_live:
                        stable_state_mismatches.append("physical_live")
                if stable_state_mismatches:
                    result.certificate_ledger_mismatch_violations += 1
                    record_invariant_violation(
                        policy,
                        result,
                        "backing_violations",
                        f"commitment {commitment.ident} effective certificate differs from protected state: "
                        + ",".join(stable_state_mismatches),
                    )

                inheritance = metadata.get("responsibility_inheritance", {})
                expected_inheritance = {
                    "physical_live": snapshot.get("physical_live"),
                    "carrier": snapshot.get("carrier"),
                    "support": snapshot.get("support"),
                    "guarantee": snapshot.get("guarantee"),
                    "phase_contract_id": snapshot.get("phase_contract_id", ""),
                    "physical_stage": snapshot.get("physical_stage", "placement"),
                    "phase_evidence_hash": snapshot.get("phase_evidence_hash", ""),
                    "assist_for": snapshot.get("assist_for"),
                    "physical_object": snapshot.get("physical_object"),
                    "responsibility_scope": snapshot.get("responsibility_scope"),
                    "responsibility_units": snapshot.get("responsibility_units"),
                }
                if inheritance != expected_inheritance:
                    record_invariant_violation(
                        policy,
                        result,
                        "certificate_hash_violations",
                        f"commitment {commitment.ident} certificate responsibility inheritance mismatch",
                    )
                crashed_acknowledgers = {
                    holder
                    for holder in acknowledgements
                    if holder < 0 or holder >= len(robots) or not robots[holder].active
                }
                active_acknowledgers = acknowledgements - crashed_acknowledgers
                if (
                    len(acknowledgements) >= commitment.certificate_fault_tolerance + 1
                    and len(crashed_acknowledgers) <= commitment.certificate_fault_tolerance
                    and not active_acknowledgers
                ):
                    result.certificate_survival_guarantee_violations += 1
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} lost all f+1 certificate copies within fault threshold",
                    )
        for release_event in commitment.release_events:
            if (
                lifecycle_protected(policy)
                and bool(release_event.get("executed"))
                and not bool(release_event.get("authorized"))
                and not bool(release_event.get("violation_recorded"))
            ):
                release_event["violation_recorded"] = True
                result.residual_liability_reuse_violations += 1
                record_invariant_violation(
                    policy,
                    result,
                    "release_violations",
                    f"commitment {commitment.ident} executed release without state authorization",
                )
            if (
                lifecycle_protected(policy)
                and bool(release_event.get("executed"))
                and bool(release_event.get("authorized"))
                and int(release_event.get("effective_version", 0)) > commitment.effective_version
            ):
                record_invariant_violation(
                    policy,
                    result,
                    "release_violations",
                    f"commitment {commitment.ident} release cites an uncommitted certificate",
                )
        if not commitment.protected_present:
            continue
        if commitment.effective_version > commitment.version:
            record_invariant_violation(
                policy,
                result,
                "version_violations",
                f"commitment {commitment.ident} effective version exceeds candidate version",
            )
        for lifecycle_event in commitment.lifecycle_events:
            if lifecycle_event.get("transition") != "degrade":
                continue
            edge_values = (
                str(lifecycle_event.get("from_guarantee")),
                str(lifecycle_event.get("to_guarantee")),
            )
            certificate_version = int(lifecycle_event.get("certificate_version", 0))
            metadata = commitment.certificate_metadata.get(certificate_version, {})
            if (
                edge_values not in commitment.authorized_degradation_edges
                or metadata.get("transition_type") != "policy_degradation"
            ):
                record_invariant_violation(
                    policy,
                    result,
                    "illegal_degradation_violations",
                    f"commitment {commitment.ident} degradation lacks contract authorization",
                )
        if commitment.status == STATUS_RUPTURED and commitment.physical_live:
            for robot_id, amount_at_rupture in commitment.rupture_backing_snapshot.items():
                if 0 <= robot_id < len(robots) and robots[robot_id].active:
                    retained = commitment.reserved.get(robot_id, 0.0)
                    mirrored = robots[robot_id].reserved.get(commitment.ident, 0.0)
                    consumed_pending = commitment.pending_consumed_backing.get(robot_id, 0.0)
                    if retained + 1e-9 < amount_at_rupture or mirrored + consumed_pending + 1e-9 < amount_at_rupture:
                        record_invariant_violation(
                            policy,
                            result,
                            "release_violations",
                            f"commitment {commitment.ident} reused valid backing after rupture",
                        )
        if commitment.status == STATUS_AT_RISK and (
            commitment.physical_live or commitment.certificate_update_uncertain
        ):
            for robot_id, amount_at_risk in commitment.at_risk_backing_snapshot.items():
                if 0 <= robot_id < len(robots) and robots[robot_id].active:
                    retained = commitment.reserved.get(robot_id, 0.0)
                    mirrored = robots[robot_id].reserved.get(commitment.ident, 0.0)
                    consumed_pending = commitment.pending_consumed_backing.get(robot_id, 0.0)
                    if retained + 1e-9 < amount_at_risk or mirrored + consumed_pending + 1e-9 < amount_at_risk:
                        record_invariant_violation(
                            policy,
                            result,
                            "release_violations",
                            f"commitment {commitment.ident} reused valid backing while at risk",
                        )
        if commitment.status not in ACTIVE_STATUSES:
            if commitment.status not in {STATUS_FORGOTTEN, STATUS_RUPTURED, STATUS_DISCHARGED}:
                if caps(policy).has_at_risk_state:
                    record_invariant_violation(policy, result, "release_violations", f"inactive commitment {commitment.ident} remains in live list")
                else:
                    result.release_violations += 1
                    result.invariant_violations += 1
            if commitment.status == STATUS_RUPTURED and not commitment.physical_live:
                record_invariant_violation(
                    policy,
                    result,
                    "release_violations",
                    f"commitment {commitment.ident} rupture silently cleared physical liability",
                )
            continue
        if caps(policy).has_monotonic_version:
            remember_version(policy, commitment, result)
        for version, snapshot in commitment.certificate_history.items():
            expected = commitment.version_state_hashes.get(version)
            if expected is not None and expected != snapshot_hash(snapshot):
                record_invariant_violation(policy, result, "certificate_hash_violations", f"commitment {commitment.ident} version {version} hash mismatch")
        check_contract_claim(commitment, result)
        check_forgetting(policy, commitment, robots, result)
        if not commitment.protected_present:
            continue
        if caps(policy).has_commitment_ledger and commitment.status in {STATUS_LIVE, STATUS_DEGRADED}:
            if not is_backed_by_reserved(commitment, robots, use_true=False):
                record_invariant_violation(policy, result, "backing_violations", f"commitment {commitment.ident} lacks modeled backing at {where}")
        if policy != "immediate_only":
            reservation_robots = set(commitment.reserved) | set(commitment.pending_reserved) | set(commitment.pending_consumed_backing)
            reservation_robots.update(
                robot_id for robot_id, robot in enumerate(robots) if commitment.ident in robot.reserved
            )
            for robot_id in reservation_robots:
                if commitment.pending_reserved.get(robot_id, 0.0) < -1e-9 or commitment.pending_consumed_backing.get(robot_id, 0.0) < -1e-9:
                    record_invariant_violation(policy, result, "double_spend_violations", f"negative pending reservation for commitment {commitment.ident}")
                    continue
                expected_lock = expected_physical_lock(commitment, robot_id)
                mirrored = robots[robot_id].reserved.get(commitment.ident, 0.0) if 0 <= robot_id < len(robots) else 0.0
                if abs(mirrored - expected_lock) > 1e-9:
                    record_invariant_violation(
                        policy,
                        result,
                        "double_spend_violations",
                        f"effective plus pending reservation mismatch for commitment {commitment.ident}",
                    )
            if commitment.pending_reserved and not commitment.pending_operation:
                record_invariant_violation(
                    policy,
                    result,
                    "version_violations",
                    f"commitment {commitment.ident} has pending locks without a transaction state",
                )
            has_pending_state = bool(
                commitment.pending_reserved
                or commitment.pending_consumed_backing
                or commitment.pending_operation
            )
            if has_pending_state and commitment.pending_version is None:
                record_invariant_violation(
                    policy,
                    result,
                    "version_violations",
                    f"commitment {commitment.ident} has pending transaction state without a version",
                )
            if commitment.pending_operation.endswith(":post_commit_release"):
                if commitment.pending_version != commitment.effective_version:
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} post-commit release lock is not tied to the effective version",
                    )
            elif has_pending_state and commitment.pending_version is not None:
                if commitment.pending_version <= commitment.effective_version:
                    record_invariant_violation(
                        policy,
                        result,
                        "version_violations",
                        f"commitment {commitment.ident} uncommitted pending state does not identify a successor version",
                    )
            for robot_id, amount in commitment.remote_claims.items():
                if 0 <= robot_id < len(robots) and robots[robot_id].remote_reserved.get(commitment.ident) != amount:
                    record_invariant_violation(policy, result, "double_spend_violations", f"remote claim mismatch for commitment {commitment.ident}")


def update_time_integrals(live: list[Commitment], robots: list[Robot], result: PolicyResult) -> None:
    result.pending_lock_duration += sum(
        1 for commitment in live
        if commitment.physical_execution_completed and commitment.retire_pending_since is not None
        and not commitment.retire_committed_recorded
    )
    active_commitments = sum(1 for c in live if c.protected_present and c.status in ACTIVE_STATUSES)
    result.active_commitments_area += active_commitments
    result.peak_active_commitments = max(result.peak_active_commitments, active_commitments)
    reserved_now = sum(robot.total_reserved for robot in robots)
    effective_reserved_now = sum(
        sum(commitment.reserved.values())
        for commitment in live
        if commitment.protected_present
    )
    pending_reserved_now = sum(
        sum(commitment.pending_reserved.values())
        for commitment in live
        if commitment.protected_present
    )
    result.reserved_energy_area += reserved_now
    result.reservation_energy_area += reserved_now
    result.effective_reservation_energy_area += effective_reserved_now
    result.pending_reservation_energy_area += pending_reserved_now
    result.peak_reserved_energy = max(result.peak_reserved_energy, reserved_now)
    result.peak_pending_reserved_energy = max(
        result.peak_pending_reserved_energy, pending_reserved_now
    )


def finalize_trace_commitments(
    policy: str,
    live: list[Commitment],
    robots: list[Robot],
    result: PolicyResult,
) -> None:
    for commitment in list(live):
        if commitment.status not in ACTIVE_STATUSES:
            continue
        if commitment.physical_execution_completed and not commitment.retire_committed_recorded:
            commitment.lifecycle_events.append(
                {"transition": "retire_observation_censored", "reason": "certificate_pending_at_end"}
            )
            result.retire_pending_at_end += 1
            result.observation_censored += 1
            continue
        commitment.lifecycle_events.append(
            {"transition": "observation_censored", "reason": "trace_end_unfinished"}
        )
        result.observation_censored += 1
        mark_missed(result, "unfinished")


def finalize_result(result: PolicyResult, params: Params) -> None:
    result.attack_attempts = result.adversarial_proposals + result.replay_attempts + result.lifecycle_attack_attempts
    result.total_energy_consumed = result.energy_consumed
    result.reservation_energy_area = result.reservation_energy_area or result.reserved_energy_area
    result.total_reserved_energy = result.reservation_energy_area
    result.wasted_reserved_energy = result.reserved_backing_released_unused
    result.eventual_physical_violations = result.adversarial_physical_violation
    result.orphaned_physical_liability = result.orphaned_liability
    result.late_detection = result.late_at_risk_discovery
    result.mean_detection_latency = 0.0
    result.underdeclared_failure_rate = (
        result.underdeclared_physical_underbacking / result.underdeclared_admitted
        if result.underdeclared_admitted
        else 0.0
    )
    result.certificate_updates = result.certificate_message_ops
    result.witness_copy_operations = result.witness_copies_created
    result.simulated_message_operations = result.certificate_message_ops
    result.runtime_seconds = result.simulation_runtime_s
    result.runtime_per_trace = result.simulation_runtime_s
    if result.certificate_survival_checks:
        result.witness_survival_rate = result.certificate_survivors / result.certificate_survival_checks
    if params.epochs:
        result.reserved_energy_mean = result.reservation_energy_area / params.epochs
        result.mean_reserved_energy = result.reserved_energy_mean
        result.mean_effective_reserved_energy = (
            result.effective_reservation_energy_area / params.epochs
        )
        result.mean_pending_reserved_energy = (
            result.pending_reservation_energy_area / params.epochs
        )
        result.mean_active_commitments = result.active_commitments_area / params.epochs
    if result.total_initial_energy > 0:
        result.mean_energy_utilization = result.energy_consumed / result.total_initial_energy
    reserve_denominator = result.reserved_backing_consumed + result.reserved_backing_released_unused
    if reserve_denominator > 0:
        result.reserve_efficiency = result.reserved_backing_consumed / reserve_denominator
        result.reserve_efficiency_defined = True
    else:
        result.reserve_efficiency = None
        result.reserve_efficiency_defined = False
    if result.terminal_commitments:
        result.mean_commitment_lifetime = result.total_commitment_lifetime / result.terminal_commitments
    if result.bound_detection_count:
        result.detection_latency_mean = result.detection_latency_total / result.bound_detection_count
        result.mean_detection_latency = result.bound_detection_latency_total / result.bound_detection_count
    if result.proposals:
        result.blocked_rate = result.blocked / result.proposals
        result.silent_unbacking_rate = result.silent_unbacking / result.proposals
        result.detection_rate = result.detection_count / result.attack_attempts if result.attack_attempts else 0.0
        result.attack_success_rate = result.attack_success / result.attack_attempts if result.attack_attempts else 0.0
        result.physical_underbacking_rate = result.physical_underbacking_events / result.proposals
    if params.robots:
        result.rescued_per_robot = result.rescued / params.robots
        result.admitted_per_robot = result.admitted / params.robots


def format_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    minutes, sec = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours:d}h{minutes:02d}m{sec:02d}s"
    if minutes:
        return f"{minutes:d}m{sec:02d}s"
    return f"{sec:d}s"


class ProgressBar:
    def __init__(self, label: str, total: int, enabled: bool = True, min_interval: float = 0.25, width: int = 30) -> None:
        self.label = label
        self.total = max(0, int(total))
        self.enabled = enabled and self.total > 0
        self.min_interval = min_interval
        self.width = width
        self.current = 0
        self.started = time.perf_counter()
        self.last_render = 0.0
        self.rendered = False
        if self.enabled:
            self.render(force=True)

    def update(self, step: int = 1) -> None:
        if not self.enabled:
            return
        self.current = min(self.total, self.current + step)
        now = time.perf_counter()
        if self.current >= self.total or now - self.last_render >= self.min_interval:
            self.render(now=now, force=True)

    def render(self, now: Optional[float] = None, force: bool = False) -> None:
        if not self.enabled:
            return
        now = time.perf_counter() if now is None else now
        if not force and now - self.last_render < self.min_interval:
            return
        self.last_render = now
        elapsed = now - self.started
        ratio = self.current / self.total if self.total else 1.0
        filled = min(self.width, int(round(self.width * ratio)))
        bar = "#" * filled + "-" * (self.width - filled)
        rate = self.current / elapsed if elapsed > 0 else 0.0
        eta = (self.total - self.current) / rate if rate > 0 else 0.0
        message = (
            f"\r{self.label} [{bar}] "
            f"{self.current}/{self.total} {ratio * 100:6.2f}% "
            f"elapsed {format_duration(elapsed)} eta {format_duration(eta)}"
        )
        sys.stderr.write(message)
        sys.stderr.flush()
        self.rendered = True

    def close(self) -> None:
        if not self.enabled:
            return
        if self.current < self.total:
            self.render(force=True)
        if self.rendered:
            sys.stderr.write("\n")
            sys.stderr.flush()


def audit_simulated_physical_liabilities(
    oracle: PhysicalLiabilityOracle,
    known: dict[int, Commitment],
    oracle_state: dict[int, tuple[str, int]],
    robots: list[Robot],
    result: PolicyResult,
    epoch: int,
) -> None:
    """Feed committed physical facts to the evaluation-only Oracle.

    This observer is outside admission/release decisions. It tracks each
    physical residual after the policy has acted and never grants authority.
    """
    for commitment in known.values():
        residual_id = commitment.assist_for if commitment.assist_for is not None else commitment.ident
        if residual_id not in oracle.residuals and commitment.assist_for is None and not commitment.physical_execution_completed:
            required = commitment.true_req.get(commitment.carrier, 0.0)
            oracle.observe(PhysicalEvent(
                commitment.created_epoch, residual_id, "physical_commit", commitment.carrier,
                required_backing=required,
                physical_object=f"residual:{residual_id}",
                contract_id=commitment.phase_contract_id,
                responsibility_scope="full",
                resource_requirements=tuple(commitment.true_req.items()),
            ))
            oracle_state[residual_id] = (commitment.physical_stage, commitment.carrier)
        if commitment.physical_execution_completed and commitment.discharge_evidence_validated:
            if residual_id in oracle.residuals:
                oracle.observe(PhysicalEvent(epoch, residual_id, "physical_discharge", commitment.carrier))
            continue
        if residual_id not in oracle.residuals or not commitment.physical_live:
            continue
        previous_stage, previous_owner = oracle_state.get(
            residual_id, (oracle.residuals[residual_id], oracle.physical_owners[residual_id])
        )
        if commitment.physical_stage != previous_stage:
            kind = "safe_wait" if commitment.physical_stage == "transport" else "physical_takeover"
            oracle.observe(PhysicalEvent(
                epoch, residual_id, kind, commitment.carrier,
                required_backing=commitment.true_req.get(commitment.carrier, 0.0),
                contract_id=commitment.phase_contract_id,
            ))
        elif commitment.carrier != previous_owner:
            oracle.observe(PhysicalEvent(
                epoch, residual_id, "responsibility_handoff", commitment.carrier,
                required_backing=commitment.true_req.get(commitment.carrier, 0.0),
                contract_id=commitment.phase_contract_id,
            ))
        oracle_state[residual_id] = (commitment.physical_stage, commitment.carrier)
        # Observed physical demand includes support roles and later inflation;
        # it is never inferred from current reservation or the certificate bound.
        oracle.resource_requirements[residual_id] = dict(commitment.true_req)

    claims: dict[int, set[int]] = {residual_id: set() for residual_id in oracle.residuals}
    for commitment in known.values():
        residual_id = commitment.assist_for if commitment.assist_for is not None else commitment.ident
        if residual_id in claims:
            claims[residual_id].add(commitment.ident)
    oracle.audit(known.values(), robots, claims, [])
    cumulative = oracle.cumulative_report()
    result.semantic_liability_coverage_violations = max(
        result.semantic_liability_coverage_violations,
        cumulative["semantic_liability_coverage_violations"],
    )
    result.physical_underbacking_events = max(
        result.physical_underbacking_events,
        cumulative["physical_underbacking_events"],
    )
    result.forgotten_liability = max(result.forgotten_liability, cumulative["forgotten_liability"])
    result.durable_record_survival_violations = max(
        result.durable_record_survival_violations,
        cumulative["durable_record_survival_violations"],
    )
    result.record_loss_beyond_fault_model = max(
        result.record_loss_beyond_fault_model,
        cumulative["record_loss_beyond_fault_model"],
    )


def simulate_policy(policy: str, trace: Trace, params: Params) -> PolicyResult:
    start_time = time.perf_counter()
    robots = make_robots(params)
    live: list[Commitment] = []
    known_commitments: dict[int, Commitment] = {}
    liability_oracle = PhysicalLiabilityOracle()
    oracle_state: dict[int, tuple[str, int]] = {}
    result = PolicyResult(policy=policy)
    result.total_initial_energy = params.robots * params.initial_energy

    for epoch in range(params.epochs):
        partition = trace.partitions_by_epoch.get(epoch)
        for commitment in live:
            commitment.network_partition = partition
            commitment.simulation_epoch = epoch

        for robot_id in trace.crashes_by_epoch.get(epoch, []):
            handle_crash(policy, robot_id, robots, live, result)

        for event in trace.inflations_by_epoch.get(epoch, []):
            commitment = choose_live_by_pick(live, event.pick, include_at_risk=False)
            if commitment is not None:
                apply_inflation(policy, commitment, live, robots, partition, result, event.multiplier, params)

        for event in trace.handoffs_by_epoch.get(epoch, []):
            commitment = choose_live_by_pick(live, event.pick, include_at_risk=True)
            if commitment is not None:
                attempt_handoff(policy, commitment, event, partition, robots, result, params, live)

        for event in trace.replays_by_epoch.get(epoch, []):
            commitment = choose_live_by_pick(live, event.pick, include_at_risk=True)
            if commitment is not None:
                apply_replay(policy, commitment, robots, result, event.stale_offset)

        if policy in {"central_commit_aware", "commit_guard"}:
            for commitment in list(live):
                try_recover_at_risk(policy, commitment, partition, robots, result, params, live, epoch)

        for event in trace.lifecycle_attacks_by_epoch.get(epoch, []):
            apply_lifecycle_attack(policy, event, live, robots, result)

        for prop in trace.proposals_by_epoch.get(epoch, []):
            admit(policy, prop, partition, robots, live, result, params)
            for commitment in live:
                known_commitments.setdefault(commitment.ident, commitment)

        process_completion_and_deadlines(policy, epoch, live, robots, result)
        audit_simulated_physical_liabilities(
            liability_oracle, known_commitments, oracle_state, robots, result, epoch
        )
        check_invariants(policy, robots, live, result, f"epoch_{epoch}")
        update_time_integrals(live, robots, result)

    finalize_trace_commitments(policy, live, robots, result)
    audit_simulated_physical_liabilities(
        liability_oracle, known_commitments, oracle_state, robots, result, params.epochs
    )

    result.stranded_robots = sum(1 for r in robots if r.self_level == SELF_STRANDED)
    result.unused_reserved_energy = sum(sum(c.reserved.values()) for c in live)
    result.effective_reserved_energy_at_end = result.unused_reserved_energy
    result.pending_reserved_energy_at_end = sum(
        sum(commitment.pending_reserved.values()) for commitment in live
    )
    result.pending_consumed_backing_at_end = sum(
        sum(commitment.pending_consumed_backing.values()) for commitment in live
    )
    result.physical_locked_energy_at_end = sum(robot.total_reserved for robot in robots)
    result.retained_unavailable_resources += sum(
        sum(robot.reserved.values()) + sum(robot.remote_reserved.values())
        for robot in robots if not robot.active
    )
    result.pending_commitments_at_end = sum(
        1
        for commitment in live
        if commitment.pending_reserved
        or commitment.pending_consumed_backing
        or commitment.pending_operation
    )
    result.pending_uncertain_commitments_at_end = sum(
        1
        for commitment in live
        if commitment.certificate_update_uncertain
        and (
            commitment.pending_reserved
            or commitment.pending_consumed_backing
            or commitment.pending_operation
        )
    )
    result.simulation_runtime_s = time.perf_counter() - start_time
    finalize_result(result, params)
    return result


def mean(values: list[float]) -> float:
    return statistics.fmean(values) if values else 0.0


def stdev(values: list[float]) -> float:
    return statistics.stdev(values) if len(values) > 1 else 0.0


def student_t_critical_95(sample_count: int) -> float:
    """Two-sided 95% Student-t critical value without external dependencies."""
    if sample_count <= 1:
        return 0.0
    table = (
        12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306, 2.262, 2.228,
        2.201, 2.179, 2.160, 2.145, 2.131, 2.120, 2.110, 2.101, 2.093, 2.086,
        2.080, 2.074, 2.069, 2.064, 2.060, 2.056, 2.052, 2.048, 2.045, 2.042,
    )
    degrees = sample_count - 1
    if degrees <= len(table):
        return table[degrees - 1]
    z = 1.959963984540054
    d = float(degrees)
    return (
        z + (z ** 3 + z) / (4 * d)
        + (5 * z ** 5 + 16 * z ** 3 + 3 * z) / (96 * d ** 2)
        + (3 * z ** 7 + 19 * z ** 5 + 17 * z ** 3 - 15 * z) / (384 * d ** 3)
    )


def student_t_ci95(values: list[float]) -> Optional[float]:
    return (
        student_t_critical_95(len(values)) * stdev(values) / math.sqrt(len(values))
        if len(values) > 1 else None
    )


def result_to_row(result: PolicyResult) -> dict[str, float | str]:
    row = asdict(result)
    row.pop("max_version_seen", None)
    return row


def numeric_cell(value: object) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        number = float(value)
        return number if math.isfinite(number) else None
    if isinstance(value, str):
        text = value.strip()
        if not text or text.upper() in {"N/A", "NA", "NONE", "NULL"}:
            return None
        try:
            number = float(text)
        except ValueError:
            return None
        return number if math.isfinite(number) else None
    return None


def aggregate(policy: str, rows: list[PolicyResult]) -> dict[str, float | str]:
    out: dict[str, float | str] = {"policy": policy, "label": POLICY_LABELS[policy]}
    sample = result_to_row(rows[0]) if rows else result_to_row(PolicyResult(policy))
    for key in sample:
        if key == "policy":
            continue
        xs = [value for r in rows if (value := numeric_cell(result_to_row(r).get(key))) is not None]
        if not xs:
            out[f"{key}_mean"] = ""
            out[f"{key}_sd"] = ""
            out[f"{key}_ci95"] = ""
            continue
        out[f"{key}_mean"] = mean(xs)
        out[f"{key}_sd"] = stdev(xs) if len(xs) > 1 else None
        out[f"{key}_ci95"] = student_t_ci95(xs)
        if len(xs) != len(rows):
            out[f"{key}_defined_n"] = len(xs)
    return out


def run_policies(
    params: Params,
    traces: int,
    seed: int,
    policies: list[str],
    progress_label: Optional[str] = None,
    show_progress: bool = True,
) -> tuple[list[dict[str, float | str]], list[dict[str, float | str]]]:
    raw: list[dict[str, float | str]] = []
    by_policy: dict[str, list[PolicyResult]] = {p: [] for p in policies}
    progress = ProgressBar(progress_label or "simulating", traces * len(policies), enabled=show_progress and PROGRESS_ENABLED)
    try:
        for trace_index in range(traces):
            trace = generate_trace(params, seed + trace_index)
            trace_digest = hashlib.sha256(repr(trace).encode("utf-8")).hexdigest()
            for policy in policies:
                result = simulate_policy(policy, trace, params)
                if hashlib.sha256(repr(trace).encode("utf-8")).hexdigest() != trace_digest:
                    raise AssertionError("policy mutated the shared exogenous workload trace")
                by_policy[policy].append(result)
                row = result_to_row(result)
                row["trace"] = trace_index
                row["trace_sha256"] = trace_digest
                row["trace_seed"] = seed + trace_index
                row["policy_label"] = POLICY_LABELS[policy]
                raw.append(row)
                progress.update()
    finally:
        progress.close()
    summary = [aggregate(policy, by_policy[policy]) for policy in policies]
    return summary, raw


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def extra_trace_count(args: argparse.Namespace) -> int:
    return int(getattr(args, "extra_traces", getattr(args, "sweep_traces", 200)))


def paired_analysis(raw: list[dict[str, float | str]], comparisons: list[tuple[str, str]], metrics: list[str]) -> list[dict[str, object]]:
    by_trace_policy: dict[int, dict[str, dict[str, float | str]]] = {}
    for row in raw:
        pair = by_trace_policy.setdefault(int(row["trace"]), {})
        policy = str(row["policy"])
        if policy in pair:
            raise ValueError("duplicate trace/policy in paired analysis; group sweep configurations first")
        pair[policy] = row
    rows: list[dict[str, object]] = []
    for baseline, challenger in comparisons:
        for metric in metrics:
            diffs: list[float] = []
            for policies in by_trace_policy.values():
                if baseline in policies and challenger in policies:
                    challenger_value = numeric_cell(policies[challenger].get(metric))
                    baseline_value = numeric_cell(policies[baseline].get(metric))
                    if challenger_value is None or baseline_value is None:
                        continue
                    diffs.append(challenger_value - baseline_value)
            if not diffs:
                continue
            difference_mean = mean(diffs)
            margin = student_t_ci95(diffs)
            rows.append(
                {
                    "baseline": baseline,
                    "challenger": challenger,
                    "metric": metric,
                    "mean_diff": difference_mean,
                    "sd_diff": stdev(diffs) if len(diffs) > 1 else None,
                    "ci95_low": difference_mean - margin if margin is not None else None,
                    "ci95_high": difference_mean + margin if margin is not None else None,
                    "ci95_method": "paired Student-t",
                    "paired_traces": len(diffs),
                }
            )
    return rows


def write_capability_table(out_dir: Path) -> None:
    rows = []
    for policy in POLICIES:
        row = {"policy": policy, "label": POLICY_LABELS[policy]}
        row.update(asdict(caps(policy)))
        rows.append(row)
    write_csv(out_dir / "policy_capabilities.csv", rows)
    write_json(out_dir / "policy_capabilities.json", rows)


def strict_invariant_enforced(policy: str) -> bool:
    if policy not in STRICT_POLICIES:
        return False
    capability = caps(policy)
    return (
        capability.has_commitment_ledger
        and capability.has_exact_reservation
        and capability.has_authenticated_certificate
        and capability.has_at_risk_state
        and capability.has_monotonic_version
        and capability.has_certificate_auth
        and capability.has_witness_replication
        and capability.has_local_resource_ownership
        and capability.has_policy_degradation
        and capability.has_replacement_before_release
        and capability.has_certified_minimum_backing
        and capability.rejects_visible_planner_errors
    )


def make_params(args: argparse.Namespace, **overrides: float | int | bool | str) -> Params:
    values = asdict(Params())
    values.update(
        robots=args.robots,
        proposal_prob=args.proposal_prob,
        proposal_mode=args.proposal_mode,
        proposal_load_per_robot=args.proposal_load_per_robot,
        partition_start_prob=args.partition_prob,
        partition_duration_min=args.partition_duration_min,
        partition_duration_max=args.partition_duration_max,
        inflation_prob=args.inflation_prob,
        crash_prob=args.crash_prob,
        self_recovery_guarantee=args.self_recovery,
        witness_count=args.witness_count,
        certificate_ack_delay_epochs=args.certificate_ack_delay_epochs,
        retire_recovery_wait_epochs=args.retire_recovery_wait_epochs,
        handoff_prob=args.handoff_prob,
        handoff_replacement_scarcity=args.handoff_replacement_scarcity,
        handoff_crash_prob=args.handoff_crash_prob,
        handoff_old_crash_prob=args.handoff_old_crash_prob,
        handoff_partition_after_certificate_prob=args.handoff_partition_after_certificate_prob,
        version_replay_prob=args.version_replay_prob,
        lifecycle_attack_prob=args.lifecycle_attack_prob,
        lifecycle_attack_kind=args.lifecycle_attack_kind,
        adversarial_proposal_prob=args.adversarial_proposal_prob,
        adversarial_cost_multiplier=args.adversarial_cost_multiplier,
        attack_mode=args.attack_mode,
        bound_error=args.bound_error,
        underreport_fraction=args.underreport_fraction,
        min_carrier_low=args.min_carrier_low,
        min_carrier_medium=args.min_carrier_medium,
        min_carrier_high=args.min_carrier_high,
        min_support_low=args.min_support_low,
        min_support_medium=args.min_support_medium,
        min_support_high=args.min_support_high,
        deadline_tightness=args.deadline_tightness,
        evidence_delay_max=args.evidence_delay_max,
        evidence_missing_prob=args.evidence_missing_prob,
        evidence_invalid_prob=args.evidence_invalid_prob,
        contract_degraded_carrier_requirement=getattr(
            args, "contract_degraded_carrier_requirement", Params.contract_degraded_carrier_requirement
        ),
        contract_degraded_support_requirement=getattr(
            args, "contract_degraded_support_requirement", Params.contract_degraded_support_requirement
        ),
    )
    values.update(overrides)
    return Params(**values)



def experiment_dir(out_dir: Path, name: str) -> Path:
    target = out_dir / name
    target.mkdir(parents=True, exist_ok=True)
    write_capability_table(target)
    return target


def metadata_payload(experiment: str, args: argparse.Namespace, params: Params, trace_count: int, sweep_values: dict[str, object] | list[dict[str, object]]) -> dict[str, object]:
    return {
        "simulator_version": "commitguard-discrete-event-paper-artifact",
        "experiment": experiment,
        "random_seed": args.seed,
        "trace_count": trace_count,
        "params": asdict(params),
        "policy_capabilities": {policy: asdict(caps(policy)) for policy in POLICIES},
        "sweep_values": sweep_values,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "python_version": sys.version,
        "assumptions": {
            "confidence_intervals": "two-sided Student-t mean intervals; paired differences use matched trace IDs; n<2 gives an undefined interval",
            "trace_fingerprints": "run_policies hashes the same Trace before and after every policy; mutation is an error. trace_sha256 is a reproducibility fingerprint within the recorded Python representation version",
            "physical_oracle": "P4 checks object, obligation scope, responsibility units, protected effective version and stage inheritance; energy/capacity is measured separately. The original full obligation persists through an unconfirmed Transform",
            "oracle_scope": "physical history is observed from simulated execution and physical requirement fields. This software-only model is not an independently implemented physical plant",
            "durable_oracle": "only live persisted holders of the current valid certificate count; obsolete quorum envelopes do not extend the successor's crash bound",
            "commit_release_boundary": "logical commit and actual local release are separate counters; inactive owners' resources remain unavailable even if central logical bookkeeping is cleaned",
            "experiment_type": "software-only discrete-event simulation; no ROS/Gazebo/FPGA/real-robot component",
            "completion_time": "default duration is sampled so duration <= deadline; deadline remains the latest permitted completion time",
            "criticality_distribution": "low/medium/high probabilities are 0.50/0.30/0.20",
            "attack_generation": "ground-truth attack labels are generated by the attack RNG and are not visible to policy admission decisions",
            "witness_selection": "witnesses are selected from deterministic witness_order among active non-participant robots",
            "common_random_numbers": "sweeps reuse deterministic stream seeds and change only the swept parameter or threshold",
            "crn_generation_method": "inflation, partition, handoff, replay, and lifecycle_attack use per-epoch deterministic candidate RNG streams; changing a probability threshold does not consume a different number of random values in later epochs",
            "lifecycle_attack_generation": "formal A2/A3 attacks are generated as post-admission LifecycleAttackEvent instances against existing LIVE/DEGRADED commitments; proposal-level malicious fields remain only for compatibility validation",
            "bound_detection_semantics": "model_underestimate_events counts true_req > claimed_req once per commitment as simulator ground truth; bound_detection_count and mean_detection_latency are recorded when settlement exposes the underdeclared requirement",
            "malicious_underreport_semantics": "malicious_underreport lowers only public carrier_bound/support_bound by underreport_fraction; true_carrier_bound/true_support_bound remain based on the original normally sampled bounds and the normal bound_error factor",
            "certified_minimum_backing": "certified_minimum_requirement uses only public participant roles and criticality thresholds; it does not read true_carrier_bound or true_support_bound. COMMIT GUARD reserves max(claimed requirement, certified minimum).",
            "contract_bound_violations_alias": "contract_bound_violations is retained as a compatibility alias for model_underestimate_events",
            "deadline_tightness": "deadline_tightness controls the upper sampling bound for duration relative to deadline; it is not an exact duration/deadline equality constraint",
            "reservation_efficiency": "reserve_efficiency is defined only when a policy has reserved backing; it equals reserved_backing_consumed / (reserved_backing_consumed + reserved_backing_released_unused)",
            "reserved_energy_alias": "total_reserved_energy is retained for old CSV compatibility and means reservation_energy_area, i.e. sum_t Reserved(t), not cumulative energy consumption",
            "rupture_residual": "DISCHARGED clears physical_live after discharge evidence and settlement; RUPTURED leaves physical_live true by default and records residual_after_rupture plus ruptured_physical_liability",
            "rupture_resource_disposition": "AT-RISK and RUPTURED retain valid backing while physical_live remains true. Crash-lost backing is excluded from available capacity; release requires committed discharge, replacement, or explicit terminal disposition evidence.",
            "observation_censoring": "commitments still active at the end of a finite trace are counted as unfinished/observation_censored and are not automatically converted to physical rupture or discharge",
            "contract_degradation": "the default workload defines only the full task guarantee. Alternative task guarantees must be installed through configure_contract_degradation with an explicit authorized edge and resource requirement; the simulator does not infer a degraded physical demand from available reservation",
            "transactional_reservation": "certificate-protected Mint, Inflate, Degrade, Transform, and Retire use prepare/confirm/commit accounting. effective_reserved mirrors the effective certificate; pending_reserved is a conservative physical lock and is not an effective right.",
            "pending_lock_metrics": "pending_reservation_energy_area and mean/peak/end pending metrics quantify conservative locks that are not effective rights; pending_consumed_backing_at_end records physically consumed backing awaiting certificate resolution.",
            "certificate_abstraction": "certificate candidates become effective only after participant acknowledgements and the configured f+1 persistence threshold. This is a lightweight state-machine safety abstraction, not an implementation or formal verification of a network consensus protocol",
            "attack_primary_metrics": "security_attacks_summary.csv reports scenario-specific primary metrics: replay uses effective stale-version attempts, lifecycle attacks use their own accepted/rejected counters, remote-right overspend uses only occupied remote reservations, and underdeclared-liability reports contract-soundness failure rather than generic attack success",
            "invariant_vs_attack_counts": "invariant violation observations may persist across epochs for debugging; attack-event counters such as remote_overspend_success, ownership_conflicts, and remote_double_spend_events are unique per affected commitment",
            "ablation_matching": "ablation runs use Full and Ablated COMMIT GUARD on the same generated trace for each scenario and report paired deltas as Ablated minus Full",
            "minimum_backing_microbench": "minimum_backing_microbench isolates Python admission-check overhead for claimed-only versus certified-minimum max/compare; it is not an end-to-end distributed systems timing measurement",
        },
    }


def write_metadata(out_dir: Path, experiment: str, args: argparse.Namespace, params: Params, trace_count: int, sweep_values: dict[str, object] | list[dict[str, object]]) -> None:
    write_json(out_dir / "experiment_metadata.json", metadata_payload(experiment, args, params, trace_count, sweep_values))


def annotate_rows(rows: list[dict[str, float | str]], experiment: str, seed: int, trace_count: int, params: Params, parameter_values: dict[str, object]) -> list[dict[str, object]]:
    annotated: list[dict[str, object]] = []
    for row in rows:
        out: dict[str, object] = {"experiment": experiment, "seed": seed, "trace_count": trace_count}
        out.update(parameter_values)
        out.update(row)
        if "trace" in out:
            out["trace_id"] = out["trace"]
        if "policy" in out and "policy_label" not in out:
            out["policy_label"] = POLICY_LABELS.get(str(out["policy"]), str(out["policy"]))
        annotated.append(out)
    return annotated


def row_metric(row: dict[str, object], metric: str, summary: bool) -> float:
    key = f"{metric}_mean" if summary else metric
    value = numeric_cell(row.get(key))
    return 0.0 if value is None else value


def add_primary_attack_metrics(row: dict[str, object], attack_name: str, summary: bool) -> None:
    def m(metric: str) -> float:
        return row_metric(row, metric, summary)

    attempts = 0.0
    successes = 0.0
    rejected = 0.0
    blocked = 0.0
    success_rate: float | str = ""
    prevention_rate: float | str = ""

    if attack_name == "A1_replay":
        attempts = m("replay_effective_attempts")
        successes = m("version_replay_accepted")
        rejected = m("replay_rejected")
        success_rate = successes / attempts if attempts else ""
        prevention_rate = rejected / attempts if attempts else ""
    elif attack_name == "A2_silent_cancellation":
        attempts = m("silent_cancellation_attempts")
        successes = m("silent_cancellation_success")
        rejected = m("silent_cancellation_rejected")
        success_rate = successes / attempts if attempts else ""
        prevention_rate = rejected / attempts if attempts else ""
    elif attack_name == "A3_unauthorized_degradation":
        attempts = m("illegal_degradation_attempts")
        successes = m("illegal_degradation_success")
        rejected = m("illegal_degradation_rejected")
        success_rate = successes / attempts if attempts else ""
        prevention_rate = rejected / attempts if attempts else ""
    elif attack_name == "A4_remote_right_overspend":
        attempts = m("remote_overspend_attempts")
        successes = m("remote_overspend_success")
        rejected = m("remote_overspend_rejected")
        blocked = m("remote_overspend_blocked")
        success_rate = successes / attempts if attempts else ""
        prevention_rate = (rejected + blocked) / attempts if attempts else ""
    elif attack_name == "A5_underdeclared_liability":
        attempts = m("underdeclared_attempts")
        admitted = m("underdeclared_admitted")
        successes = m("underdeclared_physical_underbacking")
        rejected = max(0.0, attempts - admitted)
        success_rate = successes / admitted if admitted else ""
        prevention_rate = ""
    else:
        attempts = m("attack_attempts")
        successes = m("attack_success")
        rejected = (
            m("adversarial_rejected")
            + m("replay_rejected")
            + m("silent_cancellation_rejected")
            + m("illegal_degradation_rejected")
            + m("remote_overspend_rejected")
        )
        blocked = m("remote_overspend_blocked")
        success_rate = successes / attempts if attempts else ""
        prevention_rate = (rejected + blocked) / attempts if attempts else ""

    row["primary_attack_attempts"] = attempts
    row["primary_attack_successes"] = successes
    row["primary_attack_rejected"] = rejected
    row["primary_attack_blocked"] = blocked
    row["primary_attack_success_rate"] = success_rate
    row["primary_attack_prevention_rate"] = prevention_rate


def progress_label(experiment: str, traces: int, policies: list[str], parameter_values: dict[str, object]) -> str:
    suffix_parts = []
    for key, value in parameter_values.items():
        if key in {"seed", "trace_count"}:
            continue
        suffix_parts.append(f"{key}={value}")
        if len(suffix_parts) >= 2:
            break
    suffix = f" ({', '.join(suffix_parts)})" if suffix_parts else ""
    return f"{experiment}{suffix}: {traces} traces x {len(policies)} policies"


def run_point(experiment: str, params: Params, traces: int, seed: int, policies: list[str], parameter_values: dict[str, object]) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    summary, raw = run_policies(
        params,
        traces,
        seed,
        policies,
        progress_label=progress_label(experiment, traces, policies, parameter_values),
    )
    return annotate_rows(summary, experiment, seed, traces, params, parameter_values), annotate_rows(raw, experiment, seed, traces, params, parameter_values)


def write_summary_json(path: Path, experiment: str, params: Params, summary: list[dict[str, object]], raw: list[dict[str, object]] | None = None) -> None:
    payload: dict[str, object] = {"experiment": experiment, "params": asdict(params), "summary": summary}
    if raw is not None:
        payload["raw"] = raw
    write_json(path, payload)


def write_paired_outputs(out_dir: Path, raw: list[dict[str, object]], metrics: list[str]) -> list[dict[str, object]]:
    paired = paired_analysis(raw, [("static_worst_case", "commit_guard"), ("priority_cancel", "commit_guard"), ("central_commit_aware", "commit_guard"), ("immediate_only", "commit_guard")], metrics)  # type: ignore[arg-type]
    write_csv(out_dir / "paired_analysis.csv", paired)
    write_json(out_dir / "paired_analysis.json", paired)
    return paired


def default_workload(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "default")
    params = make_params(args)
    summary, raw = run_point("default", params, args.traces, args.seed, POLICIES, {})
    write_csv(exp / "default_summary.csv", summary)
    write_csv(exp / "default_raw.csv", raw)
    paired = write_paired_outputs(exp, raw, [
        "rescued", "physical_completed", "missed", "admitted", "rejected", "blocked",
        "at_risk", "silent_unbacking", "double_spend_violations",
        "semantic_liability_coverage_violations", "physical_underbacking_events",
        "forgotten_liability", "durable_record_survival_violations",
        "pending_lock_duration", "retire_recovered", "retire_pending_at_end",
        "energy_consumed", "invariant_violations", "reserve_efficiency",
    ])
    write_csv(exp / "default_paired_analysis.csv", paired)
    write_json(exp / "default_paired_analysis.json", paired)
    write_summary_json(exp / "default_summary.json", "default", params, summary)
    write_metadata(exp, "default", args, params, args.traces, {})








def partition_sweep(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "partition")
    values = [0.00, 0.025, 0.05, 0.075, 0.10, 0.125, 0.15, 0.18]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    last_params = make_params(args)
    for prob in values:
        params = make_params(args, partition_start_prob=prob)
        last_params = params
        summary, raw = run_point("partition", params, args.sweep_traces, args.seed + 20_000, ["central_commit_aware", "commit_guard"], {"partition_start_probability": prob, "partition_start_prob": prob})
        rows.extend(summary)
        raw_rows.extend(raw)
    write_csv(exp / "partition_sweep.csv", rows)
    write_csv(exp / "partition_raw.csv", raw_rows)
    write_summary_json(exp / "partition_sweep.json", "partition", last_params, rows)
    write_metadata(exp, "partition", args, last_params, args.sweep_traces, {"partition_start_probability": values})


def inflation_sweep(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "inflation")
    values = [0.00, 0.025, 0.05, 0.075, 0.10, 0.125, 0.15, 0.175, 0.20]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    last_params = make_params(args)
    for prob in values:
        params = make_params(args, inflation_prob=prob)
        last_params = params
        summary, raw = run_point("inflation", params, args.sweep_traces, args.seed + 30_000, ["priority_cancel", "static_worst_case", "commit_guard"], {"inflation_probability": prob, "inflation_prob": prob})
        rows.extend(summary)
        raw_rows.extend(raw)
    write_csv(exp / "inflation_sweep.csv", rows)
    write_csv(exp / "inflation_raw.csv", raw_rows)
    write_summary_json(exp / "inflation_sweep.json", "inflation", last_params, rows)
    write_metadata(exp, "inflation", args, last_params, args.sweep_traces, {"inflation_probability": values})


def controlled_witness_failure(args: argparse.Namespace, out_dir: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for witness_count in [0, 1, 2, 3, 4]:
        params = make_params(args, crash_prob=0.0, witness_count=witness_count, partition_start_prob=0.0)
        for requested_crashes in [0, 1, 2, 3, 4]:
            robots = make_robots(params)
            result = PolicyResult(policy="commit_guard")
            result.total_initial_energy = params.robots * params.initial_energy
            prop = Proposal(ident=1, epoch=0, carrier=0, support=1, criticality=2, immediate_cost=4.0, carrier_bound=10.0, support_bound=4.0, true_carrier_bound=10.0, true_support_bound=4.0, deadline=10, duration=4, settlement_ratio=1.0, witness_order=tuple(range(2, params.robots)))
            commitment = create_commitment("commit_guard", prop, robots, result, params)
            live = [commitment] if commitment is not None else []
            holders = sorted(certificate_holders(commitment)) if commitment is not None else []
            crashed = holders[: min(requested_crashes, len(holders))]
            for holder in crashed:
                handle_crash("commit_guard", holder, robots, live, result)
            for c in list(live):
                check_forgetting("commit_guard", c, robots, result)
            actual_crashes = len(crashed)
            copy_count = len(holders)
            actual_extra_witnesses = len(commitment.witnesses) if commitment is not None else 0
            expected_survives = actual_crashes < copy_count
            rows.append({"experiment": "controlled_witness_failure", "seed": args.seed, "policy": "commit_guard", "policy_label": POLICY_LABELS["commit_guard"], "witness_count": witness_count, "actual_extra_witnesses": actual_extra_witnesses, "copy_count": copy_count, "requested_holder_crashes": requested_crashes, "actual_holder_crashes": actual_crashes, "expected_survives_by_f_plus_1": expected_survives, "forgotten_commitments": result.forgotten_commitments, "certificates_lost": result.certificates_lost, "orphaned_physical_liability": result.orphaned_liability, "silent_unbacking": result.silent_unbacking, "invariant_violations": result.invariant_violations})
    write_csv(out_dir / "controlled_witness_failure.csv", rows)
    write_json(out_dir / "controlled_witness_failure.json", rows)
    return rows


def crash_witness_sweep(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "crash_witness")
    crash_values = [0.0, 0.001, 0.002, 0.005, 0.01, 0.02]
    witness_values = [0, 1, 2, 3, 4]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    last_params = make_params(args)
    for crash_prob in crash_values:
        for witnesses in witness_values:
            params = make_params(args, crash_prob=crash_prob, witness_count=witnesses)
            last_params = params
            summary, raw = run_point("crash_witness", params, extra_trace_count(args), args.seed + 50_000, ["commit_guard"], {"crash_probability": crash_prob, "crash_prob": crash_prob, "witness_count": witnesses})
            rows.extend(summary)
            raw_rows.extend(raw)
    controlled = controlled_witness_failure(args, exp)
    write_csv(exp / "crash_witness_sweep.csv", rows)
    write_csv(exp / "crash_witness_raw.csv", raw_rows)
    write_json(exp / "crash_witness_sweep.json", {"summary": rows, "controlled_witness_failure": controlled})
    write_metadata(exp, "crash_witness", args, last_params, extra_trace_count(args), {"crash_probability": crash_values, "witness_count": witness_values})


def handoff_stress(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "handoff")
    values = [0.0, 0.02, 0.05, 0.10, 0.20, 0.30]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    last_params = make_params(args)
    for handoff_prob in values:
        params = make_params(args, handoff_prob=handoff_prob)
        last_params = params
        summary, raw = run_point("handoff_sweep", params, extra_trace_count(args), args.seed + 60_000, ["priority_cancel", "central_commit_aware", "commit_guard"], {"handoff_probability": handoff_prob, "handoff_prob": handoff_prob, "fault": "none"})
        rows.extend(summary)
        raw_rows.extend(raw)
    fault_configs = [("F1_old_participant_crashes_before_replacement", {"handoff_prob": 0.20, "handoff_old_crash_prob": 1.0}), ("F2_replacement_crashes_after_reserve_before_certificate", {"handoff_prob": 0.20, "handoff_crash_prob": 1.0}), ("F3_partition_after_new_certificate_before_old_release", {"handoff_prob": 0.20, "handoff_partition_after_certificate_prob": 1.0}), ("F4_replacement_insufficient_capacity", {"handoff_prob": 0.20, "handoff_replacement_scarcity": 1.0})]
    fault_rows: list[dict[str, object]] = []
    fault_raw: list[dict[str, object]] = []
    for fault_name, overrides in fault_configs:
        params = make_params(args, **overrides)
        last_params = params
        summary, raw = run_point("handoff_fault_injection", params, extra_trace_count(args), args.seed + 61_000, ["priority_cancel", "central_commit_aware", "commit_guard"], {"fault": fault_name, **overrides})
        fault_rows.extend(summary)
        fault_raw.extend(raw)
    write_csv(exp / "handoff_sweep.csv", rows)
    write_csv(exp / "handoff_fault_injection.csv", fault_rows)
    write_csv(exp / "handoff_raw.csv", raw_rows + fault_raw)
    write_json(exp / "handoff_results.json", {"handoff_sweep": rows, "handoff_fault_injection": fault_rows})
    write_json(exp / "handoff_sweep.json", rows)
    write_json(exp / "handoff_fault_injection.json", fault_rows)
    write_metadata(exp, "handoff", args, last_params, extra_trace_count(args), {"handoff_probability": values, "faults": [name for name, _ in fault_configs]})






def security_attacks_experiment(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "security_attacks")
    configs: list[tuple[str, dict[str, object]]] = [
        ("A1_replay", {"version_replay_prob": 0.20, "adversarial_proposal_prob": 0.0, "attack_mode": "mixed", "lifecycle_attack_prob": 0.0}),
        ("A2_silent_cancellation", {"adversarial_proposal_prob": 0.0, "attack_mode": "mixed", "lifecycle_attack_prob": 0.20, "lifecycle_attack_kind": "silent_cancellation"}),
        ("A3_unauthorized_degradation", {"adversarial_proposal_prob": 0.0, "attack_mode": "mixed", "lifecycle_attack_prob": 0.20, "lifecycle_attack_kind": "unauthorized_degradation"}),
        ("A4_remote_right_overspend", {"adversarial_proposal_prob": 0.20, "attack_mode": "remote_right_overspend", "partition_start_prob": 0.18, "lifecycle_attack_prob": 0.0}),
        ("A5_underdeclared_liability", {"adversarial_proposal_prob": 0.20, "attack_mode": "underdeclared_bound", "adversarial_cost_multiplier": 2.0, "lifecycle_attack_prob": 0.0}),
        ("mixed", {"version_replay_prob": 0.10, "adversarial_proposal_prob": 0.20, "attack_mode": "mixed", "lifecycle_attack_prob": 0.05, "lifecycle_attack_kind": "mixed"}),
    ]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    last_params = make_params(args)
    for attack_name, overrides in configs:
        params = make_params(args, **overrides)
        last_params = params
        summary, raw = run_point("security_attacks", params, extra_trace_count(args), args.seed + 85_000, POLICIES, {"attack": attack_name, **overrides})
        for row in summary:
            add_primary_attack_metrics(row, attack_name, summary=True)
        for row in raw:
            add_primary_attack_metrics(row, attack_name, summary=False)
        rows.extend(summary)
        raw_rows.extend(raw)
    write_csv(exp / "security_attacks_summary.csv", rows)
    write_csv(exp / "security_attacks_raw.csv", raw_rows)
    write_json(exp / "security_attacks.json", {"summary": rows, "raw_file": "security_attacks_raw.csv"})
    write_metadata(exp, "security_attacks", args, last_params, extra_trace_count(args), {"attacks": [name for name, _ in configs]})




def run_commit_guard_with_capability_override(
    params: Params,
    traces: int,
    seed: int,
    override: dict[str, object],
    progress_name: str = "ablation",
) -> list[PolicyResult]:
    original = POLICY_CAPABILITIES["commit_guard"]
    POLICY_CAPABILITIES["commit_guard"] = replace(original, **override)
    results: list[PolicyResult] = []
    progress = ProgressBar(f"{progress_name}: {traces} traces x 1 policy", traces, enabled=PROGRESS_ENABLED)
    try:
        for trace_index in range(traces):
            trace = generate_trace(params, seed + trace_index)
            results.append(simulate_policy("commit_guard", trace, params))
            progress.update()
    finally:
        progress.close()
        POLICY_CAPABILITIES["commit_guard"] = original
    return results


def run_ablation_pair(
    params: Params,
    traces: int,
    seed: int,
    override: dict[str, object],
    progress_name: str = "ablation",
) -> tuple[list[PolicyResult], list[PolicyResult]]:
    original = POLICY_CAPABILITIES["commit_guard"]
    ablated = replace(original, **override)
    full_results: list[PolicyResult] = []
    ablated_results: list[PolicyResult] = []
    progress = ProgressBar(f"{progress_name}: {traces} traces x 2 variants", traces * 2, enabled=PROGRESS_ENABLED)
    try:
        for trace_index in range(traces):
            trace = generate_trace(params, seed + trace_index)
            POLICY_CAPABILITIES["commit_guard"] = original
            full_results.append(simulate_policy("commit_guard", trace, params))
            progress.update()
            POLICY_CAPABILITIES["commit_guard"] = ablated
            ablated_results.append(simulate_policy("commit_guard", trace, params))
            progress.update()
    finally:
        progress.close()
        POLICY_CAPABILITIES["commit_guard"] = original
    return full_results, ablated_results


def ablation_policy_suffix(name: str) -> str:
    return name.lower().replace("-", "minus_").replace(" ", "_")


def add_ablation_summary_aliases(summary: dict[str, object]) -> None:
    summary["replay_success_mean"] = summary.get("version_replay_accepted_mean", 0.0)
    summary["replacement_violation_mean"] = summary.get("replacement_before_release_violations_mean", 0.0)
    summary["illegal_release_mean"] = summary.get("release_violations_mean", 0.0)


def ablation_paired_rows(
    scenario: str,
    ablation: str,
    full_results: list[PolicyResult],
    ablated_results: list[PolicyResult],
    metrics: list[str],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for metric in metrics:
        full_values: list[float] = []
        ablated_values: list[float] = []
        diffs: list[float] = []
        for full_result, ablated_result in zip(full_results, ablated_results):
            full_value = numeric_cell(result_to_row(full_result).get(metric))
            ablated_value = numeric_cell(result_to_row(ablated_result).get(metric))
            if full_value is None or ablated_value is None:
                continue
            full_values.append(full_value)
            ablated_values.append(ablated_value)
            diffs.append(ablated_value - full_value)
        if not diffs:
            continue
        delta_mean = mean(diffs)
        margin = student_t_ci95(diffs)
        rows.append(
            {
                "scenario": scenario,
                "ablation": ablation,
                "metric": metric,
                "full_mean": mean(full_values),
                "ablated_mean": mean(ablated_values),
                "mean_delta": delta_mean,
                "sd_delta": stdev(diffs),
                "ci95_low": delta_mean - margin if margin is not None else None,
                "ci95_high": delta_mean + margin if margin is not None else None,
                "ci95_method": "paired Student-t",
                "paired_traces": len(diffs),
            }
        )
    return rows


def ablation_experiment(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "ablation")
    configs = [
        ("-Witness", "crash stress", {"has_witness_replication": False}, {"crash_prob": 0.02, "witness_count": 2}, ["forgotten_commitments", "certificates_lost", "orphaned_physical_liability"]),
        ("-Version", "replay attack", {"has_monotonic_version": False}, {"version_replay_prob": 0.20}, ["version_replay_accepted", "rollback_silent_unbacking", "stale_ownership"]),
        ("-LocalRights", "partition + remote-right attack", {"has_local_resource_ownership": False}, {"partition_start_prob": 0.18, "adversarial_proposal_prob": 0.20, "attack_mode": "remote_right_overspend"}, ["remote_overspend_success", "ownership_conflicts", "remote_double_spend_events"]),
        ("-Transform", "handoff stress", {"has_replacement_before_release": False}, {"handoff_prob": 0.20, "handoff_crash_prob": 0.02}, ["replacement_before_release_violations", "unbacked_window_count", "silent_unbacking"]),
        ("-Degradation", "high resource pressure", {"has_policy_degradation": False}, {"proposal_prob": 0.75, "self_recovery_guarantee": 20.0}, ["rescued", "rejected", "blocked", "self_recovery_degradation_events", "reserve_efficiency"]),
        ("-AT-RISK", "inflation stress", {"has_at_risk_state": False}, {"inflation_prob": 0.20}, ["silent_unbacking", "release_violations", "ruptures", "at_risk", "residual_after_rupture"]),
    ]
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    paired_rows: list[dict[str, object]] = []
    traces = extra_trace_count(args)
    seed = args.seed + 95_000
    for name, scenario, override, param_overrides, metrics in configs:
        params = make_params(args, **param_overrides)
        full_results, ablated_results = run_ablation_pair(params, traces, seed, override, progress_name=f"ablation {name}")

        full_summary = aggregate("commit_guard", full_results)
        full_summary["policy"] = f"commit_guard_full_matched_{ablation_policy_suffix(name)}"
        full_summary["label"] = "COMMITGUARD Full matched"
        full_summary["variant"] = "Full-matched"
        full_summary["ablation"] = name
        full_summary["scenario"] = scenario
        add_ablation_summary_aliases(full_summary)
        rows.append(annotate_rows([full_summary], "ablation", seed, traces, params, {"ablation": name, "scenario": scenario, "variant": "Full-matched"})[0])

        ablated_summary = aggregate("commit_guard", ablated_results)
        ablated_summary["policy"] = f"commit_guard_{ablation_policy_suffix(name)}"
        ablated_summary["label"] = f"COMMITGUARD {name}"
        ablated_summary["variant"] = "Ablated"
        ablated_summary["ablation"] = name
        ablated_summary["scenario"] = scenario
        add_ablation_summary_aliases(ablated_summary)
        rows.append(annotate_rows([ablated_summary], "ablation", seed, traces, params, {"ablation": name, "scenario": scenario, "variant": "Ablated"})[0])

        paired_rows.extend(ablation_paired_rows(scenario, name, full_results, ablated_results, metrics))

        for trace_id, (full_result, ablated_result) in enumerate(zip(full_results, ablated_results)):
            full_raw = result_to_row(full_result)
            full_raw["trace"] = trace_id
            full_raw["policy"] = f"commit_guard_full_matched_{ablation_policy_suffix(name)}"
            full_raw["policy_label"] = "COMMITGUARD Full matched"
            full_raw["variant"] = "Full"
            full_raw["ablation"] = name
            full_raw["scenario"] = scenario
            raw_rows.extend(annotate_rows([full_raw], "ablation", seed, traces, params, {"ablation": name, "scenario": scenario, "variant": "Full"}))

            ablated_raw = result_to_row(ablated_result)
            ablated_raw["trace"] = trace_id
            ablated_raw["policy"] = f"commit_guard_{ablation_policy_suffix(name)}"
            ablated_raw["policy_label"] = f"COMMITGUARD {name}"
            ablated_raw["variant"] = "Ablated"
            ablated_raw["ablation"] = name
            ablated_raw["scenario"] = scenario
            raw_rows.extend(annotate_rows([ablated_raw], "ablation", seed, traces, params, {"ablation": name, "scenario": scenario, "variant": "Ablated"}))
    write_csv(exp / "ablation.csv", rows)
    write_csv(exp / "ablation_raw.csv", raw_rows)
    write_csv(exp / "ablation_paired.csv", paired_rows)
    write_json(exp / "ablation.json", {"summary": rows, "raw_file": "ablation_raw.csv", "paired_file": "ablation_paired.csv"})
    write_metadata(exp, "ablation", args, make_params(args), traces, {"ablations": [c[0] for c in configs], "matched_full_baseline": True})






def scale_experiment(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "scalability")
    rows: list[dict[str, object]] = []
    raw_rows: list[dict[str, object]] = []
    robot_values = [5, 10, 20, 40, 80, 100]
    rho_values = [0.025, 0.05, 0.10]
    last_params = make_params(args)
    for robots in robot_values:
        for rho in rho_values:
            params = make_params(args, robots=robots, proposal_mode="poisson_per_robot", proposal_load_per_robot=rho)
            last_params = params
            summary, raw = run_point("scalability", params, extra_trace_count(args), args.seed + 100_000, ["central_commit_aware", "commit_guard"], {"robots": robots, "rho": rho, "proposal_load_per_robot": rho})
            rows.extend(summary)
            raw_rows.extend(raw)
            write_csv(exp / "scalability.csv", rows)
            write_csv(exp / "scale.csv", rows)
            write_csv(exp / "scalability_raw.csv", raw_rows)
            print(f"scalability complete: robots={robots}, rho={rho}, traces={extra_trace_count(args)}", flush=True)
    write_csv(exp / "scalability.csv", rows)
    write_csv(exp / "scale.csv", rows)
    write_csv(exp / "scalability_raw.csv", raw_rows)
    write_json(exp / "scalability.json", {"summary": rows, "raw_file": "scalability_raw.csv"})
    write_json(exp / "scale.json", {"summary": rows, "raw_file": "scalability_raw.csv"})
    write_metadata(exp, "scalability", args, last_params, extra_trace_count(args), {"robots": robot_values, "rho": rho_values})


def percentile_us(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    xs = sorted(values)
    idx = min(len(xs) - 1, max(0, math.ceil(q * len(xs)) - 1))
    return xs[idx] * 1_000_000.0


def median_microseconds(values: list[float]) -> float:
    return percentile_us(values, 0.50)


def accounting_microbench(args: argparse.Namespace, out_dir: Path) -> None:
    exp = experiment_dir(out_dir, "microbenchmark")
    rng = random.Random(args.seed + 40_000)
    sizes = [10, 100, 1_000, 10_000, 100_000]
    rows: list[dict[str, object]] = []
    progress = ProgressBar("microbenchmark", len(sizes) * args.bench_repeats, enabled=PROGRESS_ENABLED)
    for size in sizes:
        commitments = [(rng.randrange(10), rng.randrange(10), rng.randrange(10), rng.uniform(3, 18)) for _ in range(size)]
        participants = (1, 4, 7)
        local_rights = {p: 100.0 for p in participants}
        local_req = {p: rng.uniform(3, 18) for p in participants}
        full_times: list[float] = []
        local_times: list[float] = []
        repeats = args.bench_repeats
        for _ in range(repeats):
            start = time.perf_counter()
            total = 0.0
            for a, b, c, demand in commitments:
                if a in participants or b in participants or c in participants:
                    total += demand
            _ = total <= 300.0
            full_times.append(time.perf_counter() - start)
            start = time.perf_counter()
            _ = all(local_rights[p] >= local_req[p] for p in participants)
            local_times.append(time.perf_counter() - start)
            progress.update()
        global_median = median_microseconds(full_times)
        local_median = median_microseconds(local_times)
        rows.append({"experiment": "microbenchmark", "seed": args.seed, "repeats": repeats, "outstanding_commitments": size, "global_scan_median_us": global_median, "global_scan_mean_us": mean(full_times) * 1_000_000.0, "global_scan_p95_us": percentile_us(full_times, 0.95), "global_scan_p99_us": percentile_us(full_times, 0.99), "participant_local_median_us": local_median, "participant_local_mean_us": mean(local_times) * 1_000_000.0, "participant_local_p95_us": percentile_us(local_times, 0.95), "participant_local_p99_us": percentile_us(local_times, 0.99), "full_scan_median_us": global_median, "local_check_median_us": local_median, "speedup_median": global_median / max(local_median, 1e-9), "speedup": global_median / max(local_median, 1e-9)})
    progress.close()
    write_csv(exp / "accounting_microbench.csv", rows)
    write_json(exp / "accounting_microbench.json", rows)
    write_metadata(exp, "microbenchmark", args, make_params(args), args.bench_repeats, {"outstanding_commitments": sizes})


























INVARIANT_SUMMARY_COLUMNS = [
    "experiment",
    "trace_id",
    "policy",
    "invariant_violations",
    "capacity_violations",
    "double_spend_violations",
    "backing_violations",
    "version_violations",
    "release_violations",
    "certificate_hash_violations",
    "replacement_before_release_violations",
    "replay_accepted",
]


def invariant_raw_files(out_dir: Path) -> list[Path]:
    excluded_names = {
        "paired_analysis.csv",
        "default_paired_analysis.csv",
        "policy_capabilities.csv",
        "invariant_summary.csv",
        "invariant_summary_aggregate.csv",
        "ablation.csv",
        "accounting_microbench.csv",
        "microbenchmark.csv",
        "final_default_raw.csv",  # delivery alias, not another independent trace file
    }
    paths: list[Path] = []
    for csv_path in sorted(out_dir.rglob("*_raw.csv")):
        if "statistics" in csv_path.relative_to(out_dir).parts:
            continue
        if csv_path.name in excluded_names:
            continue
        if csv_path.name.endswith("_summary.csv"):
            continue
        paths.append(csv_path)
    return paths


def invariant_number(row: dict[str, str], key: str) -> float:
    value = numeric_cell(row.get(key))
    return 0.0 if value is None else value


def write_invariant_summary(out_dir: Path) -> None:
    stats = out_dir / "statistics"
    stats.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, object]] = []
    aggregate: dict[tuple[str, str], dict[str, object]] = {}
    metric_columns = INVARIANT_SUMMARY_COLUMNS[3:]
    for csv_path in invariant_raw_files(out_dir):
        try:
            with csv_path.open("r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                if "invariant_violations" not in (reader.fieldnames or []):
                    continue
                for row in reader:
                    if "policy" not in row:
                        continue
                    experiment = row.get("experiment", csv_path.parent.name)
                    policy = row.get("policy", "")
                    out_row = {
                        "experiment": experiment,
                        "trace_id": row.get("trace_id", row.get("trace", "")),
                        "policy": policy,
                        "invariant_violations": row.get("invariant_violations", ""),
                        "capacity_violations": row.get("capacity_violations", ""),
                        "double_spend_violations": row.get("double_spend_violations", ""),
                        "backing_violations": row.get("backing_violations", ""),
                        "version_violations": row.get("version_violations", ""),
                        "release_violations": row.get("release_violations", ""),
                        "certificate_hash_violations": row.get("certificate_hash_violations", ""),
                        "replacement_before_release_violations": row.get("replacement_before_release_violations", ""),
                        "replay_accepted": row.get("replay_accepted", ""),
                    }
                    rows.append(out_row)
                    key = (experiment, policy)
                    if key not in aggregate:
                        aggregate[key] = {"experiment": experiment, "policy": policy, "raw_rows": 0}
                        for metric in metric_columns:
                            aggregate[key][f"{metric}_total"] = 0.0
                            aggregate[key][f"{metric}_max"] = 0.0
                    aggregate[key]["raw_rows"] = int(aggregate[key]["raw_rows"]) + 1
                    for metric in metric_columns:
                        value = invariant_number(row, metric)
                        aggregate[key][f"{metric}_total"] = float(aggregate[key][f"{metric}_total"]) + value
                        aggregate[key][f"{metric}_max"] = max(float(aggregate[key][f"{metric}_max"]), value)
        except UnicodeDecodeError:
            continue
    write_csv(stats / "invariant_summary.csv", rows)
    write_json(stats / "invariant_summary.json", rows)
    aggregate_rows = []
    for key in sorted(aggregate):
        aggregate_row = aggregate[key]
        raw_count = max(1, int(aggregate_row["raw_rows"]))
        for metric in metric_columns:
            aggregate_row[f"{metric}_mean"] = float(aggregate_row[f"{metric}_total"]) / raw_count
        aggregate_rows.append(aggregate_row)
    write_csv(stats / "invariant_summary_aggregate.csv", aggregate_rows)
    write_json(stats / "invariant_summary_aggregate.json", aggregate_rows)
    default_dir = out_dir / "default"
    paired = default_dir / "paired_analysis.csv"
    if paired.exists():
        (stats / "paired_analysis.csv").write_text(paired.read_text(encoding="utf-8"), encoding="utf-8")
        paired_json = default_dir / "paired_analysis.json"
        if paired_json.exists():
            (stats / "paired_analysis.json").write_text(paired_json.read_text(encoding="utf-8"), encoding="utf-8")


def print_default_summary(out_dir: Path) -> None:
    path = out_dir / "default_summary.csv"
    if not path.exists():
        path = out_dir / "default" / "default_summary.csv"
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    print("\nDefault workload mean per trace")
    print("policy,rescued,missed,rejected,failed,deadline,unfinished,silent,blocked,at_risk,violations")
    for row in rows:
        print(
            f"{row['label']},"
            f"{float(row['rescued_mean']):.2f},"
            f"{float(row['missed_mean']):.2f},"
            f"{float(row['rejected_mean']):.2f},"
            f"{float(row['failed_mean']):.2f},"
            f"{float(row['deadline_missed_mean']):.2f},"
            f"{float(row['unfinished_mean']):.2f},"
            f"{float(row['silent_unbacking_mean']):.2f},"
            f"{float(row['blocked_mean']):.2f},"
            f"{float(row['at_risk_mean']):.2f},"
            f"{float(row['invariant_violations_mean']):.2f}"
        )

def main() -> int:
    parser = argparse.ArgumentParser(
        description="Reproduce the formal COMMITGUARD experiments reported in paper Sections 6.1--6.7."
    )
    parser.add_argument(
        "--experiment",
        choices=[
            "default", "partition", "inflation", "crash_witness", "handoff",
            "security_attacks", "ablation", "scale", "microbench", "all",
        ],
        default="default",
    )
    parser.add_argument("--traces", type=int, default=500)
    parser.add_argument("--sweep-traces", type=int, default=200)
    parser.add_argument("--extra-traces", type=int, default=200)
    parser.add_argument("--bench-repeats", type=int, default=200)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--out-dir", type=Path, default=Path("results"))
    parser.add_argument("--no-progress", action="store_true")
    parser.add_argument("--robots", type=int, default=Params.robots)
    parser.add_argument("--proposal-prob", type=float, default=Params.proposal_prob)
    parser.add_argument("--proposal-mode", choices=["bernoulli", "poisson_per_robot"], default=Params.proposal_mode)
    parser.add_argument("--proposal-load-per-robot", type=float, default=Params.proposal_load_per_robot)
    parser.add_argument("--partition-prob", type=float, default=Params.partition_start_prob)
    parser.add_argument("--partition-duration-min", type=int, default=Params.partition_duration_min)
    parser.add_argument("--partition-duration-max", type=int, default=Params.partition_duration_max)
    parser.add_argument("--inflation-prob", type=float, default=Params.inflation_prob)
    parser.add_argument("--crash-prob", type=float, default=Params.crash_prob)
    parser.add_argument("--self-recovery", type=float, default=Params.self_recovery_guarantee)
    parser.add_argument("--witness-count", type=int, default=Params.witness_count)
    parser.add_argument("--certificate-ack-delay-epochs", type=int, default=Params.certificate_ack_delay_epochs)
    parser.add_argument("--retire-recovery-wait-epochs", type=int, default=Params.retire_recovery_wait_epochs)
    parser.add_argument("--handoff-prob", type=float, default=Params.handoff_prob)
    parser.add_argument("--handoff-replacement-scarcity", type=float, default=Params.handoff_replacement_scarcity)
    parser.add_argument("--handoff-crash-prob", type=float, default=Params.handoff_crash_prob)
    parser.add_argument("--handoff-old-crash-prob", type=float, default=Params.handoff_old_crash_prob)
    parser.add_argument("--handoff-partition-after-certificate-prob", type=float, default=Params.handoff_partition_after_certificate_prob)
    parser.add_argument("--version-replay-prob", type=float, default=Params.version_replay_prob)
    parser.add_argument("--lifecycle-attack-prob", type=float, default=Params.lifecycle_attack_prob)
    parser.add_argument("--lifecycle-attack-kind", choices=["mixed", "silent_cancellation", "unauthorized_degradation"], default=Params.lifecycle_attack_kind)
    parser.add_argument("--adversarial-proposal-prob", type=float, default=Params.adversarial_proposal_prob)
    parser.add_argument("--adversarial-cost-multiplier", type=float, default=Params.adversarial_cost_multiplier)
    parser.add_argument(
        "--attack-mode",
        choices=["mixed", "duplicate_participant", "impossible_cost", "underdeclared_bound",
                 "unauthorized_degradation", "remote_right_overspend", "silent_cancellation",
                 "malicious_underreport"],
        default=Params.attack_mode,
    )
    parser.add_argument("--bound-error", type=float, default=Params.bound_error)
    parser.add_argument("--underreport-fraction", type=float, default=Params.underreport_fraction)
    parser.add_argument("--min-carrier-low", type=float, default=Params.min_carrier_low)
    parser.add_argument("--min-carrier-medium", type=float, default=Params.min_carrier_medium)
    parser.add_argument("--min-carrier-high", type=float, default=Params.min_carrier_high)
    parser.add_argument("--min-support-low", type=float, default=Params.min_support_low)
    parser.add_argument("--min-support-medium", type=float, default=Params.min_support_medium)
    parser.add_argument("--min-support-high", type=float, default=Params.min_support_high)
    parser.add_argument("--deadline-tightness", type=float, default=Params.deadline_tightness)
    parser.add_argument("--evidence-delay-max", type=int, default=Params.evidence_delay_max)
    parser.add_argument("--evidence-missing-prob", type=float, default=Params.evidence_missing_prob)
    parser.add_argument("--evidence-invalid-prob", type=float, default=Params.evidence_invalid_prob)
    parser.add_argument("--contract-degraded-carrier-requirement", type=float, default=Params.contract_degraded_carrier_requirement)
    parser.add_argument("--contract-degraded-support-requirement", type=float, default=Params.contract_degraded_support_requirement)
    args = parser.parse_args()

    global PROGRESS_ENABLED
    PROGRESS_ENABLED = not args.no_progress
    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    write_capability_table(out_dir)

    experiments = {
        "default": default_workload,
        "partition": partition_sweep,
        "inflation": inflation_sweep,
        "crash_witness": crash_witness_sweep,
        "handoff": handoff_stress,
        "security_attacks": security_attacks_experiment,
        "ablation": ablation_experiment,
        "scale": scale_experiment,
        "microbench": accounting_microbench,
    }
    selected = list(experiments) if args.experiment == "all" else [args.experiment]
    for name in selected:
        experiments[name](args, out_dir)

    write_invariant_summary(out_dir)
    print(f"Wrote results to: {out_dir}")
    if args.experiment in {"default", "all"}:
        print_default_summary(out_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
