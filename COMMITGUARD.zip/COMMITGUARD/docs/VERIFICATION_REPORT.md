# Verification report

This report compares code/data recomputation with the final paper PDF. No source data are modified.

| Paper table | Status | Notes |
|---|---:|---|
| Table 1 | **PASS** | All reported cells reproduced at displayed precision. |
| Table 2 | **PASS** | All reported cells reproduced at displayed precision. |
| Table 3 | **PASS** | All reported cells reproduced at displayed precision. |
| Table 4 | **PASS** | All reported cells reproduced at displayed precision. |
| Table 5 | **PASS** | All reported cells reproduced at displayed precision. |
| Table 6 | **PASS** | All reported cells reproduced at displayed precision. |
| Table 7 | **PASS** | All reported cells reproduced at displayed precision. |
| Table 8 | **PASS** | All reported cells reproduced at displayed precision. |
| Table 9 | **PASS** | All reported cells reproduced at displayed precision. |
| Table 10 | **NOT VERIFIED** | Displayed cells match the bundled aggregate benchmark CSV, but the 200 primitive timing samples per size were not preserved; independent median/ratio recomputation is NOT VERIFIED. |

## Important scope limits

- Table 10 is reproduced from a formal aggregate timing file. The original 200 per-size timing samples are not bundled and therefore cannot be independently re-aggregated.
- Table 9 times measure Python discrete-event simulation runtime, not network, consensus, robot motion, or physical actuation latency.
- The simulator is a software-only model. It does not implement a real asynchronous distributed deployment.

## Default paired checks

- Physical Completed = Rescued + Retire Pending at End: 500/500 traces.
- Default beyond-bound record-loss total: 1 event across 500 COMMITGUARD traces.

## Data integrity

- Manifest: **PASS**
- CRN audit: `{"default": {"comparable_central_rows": 500, "trace_hash_mismatches": 0}, "partition": {"comparable_central_rows": 1600, "trace_hash_mismatches": 0}, "handoff": {"comparable_central_rows": 1200, "trace_hash_mismatches": 0}, "security_attacks": {"comparable_central_rows": 800, "trace_hash_mismatches": 0}, "scalability": {"comparable_central_rows": 1600, "trace_hash_mismatches": 0}}`
