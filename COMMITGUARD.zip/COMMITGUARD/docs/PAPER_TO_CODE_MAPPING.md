# Paper-to-code mapping

| Paper section/table | Formal experiment | CLI entry | Core functions | Bundled formal data |
|---|---|---|---|---|
| §6.1 / Table 1 | setup | all entries | `Params`, `weighted_criticality()`, `generate_trace()`, `run_policies()`, `paired_analysis()` | code/configuration |
| §6.2 / Table 2 | default workload | `--experiment default` | `default_workload()`, `simulate_policy()`, `finalize_result()` | `data/formal/default/` |
| §6.3 / Table 3 | partitions | `--experiment partition` | `partition_sweep()`, certificate blocking and pending-lock paths | `data/formal/partition/` |
| §6.3 / Table 4 | liability inflation | `--experiment inflation` | `inflation_sweep()`, `attempt_top_up()`, `transition_at_risk()` | `data/formal/inflation/raw.csv` |
| §6.4 / Table 5 | crash/witness | `--experiment crash_witness` | `crash_witness_sweep()`, durable-certificate oracle | `data/formal/crash_witness/raw.csv` |
| §6.4 / Table 6 | handover | `--experiment handoff` | `handoff_stress()`, `attempt_handoff()` | `data/formal/handoff/` |
| §6.5 / Table 7 | A1--A4 attacks | `--experiment security_attacks` | `security_attacks_experiment()`, `add_primary_attack_metrics()` | `data/formal/security_attacks/` |
| §6.6 / Table 8 | six ablations | `--experiment ablation` | `ablation_experiment()`, capability override helpers | `data/formal/ablation/raw.csv` |
| §6.7 / Table 9 | scalability | `--experiment scale` | `scale_experiment()`, `simulate_policy()` timing | `data/formal/scalability/` |
| §6.7 / Table 10 | ledger check microbenchmark | `--experiment microbench` | `accounting_microbench()` | `data/formal/microbenchmark/accounting_microbench.csv` |

## Five policies

The packaged `POLICY_CAPABILITIES` table and `simulate_policy()` retain exactly the five formal comparisons: Immediate-only, Static worst-case reserve, Priority-cancel, Central commit-aware, and COMMITGUARD. The package does not contain the deleted Section 6.8 comparison policies.

## Lifecycle and safety mechanism mapping

| Mechanism | Main code path | Evaluation evidence |
|---|---|---|
| Mint and pending reservation | admission functions, `publish_certificate()`, effective/pending reservation accounting | Tables 2--4 and attack/ablation data |
| Inflate/top-up | `attempt_top_up()` | Table 4 |
| AT-RISK | `transition_at_risk()` | Tables 4 and 8 |
| Transform/handover | `attempt_handoff()`, replacement-before-release checks | Tables 6 and 8 |
| Degrade/self-recovery adjustment | explicit guarantee-level transitions, capability ablation | Table 8 `SelfRecovery` row; this is not evidence for a general contract Degrade deployment |
| Retire/discharge | `transition_discharge()`, certificate confirmation and pending recovery | Tables 2--6 |
| Local resource rights | participant-owned reservation accounting and remote-right rejection | Tables 7 and 8 |
| Witness persistence/versioning | certificate snapshots, version history, durable certificate oracle | Tables 5, 7, and 8 |
| Invariants and physical Oracle | `check_invariants()`, physical-history counters, durable oracle | Tables 2, 5--8 |

## Scope boundary

This artifact demonstrates the paper's discrete-event implementation and formal data pipeline. Certificate confirmation is a modeled state-machine abstraction. It is not evidence of a production-grade distributed consensus implementation, real trusted sensing hardware, or end-to-end robot deployment.
