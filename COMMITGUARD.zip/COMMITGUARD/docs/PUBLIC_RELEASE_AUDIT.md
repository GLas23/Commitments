# Public release audit

## Scope and archive safety

- Files scanned before cleanup: 47. Files retained in the final ZIP: 45.
- ZIP entry paths, link modes, encryption flags, executable extensions, nested archives, and archive comments were inspected before extraction. No unsafe entry was found.
- The final ZIP contains one top-level directory. File timestamps are normalized at packaging.
- No PDF, image, Office, notebook, or other media asset is present in this package; no EXIF or document author metadata required removal.

## Identity and sensitive information

- Current-author identity, affiliation, contact address, ORCID, student identifier, personal repository, and private host scans: no match in the retained package.
- Credential value, private key, database connection, and authentication token scans: no match in the retained package. No credential rotation is indicated by this scan.
- One `.gitignore` rule names a Python bytecode cache directory; it is a portable ignore pattern and no cache directory is packaged.
- No Git history or author metadata is included. No third-party code or third-party copyright notice is included; none was removed.
- These are bounded static scan findings, not a guarantee against every possible identity inference.

## Editorial cleanup

- Rewrote the module description, README passages, and two generated metadata labels that described internal development history. Executable simulator AST is identical after excluding these documentation-only constants.
- Clarified the absence of an open-source license without asserting an unverified copyright owner or year.
- Removed three packaging-only audit files. Their removal does not affect simulation, formal data aggregation, or tests.
- No unrelated AI tool marker, prompt residue, or fabricated output was found in the retained source and documentation. This audit does not make a claim about AI use during research or drafting; any required disclosure remains the submitter's responsibility.

## Reproducibility checks

- All 14 formal CSV files retain their original SHA-256 values. Existing result JSON/Markdown files also retain their hashes after recalculation.
- Python syntax and import checks, six unit tests, and the default smoke test passed in the cleaned copy.
- CRN comparison between formal input runs: zero trace SHA-256 mismatches across all recorded comparison groups.
- Tables 1–9: PASS against the final paper at displayed precision. Table 10: NOT VERIFIED from primitive observations; the published cells match the retained aggregate benchmark CSV, but the individual timing samples are unavailable.
- No experiment parameter, random seed, statistic, physical metric definition, or simulation algorithm was changed. New reruns emit clearer metadata labels; existing formal data and statistical results are unchanged.

## Remaining publication condition

The project did not supply an open-source license. This ZIP is technically cleaned and reproducible, but public redistribution under an open-source license requires a rights-holder decision. Table 10's raw timing observations remain unavailable for independent median recalculation.
