# Metric definitions

All metrics are per trace unless a table explicitly reports a total. Line numbers refer to the packaged `src/commitguard_sim.py` and are also discoverable by function name.

| Metric | Raw field | Implemented meaning | Primary implementation |
|---|---|---|---|
| Physical Completed | `physical_completed` | A modeled physical execution reaches its settlement event and consumes its actual settlement requirement. It precedes protocol-level Retire confirmation. | `settle_commitment()`; counter increment near line 3720 |
| Rescued | `rescued` | The policy's successful terminal outcome. For certificate policies it requires committed discharge/Retire; for simpler baselines it follows their modeled terminal rule. | `settle_commitment()` and `transition_discharge()` near lines 2600--2700 and 3730--3750 |
| Retire Pending at End | `retire_pending_at_end` | Physical completion occurred but a certificate-protected Retire remained unresolved when the finite observation window ended. | end-of-trace classification near line 4325 |
| Silent Unbacking | `silent_unbacking` | Physical responsibility remains while backing/coverage disappears without an authorized transition or explicit exposed failure. This is driven by modeled physical history, not merely an internal assertion. | cancellation, crash, settlement, and invariant-oracle paths; representative increments near lines 2240--2530 and 3610--3670 |
| Internal Check Violations | `invariant_violations` | Observations raised by the policy-specific implementation invariant checker. The counter is not synonymous with the independent physical-history oracle and may count a persistent state at more than one check. | `check_invariants()` near line 3930 |
| Admission Blocking | `blocked` | Admission or protected lifecycle progress is conservatively refused because required view, confirmation, persistence, resource, or protected state is unavailable. | `mark_blocked()` and protected transition paths |
| Physical Underbacking | `physical_underbacking_events` | The true current physical requirement exceeds surviving backing after exogenous loss or demand change. It can coexist with semantic responsibility coverage and therefore does not imply Silent Unbacking. | physical oracle update near lines 3620--3770 |
| AT-RISK | `at_risk` | An explicit protected state indicating that the currently promised guarantee is no longer sufficiently backed. It retains the responsibility and any valid backing. | `transition_at_risk()` near line 2520; inflation/crash paths |
| Reservation Efficiency | `reserve_efficiency` | `reserved_backing_consumed / (reserved_backing_consumed + reserved_backing_released_unused)`. Undefined for Immediate-only because it has no future reservation. | `finalize_result()` near lines 4350--4395 |
| Successful Top-up | `top_up_success` | Incremental backing needed after liability growth is safely obtained and incorporated. | `attempt_top_up()` near line 2910 |
| Failed Top-up | `top_up_failed` | The increment cannot be safely established; it does not silently remove the original obligation. | `attempt_top_up()` |
| Forgotten Commitment | `forgotten` | A live commitment has no surviving visible current certificate record in the modeled storage state. | witness/crash processing near lines 3600--3900 |
| Record Loss Beyond Bound | `record_loss_beyond_fault_model` | Durable record loss after failures exceed the certificate's recorded tolerated crash bound. It is distinct from within-bound P3 failure. | durable-certificate oracle and finalization near lines 500--610 and 4535--4555 |
| Successful Handover | `handoff_success` | A configured successor/replacement path is accepted after replacement backing checks; the sweep also includes recovery-triggered paths independent of the active handoff probability. | `attempt_handoff()` near line 3250 |
| Blocked Handover | `handoff_blocked` | A handover attempt cannot safely confirm replacement/ownership conditions and retains the predecessor protection. | `attempt_handoff()` |
| Premature Release | `replacement_before_release_violations` | Old backing is released before valid replacement or discharge. | `attempt_handoff()` checks near lines 3325--3350 |
| Attack attempts/successes | `primary_attack_attempts`, `primary_attack_successes` | Scenario-specific valid denominator and successful unsafe state transition for A1--A4. Denominators are policy-specific and are never replaced by one global count. | `add_primary_attack_metrics()` and `security_attacks_experiment()` |
| Runtime | `simulation_runtime_s` | Wall-clock time of one Python discrete-event trace for the policy. It excludes real network/robot delays. | `simulate_policy()`/`scale_experiment()` |

## Statistical units

- Tables 2--6, 8, and 9 report arithmetic means over traces at a fixed configuration.
- Table 7 reports integer totals across valid attack attempts and success ratios derived from those totals.
- Paired comparisons first subtract policies within the same `trace_id`, then compute the sample mean, sample SD, and two-sided 95% Student-t interval.
- Table 10 reports the median of 200 in-process operation timings per size. The bundled formal file contains the aggregate rows, not the individual 200 timing observations.

## Important distinctions

`Physical Completed` is not a synonym for committed Retire. `Silent Unbacking` is not a synonym for resource shortage. `Forgotten` is not a synonym for beyond-bound durable record loss. Internal invariant observations and physical-history Oracle observations have different scope and must not be added together as though they were disjoint events.
