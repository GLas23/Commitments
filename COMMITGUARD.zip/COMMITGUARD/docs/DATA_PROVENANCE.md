# Data provenance

## Selection rule

The final paper PDF is the authority for experimental scope. Only Sections 6.1--6.7 and Tables 1--10 are packaged. Formal raw data were copied into this independent directory without changing any numeric cell. Where a source CSV contained rows outside the final tables, only the final-paper rows were selected; original files remain untouched outside this artifact.

## Sources

| Experiment | Non-Central source | Central commit-aware source | Packaged selection |
|---|---|---|---|
| default | frozen formal run | fixed-Central formal run | 500 traces × 5 policies |
| partition | frozen formal run | fixed-Central formal run | 8 probabilities × 200 × 2 policies |
| inflation | frozen formal run | same run | 9 probabilities × 200 × 3 policies |
| crash/witness | frozen formal run | not applicable | 6 crash probabilities × 5 witness counts × 200 |
| handover | frozen formal run | fixed-Central formal run | `handoff_sweep` rows only |
| lifecycle attacks | frozen formal run | fixed-Central formal run | A1--A4 rows only |
| ablation | frozen formal run | not applicable | 6 ablations × Full/Ablated × 200 |
| scalability | frozen formal run | fixed-Central formal run | the eight Table 9 points |
| ledger microbenchmark | frozen aggregate | not applicable | five aggregate rows, each reporting 200 repeats |

The fixed-Central source is used only for `central_commit_aware`. Other policies retain their frozen rows. `scripts/reproduce_tables.py::selected_rows()` implements this policy-selective merge explicitly.

## Integrity

`data/SOURCE_INDEX.json` records the SHA-256 of every selected source, script, configuration, test, and documentation file. The manifest also records the final paper PDF hash used for scope extraction:

`73159296F63E4C13CAEDD5625D950F2A5AB5D5AE8A7B1E308289E4E9A058774E`

The PDF itself is not redistributed in this source-code artifact.

## Reproducibility and CRN

At a configuration point, policies share `trace_id` and the same exogenous `trace_sha256` where the recorded format supplies it. The generator uses named deterministic random streams so threshold sweeps do not change later random draws merely by consuming a different count of random numbers. The verifier checks compatible trace fingerprints between frozen and fixed-Central rows.

## Timing limitation

The Table 10 source is an aggregate CSV containing median, mean, p95, p99, and ratio for each size. The individual 200 measurements were not present in the final data pack. The displayed table cells therefore reproduce, but independent recalculation of medians from primitive timing samples is `NOT VERIFIED`.
