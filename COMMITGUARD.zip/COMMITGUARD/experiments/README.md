# Formal experiment map

| Directory | Simulator experiment | Paper content |
|---|---|---|
| `default` | `default` | Section 6.2, Table 2 |
| `partition` | `partition` | Section 6.3, Table 3 |
| `inflation` | `inflation` | Section 6.3, Table 4 |
| `node_failure` | `crash_witness` | Section 6.4, Table 5 |
| `handover` | `handoff` | Section 6.4, Table 6 |
| `lifecycle_attacks` | `security_attacks` | Section 6.5, Table 7 |
| `ablation` | `ablation` | Section 6.6, Table 8 |
| `scalability` | `scale` | Section 6.7, Table 9 |
| `ledger_microbenchmark` | `microbench` | Section 6.7, Table 10 |

All experiment-specific JSON files are declarative command presets. The authoritative defaults are the `Params` dataclass and CLI in `src/commitguard_sim.py`.
