#!/usr/bin/env python3
"""Run every formal experiment in an isolated output directory."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SIM = ROOT / "src" / "commitguard_sim.py"
EXPERIMENTS = ["default", "partition", "inflation", "crash_witness", "handoff", "security_attacks", "ablation", "scale", "microbench"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", type=Path, default=ROOT / "rerun_results")
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--quick", action="store_true", help="Use two traces per point and five benchmark repetitions")
    parser.add_argument("--no-progress", action="store_true")
    args = parser.parse_args()
    traces, sweep, repeats = (2, 2, 5) if args.quick else (500, 200, 200)
    for experiment in EXPERIMENTS:
        command = [sys.executable, str(SIM), "--experiment", experiment, "--seed", str(args.seed), "--traces", str(traces), "--sweep-traces", str(sweep), "--extra-traces", str(sweep), "--bench-repeats", str(repeats), "--out-dir", str(args.out_dir / experiment)]
        if args.no_progress:
            command.append("--no-progress")
        print("RUN", " ".join(command), flush=True)
        subprocess.run(command, check=True, cwd=ROOT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
