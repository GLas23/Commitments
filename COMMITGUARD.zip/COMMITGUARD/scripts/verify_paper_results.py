#!/usr/bin/env python3
"""Verify paper Tables 1--10 against code and bundled formal results."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import sys
from pathlib import Path

from reproduce_tables import DATA, ROOT, reproduce


TARGETS = ROOT / "configs" / "paper_targets.json"
REPORT = ROOT / "docs" / "VERIFICATION_REPORT.md"
OUTPUT = ROOT / "results" / "verification.json"


def load_simulator():
    path = ROOT / "src" / "commitguard_sim.py"
    spec = importlib.util.spec_from_file_location("commitguard_sim", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Unable to load simulator")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def compare(actual, expected, table: int, path: tuple[object, ...] = ()) -> list[str]:
    failures: list[str] = []
    if isinstance(expected, dict):
        if not isinstance(actual, dict):
            return [f"{path}: expected mapping"]
        for key, value in expected.items():
            if key not in actual:
                failures.append(f"{path + (key,)}: missing")
            else:
                failures.extend(compare(actual[key], value, table, path + (key,)))
        return failures
    if isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            return [f"{path}: list length/type mismatch"]
        for index, value in enumerate(expected):
            failures.extend(compare(actual[index], value, table, path + (index,)))
        return failures
    if expected is None:
        if actual is not None:
            failures.append(f"{path}: expected null, got {actual}")
        return failures
    if isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        digits = 2 if table == 10 and path and path[-1] == 2 else 3
        if round(float(actual) + 1e-12, digits) != round(float(expected), digits):
            failures.append(f"{path}: {actual} != {expected} at {digits} decimals")
        return failures
    if actual != expected:
        failures.append(f"{path}: {actual!r} != {expected!r}")
    return failures


def verify_table_1() -> list[str]:
    sim = load_simulator()
    p = sim.Params()
    expected = {
        "robots": 10, "initial_energy": 100.0, "epochs": 80, "proposal_prob": 0.55,
        "immediate_cost_min": 3.0, "immediate_cost_max": 7.0,
        "carrier_bound_min": 10.0, "carrier_bound_max": 18.0,
        "support_required_prob": 0.45, "support_bound_min": 3.0, "support_bound_max": 7.0,
        "self_recovery_guarantee": 12.0, "partition_start_prob": 0.08,
        "partition_duration_min": 2, "partition_duration_max": 8,
        "inflation_prob": 0.10, "inflation_multiplier_min": 1.10, "inflation_multiplier_max": 1.35,
        "crash_prob": 0.002, "settlement_ratio_min": 0.90, "settlement_ratio_max": 1.0,
        "witness_count": 2, "completion_duration_min": 2, "completion_duration_max": 12,
    }
    return [f"Params.{key}: {getattr(p, key)!r} != {value!r}" for key, value in expected.items() if getattr(p, key) != value]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def verify_manifest() -> list[str]:
    path = ROOT / "data" / "SOURCE_INDEX.json"
    if not path.exists():
        return ["data/SOURCE_INDEX.json is missing"]
    manifest = json.loads(path.read_text(encoding="utf-8"))
    failures = []
    for item in manifest["files"]:
        local = ROOT / item["path"]
        if not local.exists():
            failures.append(f"missing {item['path']}")
        elif sha256(local) != item["sha256"]:
            failures.append(f"SHA-256 mismatch: {item['path']}")
    return failures


def crn_audit() -> dict[str, object]:
    import csv
    checks = {}
    for name in ["default", "partition", "handoff", "security_attacks", "scalability"]:
        directory = DATA / name
        base = directory / "frozen_raw.csv"
        fixed = directory / "central_fix_raw.csv"
        if not (base.exists() and fixed.exists()):
            continue
        def records(path: Path, policy: str | None = None):
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.DictReader(handle))
            return [r for r in rows if policy is None or r.get("policy") == policy]
        base_rows, fixed_rows = records(base), records(fixed, "central_commit_aware")
        key_fields = [field for field in ["attack", "partition_start_prob", "handoff_prob", "robots", "rho", "trace_id"] if base_rows and field in base_rows[0]]
        if "trace_id" not in key_fields:
            key_fields.append("trace_id")
        fingerprints = {tuple(r.get(f, "") for f in key_fields): r.get("trace_sha256", "") for r in base_rows if r.get("policy") != "central_commit_aware"}
        comparable = 0
        mismatch = 0
        for row in fixed_rows:
            key = tuple(row.get(f, "") for f in key_fields)
            if key in fingerprints and fingerprints[key] and row.get("trace_sha256"):
                comparable += 1
                mismatch += fingerprints[key] != row["trace_sha256"]
        checks[name] = {"comparable_central_rows": comparable, "trace_hash_mismatches": mismatch}
    return checks


def main() -> int:
    targets = json.loads(TARGETS.read_text(encoding="utf-8"))
    actual = reproduce()
    statuses: dict[str, dict[str, object]] = {}
    failures = verify_table_1()
    statuses["Table 1"] = {"status": "PASS" if not failures else "FAIL", "details": failures}
    for table in range(2, 11):
        key = f"table_{table}"
        failures = compare(actual[key], targets[key], table)
        note = ""
        if table == 10:
            note = "Displayed cells match the bundled aggregate benchmark CSV, but the 200 primitive timing samples per size were not preserved; independent median/ratio recomputation is NOT VERIFIED."
        status = "FAIL" if failures else ("NOT VERIFIED" if table == 10 else "PASS")
        statuses[f"Table {table}"] = {"status": status, "details": failures, "note": note}
    manifest_failures = verify_manifest()
    crn = crn_audit()
    payload = {"tables": statuses, "manifest": {"status": "PASS" if not manifest_failures else "FAIL", "details": manifest_failures}, "crn_audit": crn, "scope": "Sections 6.1--6.7 only"}
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = ["# Verification report", "", "This report compares code/data recomputation with the final paper PDF. No source data are modified.", "", "| Paper table | Status | Notes |", "|---|---:|---|"]
    for name, value in statuses.items():
        details = "; ".join(value["details"]) if value["details"] else value.get("note", "")
        lines.append(f"| {name} | **{value['status']}** | {details or 'All reported cells reproduced at displayed precision.'} |")
    lines.extend(["", "## Important scope limits", "", "- Table 10 is reproduced from a formal aggregate timing file. The original 200 per-size timing samples are not bundled and therefore cannot be independently re-aggregated.", "- Table 9 times measure Python discrete-event simulation runtime, not network, consensus, robot motion, or physical actuation latency.", "- The simulator is a software-only model. It does not implement a real asynchronous distributed deployment.", "", "## Default paired checks", "", f"- Physical Completed = Rescued + Retire Pending at End: {actual['table_2_diagnostics']['physical_equals_rescued_plus_pending']}/500 traces.", f"- Default beyond-bound record-loss total: {actual['table_2_diagnostics']['default_record_loss_beyond_bound_total']:.0f} event across 500 COMMITGUARD traces.", "", "## Data integrity", "", f"- Manifest: **{payload['manifest']['status']}**", f"- CRN audit: `{json.dumps(crn, ensure_ascii=False)}`", ""])
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    failed = [name for name, value in statuses.items() if value["status"] == "FAIL"]
    print("; ".join(f"{name}={value['status']}" for name, value in statuses.items()))
    return 1 if failed or manifest_failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
