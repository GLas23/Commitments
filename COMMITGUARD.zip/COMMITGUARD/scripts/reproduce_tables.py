#!/usr/bin/env python3
"""Recompute the paper's Tables 2--10 from the bundled formal CSV data.

The script uses only the Python standard library.  It never mutates formal data.
"""
from __future__ import annotations

import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "formal"
RESULTS = ROOT / "results"
LABELS = {
    "immediate_only": "Immediate-only",
    "static_worst_case": "Static worst-case reserve",
    "priority_cancel": "Priority-cancel",
    "central_commit_aware": "Central commit-aware",
    "commit_guard": "COMMIT GUARD",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def number(row: dict[str, str], field: str) -> float:
    value = row.get(field, "")
    if isinstance(value, str) and value.lower() in {"true", "false"}:
        return 1.0 if value.lower() == "true" else 0.0
    return float(value) if value not in {"", None} else 0.0


def mean(rows: Iterable[dict[str, str]], field: str) -> float:
    values = [number(row, field) for row in rows]
    return statistics.fmean(values) if values else math.nan


def selected_rows(name: str) -> list[dict[str, str]]:
    directory = DATA / name
    base = directory / "frozen_raw.csv"
    fixed = directory / "central_fix_raw.csv"
    if base.exists() and fixed.exists():
        rows = [r for r in read_csv(base) if r.get("policy") != "central_commit_aware"]
        rows.extend(r for r in read_csv(fixed) if r.get("policy") == "central_commit_aware")
        return rows
    raw = directory / "raw.csv"
    if raw.exists():
        return read_csv(raw)
    raise FileNotFoundError(f"No formal raw data for {name}")


def group(rows: Iterable[dict[str, str]], *fields: str) -> dict[tuple[str, ...], list[dict[str, str]]]:
    result: dict[tuple[str, ...], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        result[tuple(row.get(field, "") for field in fields)].append(row)
    return result


def paired_ci(rows: list[dict[str, str]], left: str, right: str, metric: str) -> dict[str, float | int]:
    by_trace: dict[str, dict[str, float]] = defaultdict(dict)
    for row in rows:
        by_trace[row["trace_id"]][row["policy"]] = number(row, metric)
    diffs = [values[left] - values[right] for values in by_trace.values() if left in values and right in values]
    n = len(diffs)
    avg = statistics.fmean(diffs)
    sd = statistics.stdev(diffs) if n > 1 else 0.0
    # n=200 or 500 in formal comparisons. These Student-t values match the simulator.
    tcrit = 1.9647293909876649 if n == 500 else 1.971956544249395
    margin = tcrit * sd / math.sqrt(n) if n > 1 else math.nan
    return {"n": n, "mean": avg, "sd": sd, "ci_low": avg - margin, "ci_high": avg + margin}


def table_2() -> tuple[dict[str, list[float | None]], dict[str, object]]:
    rows = selected_rows("default")
    grouped = group(rows, "policy")
    output: dict[str, list[float | None]] = {}
    for (policy,), sample in grouped.items():
        efficiency = [number(row, "reserve_efficiency") for row in sample if number(row, "reserve_efficiency_defined") > 0]
        output[LABELS[policy]] = [
            mean(sample, "physical_completed"), mean(sample, "rescued"),
            mean(sample, "silent_unbacking"), mean(sample, "invariant_violations"),
            mean(sample, "blocked"), statistics.fmean(efficiency) if efficiency else None,
        ]
    paired = {
        "guard_minus_static_physical_completed": paired_ci(rows, "commit_guard", "static_worst_case", "physical_completed"),
        "guard_minus_priority_physical_completed": paired_ci(rows, "commit_guard", "priority_cancel", "physical_completed"),
        "guard_minus_central_physical_completed": paired_ci(rows, "commit_guard", "central_commit_aware", "physical_completed"),
        "physical_equals_rescued_plus_pending": sum(
            abs(number(r, "physical_completed") - number(r, "rescued") - number(r, "retire_pending_at_end")) < 1e-12
            for r in rows if r["policy"] == "commit_guard"
        ),
        "guard_traces": sum(r["policy"] == "commit_guard" for r in rows),
        "default_record_loss_beyond_bound_total": sum(number(r, "record_loss_beyond_fault_model") for r in rows if r["policy"] == "commit_guard"),
    }
    return output, paired


def table_3() -> dict[str, list[float]]:
    rows = selected_rows("partition")
    grouped = group(rows, "partition_start_prob", "policy")
    output = {}
    for p in ["0.0", "0.05", "0.1", "0.15", "0.18"]:
        central = grouped[(p, "central_commit_aware")]
        guard = grouped[(p, "commit_guard")]
        output[f"{float(p):.2f}"] = [mean(central, "physical_completed"), mean(central, "rescued"), mean(central, "blocked"), mean(guard, "physical_completed"), mean(guard, "rescued"), mean(guard, "blocked")]
    return output


def table_4() -> dict[str, list[float]]:
    grouped = group(selected_rows("inflation"), "inflation_prob", "policy")
    output = {}
    for p in ["0.0", "0.05", "0.1", "0.15", "0.2"]:
        guard = grouped[(p, "commit_guard")]
        static = grouped[(p, "static_worst_case")]
        priority = grouped[(p, "priority_cancel")]
        output[f"{float(p):.2f}"] = [mean(guard, "physical_completed"), mean(guard, "rescued"), mean(static, "rescued"), mean(priority, "rescued"), mean(guard, "top_up_success"), mean(guard, "top_up_failed"), mean(guard, "at_risk")]
    return output


def table_5() -> dict[str, list[float]]:
    rows = [r for r in selected_rows("crash_witness") if r["crash_probability"] == "0.02"]
    grouped = group(rows, "witness_count")
    return {w: [mean(grouped[(w,)], metric) for metric in ["physical_completed", "rescued", "retire_pending_at_end", "forgotten", "record_loss_beyond_fault_model"]] for w in map(str, range(5))}


def table_6() -> dict[str, list[float]]:
    rows = [r for r in selected_rows("handoff") if r.get("experiment") == "handoff_sweep"]
    grouped = group(rows, "handoff_prob", "policy")
    output = {}
    for p in ["0.0", "0.05", "0.1", "0.2", "0.3"]:
        for policy in ["priority_cancel", "central_commit_aware", "commit_guard"]:
            sample = grouped[(p, policy)]
            output[f"{float(p):.2f},{policy}"] = [mean(sample, m) for m in ["physical_completed", "rescued", "handoff_success", "handoff_blocked", "replacement_before_release_violations", "silent_unbacking"]]
    return output


def table_7() -> dict[str, dict[str, list[int]]]:
    rows = selected_rows("security_attacks")
    grouped = group(rows, "attack", "policy")
    output: dict[str, dict[str, list[int]]] = {}
    for attack in ["A1_replay", "A2_silent_cancellation", "A3_unauthorized_degradation", "A4_remote_right_overspend"]:
        output[attack] = {}
        for policy in ["commit_guard", "central_commit_aware", "static_worst_case", "priority_cancel"]:
            sample = grouped[(attack, policy)]
            output[attack][policy] = [round(sum(number(r, "primary_attack_successes") for r in sample)), round(sum(number(r, "primary_attack_attempts") for r in sample))]
    return output


def table_8() -> dict[str, list[float]]:
    rows = selected_rows("ablation")
    metric = {"-Witness": "forgotten", "-Version": "replay_accepted", "-LocalRights": "remote_double_spend_events", "-Transform": "semantic_liability_coverage_violations", "-Degradation": "self_recovery_degradation_events", "-AT-RISK": "silent_unbacking"}
    grouped = group(rows, "ablation", "variant")
    output = {}
    for name, field in metric.items():
        full, ablated = grouped[(name, "Full")], grouped[(name, "Ablated")]
        output[name] = [mean(full, field), mean(ablated, field), mean(full, "rescued"), mean(ablated, "rescued")]
    return output


def table_9() -> dict[str, list[float]]:
    grouped = group(selected_rows("scalability"), "robots", "rho", "policy")
    points = [(5, .1), (10, .1), (20, .1), (40, .1), (80, .1), (100, .025), (100, .05), (100, .1)]
    output = {}
    for robots, rho in points:
        r, q = str(robots), str(rho)
        central, guard = grouped[(r, q, "central_commit_aware")], grouped[(r, q, "commit_guard")]
        output[f"{robots},{rho:.3f}"] = [mean(central, "rescued"), mean(central, "simulation_runtime_s"), mean(guard, "rescued"), mean(guard, "simulation_runtime_s")]
    return output


def table_10() -> dict[str, list[float]]:
    rows = read_csv(DATA / "microbenchmark" / "accounting_microbench.csv")
    return {r["outstanding_commitments"]: [number(r, "global_scan_median_us"), number(r, "participant_local_median_us"), number(r, "speedup_median")] for r in rows}


def reproduce() -> dict[str, object]:
    t2, diagnostics = table_2()
    return {"table_2": t2, "table_2_diagnostics": diagnostics, "table_3": table_3(), "table_4": table_4(), "table_5": table_5(), "table_6": table_6(), "table_7": table_7(), "table_8": table_8(), "table_9": table_9(), "table_10": table_10()}


def markdown(payload: dict[str, object]) -> str:
    lines = ["# Recomputed paper tables", "", "All values below were recomputed from `data/formal/`; they are not copied from the paper.", ""]
    for number_ in range(2, 11):
        key = f"table_{number_}"
        lines.extend([f"## Table {number_}", "", "```json", json.dumps(payload[key], indent=2, ensure_ascii=False), "```", ""])
    lines.extend(["## Paired diagnostics", "", "```json", json.dumps(payload["table_2_diagnostics"], indent=2), "```", ""])
    return "\n".join(lines)


def main() -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    payload = reproduce()
    (RESULTS / "recomputed_tables.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (RESULTS / "recomputed_tables.md").write_text(markdown(payload), encoding="utf-8")
    print(f"Wrote {RESULTS / 'recomputed_tables.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
