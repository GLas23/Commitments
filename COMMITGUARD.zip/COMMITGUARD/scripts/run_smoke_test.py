#!/usr/bin/env python3
"""Run a non-destructive two-trace default experiment in a temporary directory."""
from __future__ import annotations

import csv
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SIM = ROOT / "src" / "commitguard_sim.py"


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="commitguard-smoke-") as temporary:
        out = Path(temporary) / "results"
        subprocess.run([sys.executable, str(SIM), "--experiment", "default", "--traces", "2", "--seed", "1", "--out-dir", str(out), "--no-progress"], check=True, cwd=ROOT)
        raw = out / "default_raw.csv"
        if not raw.exists():
            raw = out / "default" / "default_raw.csv"
        with raw.open("r", encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))
        assert len(rows) == 10, f"expected 2 traces x 5 policies, got {len(rows)}"
        for trace_id in {row["trace_id"] for row in rows}:
            hashes = {row["trace_sha256"] for row in rows if row["trace_id"] == trace_id}
            assert len(hashes) == 1, f"CRN mismatch on trace {trace_id}"
        guard = [r for r in rows if r["policy"] == "commit_guard"]
        assert all(float(r["invariant_violations"]) == 0 for r in guard)
    print("SMOKE TEST PASS: 2 traces x 5 policies, CRN intact, COMMITGUARD invariants zero")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
