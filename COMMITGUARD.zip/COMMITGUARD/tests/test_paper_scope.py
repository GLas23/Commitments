from __future__ import annotations

import importlib.util
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from reproduce_tables import reproduce  # noqa: E402


def load_simulator():
    path = ROOT / "src" / "commitguard_sim.py"
    spec = importlib.util.spec_from_file_location("commitguard_sim_test", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


class PaperScopeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sim = load_simulator()

    def test_default_parameters(self):
        params = self.sim.Params()
        self.assertEqual((params.robots, params.initial_energy, params.epochs), (10, 100.0, 80))
        self.assertEqual(params.witness_count, 2)
        self.assertAlmostEqual(params.partition_start_prob, 0.08)
        self.assertAlmostEqual(params.inflation_prob, 0.10)

    def test_trace_generation_is_deterministic(self):
        params = self.sim.Params()
        self.assertEqual(self.sim.generate_trace(params, 1), self.sim.generate_trace(params, 1))
        self.assertNotEqual(self.sim.generate_trace(params, 1), self.sim.generate_trace(params, 2))

    def test_common_random_numbers_and_guard_invariants(self):
        _, raw = self.sim.run_policies(self.sim.Params(), 1, 1, self.sim.POLICIES, show_progress=False)
        self.assertEqual(len(raw), 5)
        self.assertEqual(len({row["trace_sha256"] for row in raw}), 1)
        guard = next(row for row in raw if row["policy"] == "commit_guard")
        self.assertEqual(guard["invariant_violations"], 0)

    def test_immediate_reserve_efficiency_is_undefined(self):
        summary, _ = self.sim.run_policies(self.sim.Params(), 1, 1, ["immediate_only"], show_progress=False)
        self.assertEqual(summary[0]["reserve_efficiency_mean"], "")

    def test_formal_default_table_recomputes(self):
        table = reproduce()["table_2"]
        self.assertAlmostEqual(table["COMMIT GUARD"][0], 28.232)
        self.assertAlmostEqual(table["COMMIT GUARD"][1], 27.692)
        self.assertIsNone(table["Immediate-only"][5])

    def test_packaged_scope_excludes_later_experiments(self):
        source = (ROOT / "src" / "commitguard_sim.py").read_text(encoding="utf-8")
        for token in ["B3+", "liability_pair", "recovery_assist", "certificate_faults", "E1-E3"]:
            self.assertNotIn(token, source)


if __name__ == "__main__":
    unittest.main()
